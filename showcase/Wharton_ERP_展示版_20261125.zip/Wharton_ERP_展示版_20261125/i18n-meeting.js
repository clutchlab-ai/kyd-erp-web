/* Offline exhibition interface translations. */
window.SFM_I18N??={};
Object.assign(window.SFM_I18N,{
 "meeting": [
  [
   "特別假（家庭事件）",
   "Special leave (family events)",
   "ច្បាប់ឈប់ពិសេស (ព្រឹត្តិការណ៍គ្រួសារ)"
  ],
  [
   "產假",
   "Maternity leave",
   "ច្បាប់ឈប់សម្រាកមាតុភាព"
  ],
  [
   "無薪假",
   "Unpaid leave",
   "ច្បាប់ឈប់គ្មានប្រាក់ឈ្នួល"
  ],
  [
   "送出申請",
   "Submit request",
   "ដាក់សំណើ"
  ],
  [
   "累計額度",
   "Accrued entitlement",
   "សិទ្ធិឈប់សម្រាកបង្គរ"
  ],
  [
   "計算截止月份",
   "Accrued through",
   "គណនាដល់ខែ"
  ],
  [
   "額度調整紀錄",
   "Balance adjustments",
   "កំណត់ត្រាកែតម្រូវសមតុល្យ"
  ],
  [
   "尚無額度調整。",
   "No balance adjustments.",
   "មិនមានការកែតម្រូវសមតុល្យទេ។"
  ],
  [
   "年假計算",
   "Annual leave accrual",
   "ការបង្គរច្បាប់ឈប់ប្រចាំឆ្នាំ"
  ],
  [
   "設定年假規則",
   "Set annual leave rules",
   "កំណត់ច្បាប់ឈប់ប្រចាំឆ្នាំ"
  ],
  [
   "調整員工額度",
   "Adjust employee balance",
   "កែតម្រូវសមតុល្យបុគ្គលិក"
  ],
  [
   "一至三層簽核",
   "One to three approval stages",
   "ការអនុម័តមួយដល់បីដំណាក់កាល"
  ],
  [
   "設定簽核路線",
   "Set approval route",
   "កំណត់លំដាប់អនុម័ត"
  ],
  [
   "部門／角色",
   "Department / role",
   "ផ្នែក / តួនាទី"
  ],
  [
   "處理順序",
   "Processing order",
   "លំដាប់ដំណើរការ"
  ],
  [
   "全部部門",
   "All departments",
   "គ្រប់ផ្នែក"
  ],
  [
   "全部角色",
   "All roles",
   "គ្រប់តួនាទី"
  ],
  [
   "假別與適用規則",
   "Leave types and rules",
   "ប្រភេទច្បាប់ឈប់និងលក្ខខណ្ឌ"
  ],
  [
   "新增公司假別",
   "Add company leave type",
   "បន្ថែមប្រភេទច្បាប់ឈប់របស់ក្រុមហ៊ុន"
  ],
  [
   "假別名稱",
   "Leave type name",
   "ឈ្មោះប្រភេទច្បាប់ឈប់"
  ],
  [
   "每月累計天數",
   "Days accrued per month",
   "ចំនួនថ្ងៃបង្គរប្រចាំខែ"
  ],
  [
   "每日換算時數",
   "Hours per day",
   "ចំនួនម៉ោងក្នុងមួយថ្ងៃ"
  ],
  [
   "待審是否預留額度",
   "Reserve pending requests",
   "រក្សាទុកសមតុល្យសម្រាប់សំណើរង់ចាំ"
  ],
  [
   "預留",
   "Reserve",
   "រក្សាទុក"
  ],
  [
   "核准才扣額度",
   "Deduct on approval",
   "កាត់បន្ថយពេលអនុម័ត"
  ],
  [
   "設定依據",
   "Basis for this setting",
   "មូលដ្ឋាននៃការកំណត់"
  ],
  [
   "調整時數（可正負）",
   "Adjustment hours (+/−)",
   "ម៉ោងកែតម្រូវ (+/−)"
  ],
  [
   "調整原因",
   "Adjustment reason",
   "មូលហេតុកែតម្រូវ"
  ],
  [
   "申請人角色",
   "Applicant role",
   "តួនាទីអ្នកស្នើសុំ"
  ],
  [
   "簽核層數",
   "Number of approval stages",
   "ចំនួនដំណាក់កាលអនុម័ត"
  ],
  [
   "一層",
   "One stage",
   "មួយដំណាក់កាល"
  ],
  [
   "兩層",
   "Two stages",
   "ពីរដំណាក់កាល"
  ],
  [
   "三層",
   "Three stages",
   "បីដំណាក់កាល"
  ],
  [
   "第 1 層",
   "Stage 1",
   "ដំណាក់កាលទី ១"
  ],
  [
   "第 2 層",
   "Stage 2",
   "ដំណាក់កាលទី ២"
  ],
  [
   "第 3 層",
   "Stage 3",
   "ដំណាក់កាលទី ៣"
  ],
  [
   "佐證連結（選填）",
   "Evidence link (optional)",
   "តំណភស្តុតាង (ស្រេចចិត្ត)"
  ],
  [
   "開啟佐證連結",
   "Open evidence link",
   "បើកតំណភស្តុតាង"
  ],
  [
   "假別與簽核設定",
   "Leave and approval settings",
   "ការកំណត់ច្បាប់ឈប់និងការអនុម័ត"
  ],
  [
   "可視化班表",
   "Schedule calendar",
   "ប្រតិទិនវេនការងារ"
  ],
  [
   "全員假勤總表",
   "Team leave and attendance",
   "សង្ខេបច្បាប់ឈប់និងវត្តមានក្រុម"
  ],
  [
   "全員假勤與工時",
   "Team leave and working hours",
   "ច្បាប់ឈប់និងម៉ោងការងារក្រុម"
  ],
  [
   "班表清單",
   "Schedule list",
   "បញ្ជីវេនការងារ"
  ],
  [
   "月結核對",
   "Monthly reconciliation",
   "ផ្ទៀងផ្ទាត់ប្រចាំខែ"
  ],
  [
   "全部授權部門",
   "All authorized departments",
   "គ្រប់ផ្នែកដែលមានសិទ្ធិ"
  ],
  [
   "套用篩選",
   "Apply filters",
   "អនុវត្តតម្រង"
  ],
  [
   "員工／部門",
   "Employee / department",
   "បុគ្គលិក / ផ្នែក"
  ],
  [
   "排定工時",
   "Scheduled hours",
   "ម៉ោងការងារបានកំណត់"
  ],
  [
   "打卡參考工時",
   "Clocked hours (reference)",
   "ម៉ោងកត់ត្រាវត្តមាន (យោង)"
  ],
  [
   "核准請假",
   "Approved leave",
   "ច្បាប់ឈប់បានអនុម័ត"
  ],
  [
   "待審請假",
   "Pending leave",
   "ច្បាប់ឈប់រង់ចាំអនុម័ត"
  ],
  [
   "核准加班",
   "Approved overtime",
   "ម៉ោងបន្ថែមបានអនុម័ត"
  ],
  [
   "目前年假可用",
   "Current annual leave balance",
   "សមតុល្យច្បាប់ឈប់ប្រចាំឆ្នាំបច្ចុប្បន្ន"
  ],
  [
   "來源",
   "Source",
   "ប្រភព"
  ],
  [
   "來源明細",
   "Source records",
   "កំណត់ត្រាប្រភព"
  ],
  [
   "跨月待拆分",
   "Cross-month allocation needed",
   "ត្រូវបែងចែកតាមខែ"
  ],
  [
   "返回全員總表",
   "Back to team summary",
   "ត្រឡប់ទៅសង្ខេបក្រុម"
  ],
  [
   "目前範圍沒有員工",
   "No employees in this scope",
   "គ្មានបុគ្គលិកក្នុងវិសាលភាពនេះ"
  ],
  [
   "本月沒有假勤申請",
   "No leave requests this month",
   "មិនមានសំណើច្បាប់ឈប់ខែនេះ"
  ],
  [
   "安排班次",
   "Schedule a shift",
   "រៀបចំវេនការងារ"
  ],
  [
   "班次明細",
   "Shift details",
   "ព័ត៌មានលម្អិតវេន"
  ],
  [
   "當日尚無班次。",
   "No shifts on this day.",
   "មិនមានវេននៅថ្ងៃនេះទេ។"
  ],
  [
   "當日請假",
   "Leave on this day",
   "ច្បាប់ឈប់នៅថ្ងៃនេះ"
  ],
  [
   "當日沒有已核准請假。",
   "No approved leave on this day.",
   "មិនមានច្បាប់ឈប់បានអនុម័តនៅថ្ងៃនេះទេ។"
  ],
  [
   "人力待補",
   "Staffing shortage",
   "ខ្វះបុគ្គលិក"
  ],
  [
   "尚未設定當日崗位需求。",
   "No staffing requirement set for this day.",
   "មិនទាន់កំណត់តម្រូវការបុគ្គលិកសម្រាប់ថ្ងៃនេះទេ។"
  ],
  [
   "安排崗位人力",
   "Plan staffing",
   "រៀបចំកម្លាំងបុគ្គលិក"
  ],
  [
   "送交主管發布",
   "Submit for schedule publication",
   "ដាក់ស្នើឱ្យអ្នកគ្រប់គ្រងផ្សាយវេន"
  ],
  [
   "全員證件總表",
   "Team document register",
   "បញ្ជីឯកសាររបស់ក្រុម"
  ],
  [
   "未登錄",
   "Not recorded",
   "មិនទាន់ចុះបញ្ជី"
  ],
  [
   "請核對是否適用",
   "Check applicability",
   "ពិនិត្យថាតើត្រូវអនុវត្តឬទេ"
  ],
  [
   "全員總表",
   "Team register",
   "បញ្ជីសង្ខេបក្រុម"
  ],
  [
   "證件清單與跟進",
   "Documents and follow-up",
   "ឯកសារនិងការតាមដាន"
  ],
  [
   "董事長專屬 Dashboard",
   "Chairman dashboard",
   "ផ្ទាំងគ្រប់គ្រងសម្រាប់ប្រធានក្រុមប្រឹក្សាភិបាល"
  ],
  [
   "管理總覽",
   "Management overview",
   "ទិដ្ឋភាពទូទៅការគ្រប់គ្រង"
  ],
  [
   "我的工作與申請",
   "My work and requests",
   "ការងារនិងសំណើរបស់ខ្ញុំ"
  ],
  [
   "統計週期",
   "Reporting period",
   "រយៈពេលរបាយការណ៍"
  ],
  [
   "近七日",
   "Last seven days",
   "ប្រាំពីរថ្ងៃចុងក្រោយ"
  ],
  [
   "本月",
   "This month",
   "ខែនេះ"
  ],
  [
   "更新總覽",
   "Update overview",
   "ធ្វើបច្ចុប្បន្នភាពទិដ្ឋភាពទូទៅ"
  ],
  [
   "已入帳收入",
   "Posted income",
   "ចំណូលបានកត់ត្រាក្នុងបញ្ជី"
  ],
  [
   "已入帳費用",
   "Posted expenses",
   "ចំណាយបានកត់ត្រាក្នុងបញ្ជី"
  ],
  [
   "財務大類",
   "Financial categories",
   "ប្រភេទហិរញ្ញវត្ថុ"
  ],
  [
   "此期間尚無已入帳收入或費用。",
   "No posted income or expenses in this period.",
   "មិនមានចំណូលឬចំណាយបានកត់ត្រាក្នុងរយៈពេលនេះទេ។"
  ],
  [
   "核對帳務來源",
   "Review accounting records",
   "ពិនិត្យកំណត់ត្រាគណនេយ្យ"
  ],
  [
   "需關注事項",
   "Items needing attention",
   "ចំណុចដែលត្រូវយកចិត្តទុកដាក់"
  ],
  [
   "期間請假人數",
   "People on leave in period",
   "ចំនួនអ្នកឈប់ក្នុងរយៈពេល"
  ],
  [
   "考核完成",
   "Completed reviews",
   "ការវាយតម្លៃបានបញ្ចប់"
  ],
  [
   "各部門近況",
   "Department status",
   "ស្ថានភាពផ្នែកនីមួយៗ"
  ],
  [
   "考核完成／總數",
   "Reviews completed / total",
   "ការវាយតម្លៃបានបញ្ចប់ / សរុប"
  ],
  [
   "工程進度",
   "Engineering progress",
   "វឌ្ឍនភាពវិស្វកម្ម"
  ],
  [
   "工作與里程碑",
   "Work and milestones",
   "ការងារនិងគោលដៅដំណាក់កាល"
  ],
  [
   "目前公司沒有工程專案。",
   "No engineering projects for this company.",
   "ក្រុមហ៊ុននេះមិនមានគម្រោងវិស្វកម្មទេ។"
  ],
  [
   "各公司已入帳摘要",
   "Posted totals by company",
   "សង្ខេបដែលបានកត់ត្រាតាមក្រុមហ៊ុន"
  ],
  [
   "按公司、部門及月份核對；申請核准、銷假與補卡後自動更新。",
   "Review by company, department and month. Updates after approvals, leave cancellations and punch corrections.",
   "ពិនិត្យតាមក្រុមហ៊ុន ផ្នែក និងខែ។ ធ្វើបច្ចុប្បន្នភាពក្រោយអនុម័ត លុបច្បាប់ឈប់ និងកែវត្តមាន។"
  ],
  [
   "先選日期，再安排班次或查看請假；班表送交另一位主管發布。",
   "Select a date to schedule shifts or review leave. Another authorized manager publishes the schedule.",
   "ជ្រើសកាលបរិច្ឆេទដើម្បីរៀបចំវេនឬពិនិត្យច្បាប់ឈប់។ អ្នកគ្រប់គ្រងផ្សេងដែលមានសិទ្ធិនឹងផ្សាយវេន។"
  ],
  [
   "藍色為班次；橙色為請假。請假不會自動刪除班次。",
   "Blue shows shifts; orange shows leave. Leave does not automatically remove a shift.",
   "ពណ៌ខៀវបង្ហាញវេន ពណ៌ទឹកក្រូចបង្ហាញច្បាប់ឈប់។ ច្បាប់ឈប់មិនលុបវេនដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "當日有請假，請核對時段與替班安排。",
   "Leave exists on this day. Check the time and replacement arrangement.",
   "មានច្បាប់ឈប់នៅថ្ងៃនេះ។ សូមពិនិត្យម៉ោងនិងការរៀបចំអ្នកជំនួស។"
  ],
  [
   "列出授權範圍內全部在職人員，缺件、期限與續辦紀錄集中核對。",
   "Review all active employees in scope, including missing documents, expiry dates and renewal history.",
   "ពិនិត្យបុគ្គលិកកំពុងបម្រើការទាំងអស់ក្នុងវិសាលភាព រួមទាំងឯកសារខ្វះ ថ្ងៃផុតកំណត់ និងប្រវត្តិបន្ត។"
  ],
  [
   "先看各單位的重要數字、進度與需關注事項，再進入來源核對。",
   "See key numbers, progress and issues by unit, then open the source records.",
   "មើលតួលេខសំខាន់ វឌ្ឍនភាព និងបញ្ហាតាមអង្គភាព រួចបើកកំណត់ត្រាប្រភព។"
  ],
  [
   "公司帳分開，切換上方公司即可查看各單位。不同幣別不直接合併。",
   "Company books are separate. Switch company above to review each unit. Different currencies are not combined.",
   "បញ្ជីគណនេយ្យក្រុមហ៊ុនដាច់ដោយឡែក។ ប្ដូរក្រុមហ៊ុនខាងលើដើម្បីពិនិត្យ។ រូបិយប័ណ្ណផ្សេងគ្នាមិនបូកចូលគ្នាទេ។"
  ],
  [
   "年假可用額度依假勤設定的截止月份計算，不是所選月份的歷史餘額。",
   "Available annual leave uses the accrual cutoff in leave settings, not a historical balance for the selected month.",
   "សមតុល្យច្បាប់ឈប់គិតតាមខែកំណត់ក្នុងការកំណត់ច្បាប់ឈប់ មិនមែនសមតុល្យប្រវត្តិសាស្ត្រនៃខែដែលបានជ្រើសទេ។"
  ],
  [
   "以下為流程示例。未登錄不代表違規；各證件的適用人員與必備條件仍須核對。",
   "These are workflow examples. Missing records do not establish a violation; document applicability still needs confirmation.",
   "ទាំងនេះជាឧទាហរណ៍ដំណើរការ។ កំណត់ត្រាខ្វះមិនមានន័យថាល្មើសទេ ហើយត្រូវបញ្ជាក់លក្ខខណ្ឌឯកសារ។"
  ],
  [
   "選擇申請類型，填寫後送出；處理人會依簽核順序收到待辦。",
   "Choose a request type, complete it and submit. Approvers receive tasks in order.",
   "ជ្រើសប្រភេទសំណើ បំពេញហើយដាក់ស្នើ។ អ្នកអនុម័តទទួលការងារតាមលំដាប់។"
  ],
  [
   "依公司、申請類型、部門及申請人角色設定。已送出申請保留原路線。",
   "Configure by company, request type, department and applicant role. Submitted requests retain their original route.",
   "កំណត់តាមក្រុមហ៊ុន ប្រភេទសំណើ ផ្នែក និងតួនាទីអ្នកស្នើ។ សំណើដែលបានដាក់រក្សាលំដាប់ដើម។"
  ],
  [
   "未另設的情境沿用目前兩層示例；正式准假表仍以營運主管核定為準。",
   "Unconfigured cases use the existing two-stage example. Formal leave authority still requires CEO approval.",
   "ករណីមិនបានកំណត់ប្រើឧទាហរណ៍ពីរដំណាក់កាល។ សិទ្ធិអនុម័តច្បាប់ឈប់ផ្លូវការត្រូវរង់ចាំ CEO បញ្ជាក់។"
  ],
  [
   "只使用所選層數；最後一層核准，其餘層複核。不能自審或重複簽核。",
   "Only the selected stages apply. The final stage approves; prior stages review. No self-approval or duplicate approver.",
   "ប្រើតែដំណាក់កាលដែលបានជ្រើស។ ដំណាក់កាលចុងក្រោយអនុម័ត ដំណាក់កាលមុនផ្ទៀងផ្ទាត់។ មិនអាចអនុម័តខ្លួនឯងឬស្ទួនបានទេ។"
  ],
  [
   "額度、薪資、佐證及適用條件仍須按正式制度設定，這裡不自動計薪。",
   "Entitlements, pay, evidence and eligibility require formal policy settings. This view does not calculate payroll.",
   "សិទ្ធិ ប្រាក់ឈ្នួល ភស្តុតាង និងលក្ខខណ្ឌត្រូវកំណត់តាមគោលការណ៍ផ្លូវការ។ ទំព័រនេះមិនគណនាប្រាក់ខែទេ។"
  ],
  [
   "目前身分無法查看全員總表",
   "Your role cannot access the team register",
   "តួនាទីរបស់អ្នកមិនអាចមើលបញ្ជីក្រុមបានទេ"
  ],
  [
   "目前身分無法查看管理總覽",
   "Your role cannot access management overview",
   "តួនាទីរបស់អ្នកមិនអាចមើលទិដ្ឋភាពគ្រប់គ្រងបានទេ"
  ],
  [
   "年假餘額不足，請調整時數或自行選擇其他適用假別；不會自動更改假別。",
   "Insufficient annual leave. Adjust hours or choose another applicable leave type; it will not be changed automatically.",
   "សមតុល្យច្បាប់ឈប់មិនគ្រប់។ កែម៉ោងឬជ្រើសប្រភេទសមស្របផ្សេងទៀត វាមិនប្ដូរដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "這個月份已送審或鎖定，請先重新開啟月結，再調整假勤。",
   "This month is under review or locked. Reopen monthly closing before changing leave.",
   "ខែនេះកំពុងពិនិត្យឬបានចាក់សោ។ បើកការបិទប្រចាំខែឡើងវិញមុនកែច្បាប់ឈប់។"
  ],
  [
   "單日",
   "Single day",
   "មួយថ្ងៃ"
  ],
  [
   "在職人員",
   "Active employees",
   "បុគ្គលិកកំពុងបម្រើការ"
  ],
  [
   "年假、家庭事件特別假、產假與病假分開管理；事假及無薪假依公司制度。國定假日與每週休息日屬班表日曆，不當作請假扣除。",
   "Annual, special family, maternity and sick leave are separate. Personal and unpaid leave follow company policy. Public holidays and weekly rest days belong in the schedule calendar and are not leave deductions.",
   "ច្បាប់ឈប់ប្រចាំឆ្នាំ ពិសេសគ្រួសារ មាតុភាព និងឈឺគ្រប់គ្រងដាច់ដោយឡែក។ ច្បាប់ឈប់ផ្ទាល់ខ្លួននិងគ្មានប្រាក់ឈ្នួលតាមគោលការណ៍ក្រុមហ៊ុន។ ថ្ងៃបុណ្យនិងថ្ងៃសម្រាកប្រចាំសប្ដាហ៍មិនកាត់ច្បាប់ឈប់ទេ។"
  ],
  [
   "工時以成對打卡扣除班別休息時間計算，缺卡另列；此數字不等同計薪工時。跨月申請完整列入來源，但尚未拆分的時數不併入月合計。",
   "Hours use paired clock-ins and clock-outs less shift breaks; missing punches are listed separately. These are not payroll hours. Cross-month requests remain in the sources; unallocated hours are excluded from monthly totals.",
   "ម៉ោងគិតពីការកត់ត្រាចូលនិងចេញគូគ្នា ដកពេលសម្រាក ហើយការខ្វះកត់ត្រាបង្ហាញដាច់ដោយឡែក។ នេះមិនមែនម៉ោងគណនាប្រាក់ខែទេ។ សំណើឆ្លងខែមានក្នុងប្រភព តែម៉ោងមិនទាន់បែងចែកមិនបញ្ចូលក្នុងសរុបខែទេ។"
  ],
  [
   "柬埔寨勞動法參考（第 71、166–171、182 條）",
   "Cambodian Labour Law reference (Articles 71, 166–171, 182)",
   "យោងច្បាប់ការងារកម្ពុជា (មាត្រា 71, 166–171, 182)"
  ],
  [
   "班次與已核准請假重疊，請核對替班安排。",
   "This shift overlaps approved leave. Check replacement coverage.",
   "វេននេះជាន់គ្នានឹងច្បាប់ឈប់ដែលបានអនុម័ត។ សូមពិនិត្យអ្នកជំនួស។"
  ],
  [
   "依已發布班次核對；部分時段請假也列為衝突，請確認替班，不代表全天缺勤。",
   "Checked against published shifts. Partial leave is also flagged; confirm coverage. This does not mean a full-day absence.",
   "ផ្ទៀងផ្ទាត់តាមវេនដែលបានផ្សាយ។ ច្បាប់ឈប់មួយផ្នែកក៏ត្រូវបានសម្គាល់។ សូមពិនិត្យអ្នកជំនួស មិនមែនអវត្តមានពេញមួយថ្ងៃទេ។"
  ],
  [
   "查看崗位安排",
   "View staffing assignment",
   "មើលការរៀបចំបុគ្គលិក"
  ],
  [
   "人力待查",
   "Check coverage",
   "ពិនិត្យបុគ្គលិក"
  ],
  [
   "請由獲公司授權的人資或管理層處理月結。",
   "Company-authorized HR or management must process monthly closing.",
   "ផ្នែកធនធានមនុស្សឬថ្នាក់គ្រប់គ្រងដែលក្រុមហ៊ុនអនុញ្ញាតត្រូវដំណើរការបិទខែ។"
  ]
 ],
 "nov12": [
  [
   "培訓紀錄",
   "Training records",
   "កំណត់ត្រាបណ្តុះបណ្តាល"
  ],
  [
   "內部培訓",
   "Internal training",
   "ការបណ្តុះបណ្តាលផ្ទៃក្នុង"
  ],
  [
   "外部培訓",
   "External training",
   "ការបណ្តុះបណ្តាលខាងក្រៅ"
  ],
  [
   "課程管理",
   "Course management",
   "ការគ្រប់គ្រងវគ្គសិក្សា"
  ],
  [
   "我的課程",
   "My courses",
   "វគ្គសិក្សារបស់ខ្ញុំ"
  ],
  [
   "登錄培訓紀錄",
   "Record training",
   "កត់ត្រាការបណ្តុះបណ្តាល"
  ],
  [
   "參訓通知",
   "Training invitation",
   "ការជូនដំណឹងបណ្តុះបណ្តាល"
  ],
  [
   "回覆參訓通知",
   "Reply to invitation",
   "ឆ្លើយតបការជូនដំណឹង"
  ],
  [
   "修改參訓回覆",
   "Edit training response",
   "កែចម្លើយការបណ្តុះបណ្តាល"
  ],
  [
   "參訓意願",
   "Participation intention",
   "បំណងចូលរួម"
  ],
  [
   "可以參加",
   "Can attend",
   "អាចចូលរួម"
  ],
  [
   "無法參加",
   "Cannot attend",
   "មិនអាចចូលរួម"
  ],
  [
   "已確認參加",
   "Attendance intention confirmed",
   "បានបញ្ជាក់បំណងចូលរួម"
  ],
  [
   "已回覆無法參加",
   "Replied: cannot attend",
   "បានឆ្លើយថាមិនអាចចូលរួម"
  ],
  [
   "回覆會參加",
   "Intends to attend",
   "មានបំណងចូលរួម"
  ],
  [
   "回覆無法參加",
   "Unable to attend",
   "មិនអាចចូលរួម"
  ],
  [
   "尚未回覆意願",
   "No response yet",
   "មិនទាន់ឆ្លើយតប"
  ],
  [
   "送出回覆",
   "Send response",
   "ផ្ញើចម្លើយ"
  ],
  [
   "通知參訓員工",
   "Notify participants",
   "ជូនដំណឹងអ្នកចូលរួម"
  ],
  [
   "首堂日期",
   "First session date",
   "កាលបរិច្ឆេទវគ្គដំបូង"
  ],
  [
   "內部講師",
   "Internal instructor",
   "គ្រូបណ្តុះបណ្តាលផ្ទៃក្នុង"
  ],
  [
   "外部講師",
   "External instructor",
   "គ្រូបណ្តុះបណ្តាលខាងក្រៅ"
  ],
  [
   "外部講師姓名",
   "External instructor name",
   "ឈ្មោះគ្រូខាងក្រៅ"
  ],
  [
   "發布課程與通知",
   "Publish course and invitations",
   "ផ្សព្វផ្សាយវគ្គនិងជូនដំណឹង"
  ],
  [
   "補請假",
   "Retroactive leave request",
   "សំណើច្បាប់ឈប់ក្រោយពេលអវត្តមាន"
  ],
  [
   "新增補請假",
   "New retroactive leave request",
   "ស្នើច្បាប់ឈប់ក្រោយពេលអវត្តមានថ្មី"
  ],
  [
   "銷假方式",
   "Leave cancellation scope",
   "វិសាលភាពការលុបច្បាប់ឈប់"
  ],
  [
   "全部剩餘時數",
   "All remaining hours",
   "ម៉ោងនៅសល់ទាំងអស់"
  ],
  [
   "部分時段",
   "Partial period",
   "រយៈពេលមួយផ្នែក"
  ],
  [
   "部分銷假開始日期",
   "Partial cancellation start date",
   "ថ្ងៃចាប់ផ្តើមលុបច្បាប់មួយផ្នែក"
  ],
  [
   "部分銷假結束日期",
   "Partial cancellation end date",
   "ថ្ងៃបញ្ចប់លុបច្បាប់មួយផ្នែក"
  ],
  [
   "部分銷假時數",
   "Hours to cancel",
   "ម៉ោងច្បាប់ដែលត្រូវលុប"
  ],
  [
   "本機示例附件",
   "Local example attachments",
   "ឯកសារភ្ជាប់គំរូនៅក្នុងឧបករណ៍"
  ],
  [
   "附件",
   "Attachments",
   "ឯកសារភ្ជាប់"
  ],
  [
   "選擇 PDF／圖片，或拖曳到這裡",
   "Choose a PDF/image or drop it here",
   "ជ្រើស PDF/រូបភាព ឬទម្លាក់នៅទីនេះ"
  ],
  [
   "新增交辦",
   "Assign a task",
   "ប្រគល់ភារកិច្ច"
  ],
  [
   "主管交辦",
   "Supervisor assignment",
   "ការប្រគល់ភារកិច្ចពីអ្នកគ្រប់គ្រង"
  ],
  [
   "員工執行與回報",
   "Employee work and progress",
   "ការងារនិងរបាយការណ៍បុគ្គលិក"
  ],
  [
   "主管驗收",
   "Supervisor acceptance",
   "ការទទួលស្គាល់ពីអ្នកគ្រប់គ្រង"
  ],
  [
   "預期成果與說明",
   "Expected outcome and notes",
   "លទ្ធផលរំពឹងទុកនិងកំណត់សម្គាល់"
  ],
  [
   "歷史申請",
   "Earlier requests",
   "សំណើពីមុន"
  ],
  [
   "請款與零用金申請",
   "Payment and petty-cash requests",
   "សំណើទូទាត់និងប្រាក់បន្តិចបន្តួច"
  ],
  [
   "請款與零用金",
   "Payment and petty cash",
   "ការទូទាត់និងប្រាក់បន្តិចបន្តួច"
  ],
  [
   "請款",
   "Payment request",
   "សំណើទូទាត់"
  ],
  [
   "零用金",
   "Petty cash",
   "ប្រាក់បន្តិចបន្តួច"
  ],
  [
   "新增請款",
   "New payment request",
   "សំណើទូទាត់ថ្មី"
  ],
  [
   "新增零用金",
   "New petty-cash request",
   "សំណើប្រាក់បន្តិចបន្តួចថ្មី"
  ],
  [
   "用途／事項",
   "Purpose",
   "គោលបំណង"
  ],
  [
   "申請金額（USD）",
   "Requested amount (USD)",
   "ចំនួនទឹកប្រាក់ស្នើ (USD)"
  ],
  [
   "收款對象",
   "Payee",
   "អ្នកទទួលប្រាក់"
  ],
  [
   "說明與單據資訊",
   "Explanation and supporting documents",
   "ការពន្យល់និងឯកសារគាំទ្រ"
  ],
  [
   "財務另辦付款",
   "Finance arranges payment separately",
   "ហិរញ្ញវត្ថុរៀបចំការទូទាត់ដាច់ដោយឡែក"
  ],
  [
   "已核准，待財務另辦付款",
   "Approved; payment to be arranged by Finance",
   "បានអនុម័ត រង់ចាំហិរញ្ញវត្ថុទូទាត់"
  ],
  [
   "返回請款清單",
   "Back to payment requests",
   "ត្រឡប់ទៅបញ្ជីសំណើទូទាត់"
  ],
  [
   "目前沒有請款申請",
   "No payment requests yet",
   "មិនទាន់មានសំណើទូទាត់"
  ],
  [
   "請回覆參訓意願；尚未登記實際出席",
   "Please respond; actual attendance is not recorded yet",
   "សូមឆ្លើយតបបំណងចូលរួម វត្តមានពិតមិនទាន់បានកត់ត្រា"
  ]
 ]
});
