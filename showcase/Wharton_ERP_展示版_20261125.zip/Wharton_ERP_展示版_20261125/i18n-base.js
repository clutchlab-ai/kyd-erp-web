/* Offline exhibition interface translations. */
window.SFM_I18N??={};
Object.assign(window.SFM_I18N,{
 "base": [
  [
   "工作首頁",
   "Workspace",
   "ទំព័រការងារ"
  ],
  [
   "員工與組織",
   "People & organization",
   "បុគ្គលិក និងអង្គភាព"
  ],
  [
   "財務與薪資",
   "Finance & payroll",
   "ហិរញ្ញវត្ថុ និងប្រាក់ខែ"
  ],
  [
   "採購管理",
   "Purchasing",
   "ការទិញ"
  ],
  [
   "專案交辦",
   "Administrative tasks",
   "កិច្ចការរដ្ឋបាល"
  ],
  [
   "假勤申請",
   "Leave requests",
   "សំណើសុំច្បាប់"
  ],
  [
   "文件資料",
   "Documents",
   "ឯកសារ"
  ],
  [
   "PMS 串接",
   "PMS connection",
   "ការតភ្ជាប់ PMS"
  ],
  [
   "系統設定",
   "Settings",
   "ការកំណត់"
  ],
  [
   "全部公司",
   "All authorized companies",
   "ក្រុមហ៊ុនដែលបានអនុញ្ញាតទាំងអស់"
  ],
  [
   "歸屬公司",
   "Company",
   "ក្រុមហ៊ុន"
  ],
  [
   "公司",
   "Company",
   "ក្រុមហ៊ុន"
  ],
  [
   "登入",
   "Sign in",
   "ចូលប្រើ"
  ],
  [
   "帳號",
   "Email",
   "អ៊ីមែល"
  ],
  [
   "在職員工",
   "Active employees",
   "បុគ្គលិកកំពុងបម្រើការ"
  ],
  [
   "離職紀錄",
   "Former employees",
   "បុគ្គលិកដែលបានចាកចេញ"
  ],
  [
   "已授權公司",
   "Authorized companies",
   "ក្រុមហ៊ុនដែលបានអនុញ្ញាត"
  ],
  [
   "已存草稿",
   "Saved drafts",
   "សេចក្តីព្រាងដែលបានរក្សាទុក"
  ],
  [
   "公司人員概況",
   "Company overview",
   "ទិដ្ឋភាពទូទៅនៃក្រុមហ៊ុន"
  ],
  [
   "常用工作",
   "Quick access",
   "ការងារដែលប្រើញឹកញាប់"
  ],
  [
   "查看員工與任職資料",
   "View employee profiles",
   "មើលព័ត៌មានបុគ្គលិក"
  ],
  [
   "按公司核對薪資資料",
   "Review payroll by company",
   "ពិនិត្យប្រាក់ខែតាមក្រុមហ៊ុន"
  ],
  [
   "建立採購申請",
   "Create a purchase request",
   "បង្កើតសំណើទិញ"
  ],
  [
   "管理登入與使用權限",
   "Manage accounts and permissions",
   "គ្រប់គ្រងគណនី និងសិទ្ធិ"
  ],
  [
   "員工",
   "Employee",
   "បុគ្គលិក"
  ],
  [
   "人資",
   "HR",
   "ធនធានមនុស្ស"
  ],
  [
   "財務",
   "Finance",
   "ហិរញ្ញវត្ថុ"
  ],
  [
   "主管",
   "Manager",
   "អ្នកគ្រប់គ្រង"
  ],
  [
   "經營主管",
   "Executive",
   "ថ្នាក់ដឹកនាំ"
  ],
  [
   "系統管理員",
   "Administrator",
   "អ្នកគ្រប់គ្រងប្រព័ន្ធ"
  ],
  [
   "部門",
   "Department",
   "ផ្នែក"
  ],
  [
   "職務",
   "Job title",
   "មុខតំណែង"
  ],
  [
   "狀態",
   "Status",
   "ស្ថានភាព"
  ],
  [
   "在職",
   "Active",
   "កំពុងបម្រើការ"
  ],
  [
   "離職",
   "Departed",
   "បានចាកចេញ"
  ],
  [
   "所有狀態",
   "All statuses",
   "គ្រប់ស្ថានភាព"
  ],
  [
   "搜尋姓名、編號、部門",
   "Search name, ID or department",
   "ស្វែងរកឈ្មោះ លេខសម្គាល់ ឬផ្នែក"
  ],
  [
   "筆資料",
   "records",
   "កំណត់ត្រា"
  ],
  [
   "查看",
   "View",
   "មើល"
  ],
  [
   "返回員工清單",
   "Back to people",
   "ត្រឡប់ទៅបញ្ជីបុគ្គលិក"
  ],
  [
   "編輯任職資料",
   "Edit assignment",
   "កែប្រែព័ត៌មានការងារ"
  ],
  [
   "員工編號",
   "Employee number",
   "លេខបុគ្គលិក"
  ],
  [
   "英文姓名",
   "English name",
   "ឈ្មោះអង់គ្លេស"
  ],
  [
   "姓名",
   "Display name",
   "ឈ្មោះ"
  ],
  [
   "到職日期",
   "Joined",
   "កាលបរិច្ឆេទចូលធ្វើការ"
  ],
  [
   "離職日期",
   "Departed",
   "កាលបរិច្ឆេទចាកចេញ"
  ],
  [
   "直屬主管",
   "Line manager",
   "អ្នកគ្រប់គ្រងផ្ទាល់"
  ],
  [
   "支援項目",
   "Service projects",
   "គម្រោងដែលគាំទ្រ"
  ],
  [
   "待設定",
   "Not configured",
   "មិនទាន់កំណត់"
  ],
  [
   "未提供",
   "Not recorded",
   "មិនទាន់មាន"
  ],
  [
   "原始資料來源",
   "Source record",
   "ប្រភពទិន្នន័យ"
  ],
  [
   "薪資歸屬",
   "Payroll company",
   "ក្រុមហ៊ុនបើកប្រាក់ខែ"
  ],
  [
   "返回",
   "Back",
   "ត្រឡប់"
  ],
  [
   "應收款",
   "Receivables",
   "ប្រាក់ត្រូវទទួល"
  ],
  [
   "應付款",
   "Payables",
   "ប្រាក់ត្រូវបង់"
  ],
  [
   "薪資資料",
   "Payroll data",
   "ទិន្នន័យប្រាក់ខែ"
  ],
  [
   "基本薪資",
   "Base salary",
   "ប្រាក់ខែគោល"
  ],
  [
   "津貼",
   "Allowance",
   "ប្រាក់ឧបត្ថម្ភ"
  ],
  [
   "服務費",
   "Service charge",
   "ប្រាក់សេវា"
  ],
  [
   "已知基本薪資合計",
   "Known basic salaries",
   "សរុបប្រាក់ខែគោលដែលបានផ្តល់"
  ],
  [
   "基本薪資待補",
   "Missing basic salary",
   "ប្រាក់ខែគោលមិនទាន់មាន"
  ],
  [
   "薪資公司數",
   "Payroll companies",
   "ក្រុមហ៊ុនបើកប្រាក់ខែ"
  ],
  [
   "新增草稿",
   "New draft",
   "សេចក្តីព្រាងថ្មី"
  ],
  [
   "尚無紀錄",
   "No records yet",
   "មិនទាន់មានកំណត់ត្រា"
  ],
  [
   "找不到資料",
   "No matching records",
   "រកមិនឃើញទិន្នន័យ"
  ],
  [
   "主旨",
   "Title",
   "ចំណងជើង"
  ],
  [
   "往來對象",
   "Counterparty",
   "ដៃគូ"
  ],
  [
   "金額",
   "Amount",
   "ចំនួនទឹកប្រាក់"
  ],
  [
   "建立時間",
   "Created",
   "កាលបរិច្ឆេទបង្កើត"
  ],
  [
   "草稿",
   "Draft",
   "ព្រាង"
  ],
  [
   "作廢",
   "Void",
   "ទុកជាមោឃៈ"
  ],
  [
   "備註",
   "Notes",
   "កំណត់ចំណាំ"
  ],
  [
   "儲存",
   "Save",
   "រក្សាទុក"
  ],
  [
   "取消",
   "Cancel",
   "បោះបង់"
  ],
  [
   "關閉",
   "Off",
   "បិទ"
  ],
  [
   "儲存成功",
   "Saved",
   "បានរក្សាទុក"
  ],
  [
   "新增帳號",
   "Create account",
   "បង្កើតគណនី"
  ],
  [
   "權限角色",
   "Permission role",
   "តួនាទី និងសិទ្ធិ"
  ],
  [
   "啟用",
   "Enable",
   "បើក"
  ],
  [
   "停用",
   "Disabled",
   "បិទ"
  ],
  [
   "已停用",
   "Disabled",
   "បិទ"
  ],
  [
   "重新啟用",
   "Enable",
   "បើកឡើងវិញ"
  ],
  [
   "操作紀錄",
   "Activity log",
   "កំណត់ត្រាសកម្មភាព"
  ],
  [
   "操作者",
   "Actor",
   "អ្នកធ្វើសកម្មភាព"
  ],
  [
   "操作",
   "Action",
   "សកម្មភាព"
  ],
  [
   "對象",
   "Record",
   "កំណត់ត្រា"
  ],
  [
   "公司範圍",
   "Company access",
   "សិទ្ធិចូលប្រើក្រុមហ៊ុន"
  ],
  [
   "起始日期",
   "Start date",
   "ថ្ងៃចាប់ផ្តើម"
  ],
  [
   "結束日期",
   "End date",
   "ថ្ងៃបញ្ចប់"
  ],
  [
   "打卡與考勤",
   "Time & attendance",
   "វត្តមាន និងការចុះម៉ោង"
  ],
  [
   "尚未啟用",
   "Not enabled",
   "មិនទាន់បើកប្រើ"
  ],
  [
   "已確認有資料",
   "Listed in roster",
   "បានកត់ក្នុងបញ្ជី"
  ],
  [
   "待核對",
   "To verify",
   "ត្រូវពិនិត្យ"
  ],
  [
   "內部使用版",
   "Internal workspace",
   "ប្រព័ន្ធប្រើប្រាស់ផ្ទៃក្នុង"
  ],
  [
   "僅此電腦可連線",
   "Access on this Mac only",
   "អាចចូលបានតែលើ Mac នេះ"
  ],
  [
   "歡迎回來",
   "Welcome back",
   "សូមស្វាគមន៍"
  ],
  [
   "所有資料按授權公司顯示。",
   "Data is limited to authorized companies.",
   "ទិន្នន័យបង្ហាញតាមក្រុមហ៊ុនដែលបានអនុញ្ញាត។"
  ],
  [
   "任職公司與支援項目分開管理。",
   "Employer and service projects are managed separately.",
   "ក្រុមហ៊ុននិយោជក និងគម្រោងដែលគាំទ្រត្រូវបានគ្រប់គ្រងដាច់ដោយឡែក។"
  ],
  [
   "目前只顯示實際匯入與已保存的資料。",
   "Only imported and saved records are shown.",
   "បង្ហាញតែទិន្នន័យដែលបាននាំចូល និងរក្សាទុក។"
  ],
  [
   "從真實單據開始建立，尚未入帳或付款。",
   "Start from a real document. Drafts are not posted or paid.",
   "ចាប់ផ្តើមពីឯកសារពិត។ សេចក្តីព្រាងមិនទាន់កត់ត្រាគណនេយ្យ ឬទូទាត់ទេ។"
  ],
  [
   "這份名冊未提供資料。",
   "Not supplied in the roster.",
   "បញ្ជីនេះមិនបានផ្តល់ទិន្នន័យ។"
  ],
  [
   "先選公司，再核對人員與金額。",
   "Select a company, then review people and amounts.",
   "ជ្រើសក្រុមហ៊ុន រួចពិនិត្យបុគ្គលិក និងចំនួនទឹកប្រាក់។"
  ],
  [
   "這是名冊中的薪資基礎資料，尚未計算考勤、扣款、稅金與實發薪資。",
   "These are roster payroll inputs, not net pay. Attendance, deductions and tax are not calculated.",
   "នេះជាទិន្នន័យប្រាក់ខែពីបញ្ជី មិនមែនប្រាក់ខែសុទ្ធទេ។ វត្តមាន ការកាត់ប្រាក់ និងពន្ធមិនទាន់គណនា។"
  ],
  [
   "服務費獨立列示，尚未併入計薪。",
   "Service charges are listed separately and are not included in payroll calculations.",
   "ប្រាក់សេវាត្រូវបានបង្ហាញដាច់ដោយឡែក មិនទាន់បញ្ចូលក្នុងការគណនាប្រាក់ខែ។"
  ],
  [
   "不指定",
   "Unassigned",
   "មិនទាន់ចាត់តាំង"
  ],
  [
   "不改變任職公司與薪資歸屬。",
   "This does not change the employer or payroll company.",
   "នេះមិនផ្លាស់ប្តូរក្រុមហ៊ុននិយោជក ឬក្រុមហ៊ុនបើកប្រាក់ខែទេ។"
  ],
  [
   "業主結算",
   "Owner settlements",
   "ការទូទាត់ជូនម្ចាស់"
  ],
  [
   "項目收費規則",
   "Project billing rules",
   "ច្បាប់គិតថ្លៃគម្រោង"
  ],
  [
   "項目",
   "Field",
   "ព័ត៌មាន"
  ],
  [
   "出帳公司",
   "Billing company",
   "ក្រុមហ៊ុនចេញវិក្កយបត្រ"
  ],
  [
   "收費對象",
   "Charge to",
   "អ្នកត្រូវបង់"
  ],
  [
   "收費項目",
   "Fee item",
   "ប្រភេទថ្លៃ"
  ],
  [
   "收款方式",
   "Collection method",
   "វិធីទទួលប្រាក់"
  ],
  [
   "業主姓名",
   "Owner name",
   "ឈ្មោះម្ចាស់"
  ],
  [
   "結算週期",
   "Settlement frequency",
   "រយៈពេលទូទាត់"
  ],
  [
   "結算單語言",
   "Statement language",
   "ភាសារបាយការណ៍"
  ],
  [
   "撥款方式",
   "Payout method",
   "វិធីបង់ប្រាក់"
  ],
  [
   "租客",
   "Tenant",
   "អ្នកជួល"
  ],
  [
   "託管業主",
   "Managed owner",
   "ម្ចាស់ដែលប្រគល់ការគ្រប់គ្រង"
  ],
  [
   "自用或自行委託房仲業主",
   "Self-use / own-agent owner",
   "ម្ចាស់ប្រើផ្ទាល់ ឬមានភ្នាក់ងារផ្ទាល់"
  ],
  [
   "本地銀行轉帳",
   "Local bank transfer",
   "ផ្ទេរប្រាក់តាមធនាគារក្នុងស្រុក"
  ],
  [
   "海外匯款",
   "Overseas remittance",
   "ផ្ទេរប្រាក់ទៅក្រៅប្រទេស"
  ],
  [
   "現金",
   "Cash",
   "សាច់ប្រាក់"
  ],
  [
   "從租金中扣除",
   "Deduct from rent",
   "កាត់ពីប្រាក់ជួល"
  ],
  [
   "月結",
   "Monthly",
   "ប្រចាំខែ"
  ],
  [
   "季結",
   "Quarterly",
   "ប្រចាំត្រីមាស"
  ],
  [
   "半年結",
   "Half-yearly",
   "រៀងរាល់កន្លះឆ្នាំ"
  ],
  [
   "年結",
   "Yearly",
   "ប្រចាំឆ្នាំ"
  ],
  [
   "請選擇",
   "Select",
   "ជ្រើសរើស"
  ],
  [
   "一般業務（不屬物業項目）",
   "General business (no property project)",
   "អាជីវកម្មទូទៅ"
  ],
  [
   "租金",
   "Rent",
   "ថ្លៃជួល"
  ],
  [
   "管理費（出租期間）",
   "Management fee — leased",
   "ថ្លៃគ្រប់គ្រងពេលជួល"
  ],
  [
   "管理費（空置期間）",
   "Management fee — vacant",
   "ថ្លៃគ្រប់គ្រងពេលទំនេរ"
  ],
  [
   "管理費",
   "Management fee",
   "ថ្លៃគ្រប់គ្រង"
  ],
  [
   "水電費",
   "Utilities",
   "ថ្លៃទឹកភ្លើង"
  ],
  [
   "廠區費",
   "Cleaning fee",
   "ថ្លៃសម្អាត"
  ],
  [
   "維修費",
   "Repair fee",
   "ថ្លៃជួសជុល"
  ],
  [
   "停車費",
   "Parking fee",
   "ថ្លៃចំណត"
  ],
  [
   "押金",
   "Deposit",
   "ប្រាក់កក់"
  ],
  [
   "門禁卡押金",
   "Access card deposit",
   "ប្រាក់កក់កាតចូល"
  ],
  [
   "其他服務費",
   "Other service fees",
   "ថ្លៃសេវាផ្សេង"
  ],
  [
   "託管服務費",
   "Management service fee",
   "ថ្លៃសេវាគ្រប់គ្រង"
  ],
  [
   "代租佣金",
   "Letting commission",
   "កម្រៃជើងសារជួល"
  ],
  [
   "年度保險費",
   "Annual insurance",
   "ថ្លៃធានារ៉ាប់រងប្រចាំឆ្នាំ"
  ],
  [
   "代購用品或維護費",
   "Procurement or maintenance",
   "ថ្លៃទិញសម្ភារៈ ឬថែទាំ"
  ],
  [
   "網路費",
   "Internet fee",
   "ថ្លៃអ៊ីនធឺណិត"
  ],
  [
   "由項目自動帶入",
   "Set by project",
   "កំណត់តាមគម្រោង"
  ],
  [
   "一般業務可自行選擇公司。",
   "Select the company for general business.",
   "សូមជ្រើសក្រុមហ៊ុនសម្រាប់អាជីវកម្មទូទៅ។"
  ],
  [
   "項目決定出帳公司；不改變員工的薪資歸屬。",
   "The project determines billing; payroll employment is unchanged.",
   "គម្រោងកំណត់ក្រុមហ៊ុនចេញវិក្កយបត្រ មិនផ្លាស់ប្តូរក្រុមហ៊ុនបើកប្រាក់ខែទេ។"
  ],
  [
   "有轉錯帳戶？記錄收款核對資料",
   "Wrong account? Record a reconciliation note",
   "ផ្ទេរខុសគណនី? កត់ត្រាសម្រាប់ពិនិត្យ"
  ],
  [
   "實際收款公司",
   "Actual receiving company",
   "ក្រុមហ៊ុនទទួលប្រាក់ពិត"
  ],
  [
   "應收帳戶備註",
   "Expected account reference",
   "កំណត់សម្គាល់គណនីត្រូវទទួល"
  ],
  [
   "實際入帳帳戶備註",
   "Actual account reference",
   "កំណត់សម្គាល់គណនីបានទទួល"
  ],
  [
   "轉錯帳戶",
   "Wrong account",
   "ផ្ទេរខុសគណនី"
  ],
  [
   "收款核對備註",
   "Reconciliation note",
   "កំណត់សម្គាល់ផ្ទៀងផ្ទាត់"
  ],
  [
   "轉帳待核對",
   "Transfer needs review",
   "ត្រូវពិនិត្យការផ្ទេរ"
  ],
  [
   "只記錄待核對事項，保留原出帳公司，不會自動調帳或移轉款項。",
   "This records an exception. The billing company is preserved; no journal or funds are moved.",
   "កត់ត្រាតែបញ្ហាដែលត្រូវពិនិត្យ។ មិនកែគណនេយ្យ ឬផ្ទេរប្រាក់ដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "稅率待財務確認；此金額不會自動加稅或扣稅。",
   "Tax rules need finance review. No tax is added or withheld automatically.",
   "អត្រាពន្ធត្រូវការពិនិត្យ។ មិនបន្ថែម ឬកាត់ពន្ធដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "結算幣別：USD。先建立結算資料；尚未計算扣款、扣繳稅或實際撥款。",
   "Currency: USD. Save settlement details first; deductions, withholding and payouts are not executed.",
   "រូបិយប័ណ្ណ៖ USD។ រក្សាទុកព័ត៌មានទូទាត់ជាមុន មិនគណនាការកាត់ប្រាក់ ពន្ធ ឬបង់ប្រាក់នៅឡើយ។"
  ],
  [
   "此階段儲存為草稿。簽核流程尚未啟用，不會自動送審、入帳或付款。",
   "Saved as draft; no approval, posting or payment is executed.",
   "រក្សាទុកជាសេចក្តីព្រាង មិនអនុម័ត កត់ត្រាគណនេយ្យ ឬទូទាត់ទេ។"
  ],
  [
   "設定來源",
   "Configuration source",
   "ប្រភពការកំណត់"
  ],
  [
   "已確認的是作業規則；實際交易仍需由經辦人建立。",
   "Confirmed operating rules; staff must create actual transactions.",
   "ច្បាប់ការងារបានបញ្ជាក់ ប៉ុន្តែប្រតិបត្តិការពិតត្រូវបង្កើតដោយបុគ្គលិក។"
  ],
  [
   "以下已依客戶回覆設定。PMS 資料同步尚未連線。",
   "Configured from the client response. PMS synchronization is not connected.",
   "បានកំណត់តាមចម្លើយអតិថិជន។ PMS មិនទាន់ភ្ជាប់ទេ។"
  ],
  [
   "尚未連線",
   "Not connected",
   "មិនទាន់ភ្ជាប់"
  ],
  [
   "商辦",
   "Office building",
   "អគារការិយាល័យ"
  ],
  [
   "公寓",
   "Apartments",
   "អាផាតមិន"
  ],
  [
   "部分房源提供短租",
   "Some units offer short stays",
   "បន្ទប់ខ្លះផ្តល់ការជួលខ្លី"
  ],
  [
   "目前不提供短租",
   "No short stays currently",
   "បច្ចុប្បន្នមិនមានការជួលខ្លី"
  ],
  [
   "會議中心",
   "Meeting center",
   "មជ្ឈមណ្ឌលប្រជុំ"
  ],
  [
   "每月 20 元月租金 1 點",
   "1 monthly point per 20 rent units (currency to confirm)",
   "១ ពិន្ទុប្រចាំខែ សម្រាប់ថ្លៃជួល ២០ ឯកតា (រូបិយប័ណ្ណត្រូវបញ្ជាក់)"
  ],
  [
   "加購：每點 USD 2；亦提供外部客戶租用。",
   "Extra points: USD 2 each. External customers may also book.",
   "ពិន្ទុបន្ថែម៖ USD 2 ក្នុងមួយពិន្ទុ។ អតិថិជនខាងក្រៅអាចជួលបាន។"
  ],
  [
   "免費點數的幣別、尾數及有效期待確認，尚未自動計算。",
   "Free-point currency, rounding and expiry need confirmation. No automatic calculation.",
   "រូបិយប័ណ្ណ ការបង្គត់ និងថ្ងៃផុតកំណត់ពិន្ទុត្រូវបញ្ជាក់។ មិនគណនាស្វ័យប្រវត្តិទេ។"
  ],
  [
   "23 樓共享辦公室短租：僅為未來考慮。",
   "Floor 23 coworking short rental is a future consideration only.",
   "ការជួលខ្លីការិយាល័យរួមជាន់ទី ២៣ ជាការពិចារណាអនាគតប៉ុណ្ណោះ។"
  ],
  [
   "廠區排班依據",
   "Housekeeping schedule basis",
   "មូលដ្ឋានកាលវិភាគសម្អាត"
  ],
  [
   "已記錄頻率；詳細排班待提供，尚未產生工作單。",
   "Frequencies recorded. Detailed schedules are pending; no work orders generated.",
   "បានកត់ប្រេកង់ការងារ។ កាលវិភាគលម្អិតមិនទាន់មាន និងមិនបង្កើតបញ្ជាការងារ។"
  ],
  [
   "公共區域",
   "Common areas",
   "តំបន់រួម"
  ],
  [
   "公寓委託單位",
   "Managed apartments",
   "អាផាតមិនគ្រប់គ្រង"
  ],
  [
   "商辦委託單位",
   "Managed offices",
   "ការិយាល័យគ្រប់គ្រង"
  ],
  [
   "公共垃圾收取",
   "Common garbage collection",
   "ប្រមូលសំរាមរួម"
  ],
  [
   "消毒殺蟲",
   "Pest control",
   "កម្ចាត់សត្វល្អិត"
  ],
  [
   "依內容而定",
   "Depends on the task",
   "អាស្រ័យលើការងារ"
  ],
  [
   "每週一次",
   "Once a week",
   "ម្តងក្នុងមួយសប្តាហ៍"
  ],
  [
   "每日兩次",
   "Twice a day",
   "ពីរដងក្នុងមួយថ្ងៃ"
  ],
  [
   "待確認事項",
   "Decisions still needed",
   "ចំណុចត្រូវបញ្ជាក់"
  ],
  [
   "建立應收款時，選項會依項目及收費對象自動調整。",
   "Receivable options follow the selected project and counterparty type.",
   "ជម្រើសប្រាក់ត្រូវទទួលផ្លាស់ប្តូរតាមគម្រោង និងអ្នកត្រូវបង់។"
  ],
  [
   "稅務資料待確認",
   "Tax information needs review",
   "ព័ត៌មានពន្ធត្រូវពិនិត្យ"
  ],
  [
   "以下是客戶提供的回覆，尚未作為自動計稅或扣繳依據。",
   "Customer-supplied statements below are not applied to automatic tax or withholding.",
   "ចម្លើយអតិថិជនខាងក្រោមមិនអនុវត្តសម្រាប់គណនាពន្ធស្វ័យប្រវត្តិទេ។"
  ],
  [
   "審計資料需求",
   "Audit information required",
   "ទិន្នន័យត្រូវការសម្រាប់សវនកម្ម"
  ],
  [
   "已記錄需求；財務報表與固定資產模組尚未建置，不會顯示為已完成。",
   "Requirements recorded. Financial statements and fixed assets are not implemented yet.",
   "បានកត់តម្រូវការ។ របាយការណ៍ហិរញ្ញវត្ថុ និងទ្រព្យថេរមិនទាន់បង្កើត។"
  ],
  [
   "是",
   "Yes",
   "បាទ/ចាស"
  ],
  [
   "否",
   "No",
   "ទេ"
  ],
  [
   "幣別",
   "Currency",
   "រូបិយប័ណ្ណ"
  ],
  [
   "規則版本",
   "Rules version",
   "កំណែច្បាប់"
  ],
  [
   "收款核對",
   "Collection review",
   "ពិនិត្យការទទួលប្រាក់"
  ],
  [
   "稅務核對",
   "Tax review",
   "ពិនិត្យពន្ធ"
  ],
  [
   "待核對（尚未調帳）",
   "Pending review (not adjusted)",
   "រង់ចាំពិនិត្យ (មិនកែគណនេយ្យ)"
  ],
  [
   "已記錄（尚未對帳）",
   "Recorded (not reconciled)",
   "បានកត់ត្រា (មិនទាន់ផ្ទៀងផ្ទាត់)"
  ],
  [
   "待財務確認（未計稅）",
   "Finance review pending (tax not calculated)",
   "រង់ចាំហិរញ្ញវត្ថុ (មិនគណនាពន្ធ)"
  ],
  [
   "請先選擇項目，系統會帶入出帳公司。",
   "Select a project to set its billing company.",
   "ជ្រើសគម្រោង ដើម្បីកំណត់ក្រុមហ៊ុនចេញវិក្កយបត្រ។"
  ],
  [
   "已離職",
   "Departed",
   "បានចាកចេញ"
  ],
  [
   "財務功能",
   "Finance functions",
   "មុខងារហិរញ្ញវត្ថុ"
  ],
  [
   "財務與會計",
   "Finance & accounting",
   "ហិរញ្ញវត្ថុ និងគណនេយ្យ"
  ],
  [
   "先選公司；輸入、複核、核准完成後，再正式入帳。",
   "Select a company. Prepare, review and approve before posting.",
   "ជ្រើសក្រុមហ៊ុន រៀបចំ ពិនិត្យ អនុម័ត រួចកត់ត្រា។"
  ],
  [
   "帳套待確認",
   "Book not configured",
   "មិនទាន់កំណត់បញ្ជី"
  ],
  [
   "進入這家公司 →",
   "Open this company →",
   "ចូលក្រុមហ៊ុននេះ →"
  ],
  [
   "沒有帳務權限",
   "No accounting access",
   "គ្មានសិទ្ធិគណនេយ្យ"
  ],
  [
   "小數",
   "Decimals",
   "ខ្ទង់ទសភាគ"
  ],
  [
   "先確認這家公司的帳套",
   "Confirm this company’s book first",
   "បញ្ជាក់បញ្ជីក្រុមហ៊ុននេះជាមុន"
  ],
  [
   "需要財務確認幣別、起始日、科目表與簽核職位。沒有預填金額或替公司指派人員。",
   "Finance must confirm currency, start date, accounts and approval roles. No balances or assignments are prefilled.",
   "ត្រូវបញ្ជាក់រូបិយប័ណ្ណ ថ្ងៃចាប់ផ្តើម គណនី និងអ្នកអនុម័ត។ មិនបំពេញសមតុល្យឬបុគ្គលិកជាមុនទេ។"
  ],
  [
   "設定帳套與簽核",
   "Configure book & approvals",
   "កំណត់បញ្ជី និងអនុម័ត"
  ],
  [
   "① 填寫傳票",
   "① Prepare",
   "① រៀបចំ"
  ],
  [
   "② 複核／修改",
   "② Review / revise",
   "② ពិនិត្យ / កែ"
  ],
  [
   "③ 核准",
   "③ Approve",
   "③ អនុម័ត"
  ],
  [
   "④ 入帳、產生報表",
   "④ Post → reports",
   "④ កត់ត្រា → របាយការណ៍"
  ],
  [
   "新增傳票",
   "New voucher",
   "បន្ថែមប័ណ្ណ"
  ],
  [
   "傳票／摘要",
   "Voucher / description",
   "ប័ណ្ណ / សេចក្តីសង្ខេប"
  ],
  [
   "日期",
   "Date",
   "កាលបរិច្ឆេទ"
  ],
  [
   "期初餘額",
   "Opening balances",
   "សមតុល្យដើម"
  ],
  [
   "沖回",
   "Reversal",
   "ត្រឡប់"
  ],
  [
   "只有已入帳傳票會進入報表；核准不代表已付款。已入帳資料以沖回傳票更正，保留原紀錄。",
   "Only posted vouchers appear in reports. Approval is not payment. Correct posted entries with a linked reversal.",
   "របាយការណ៍ប្រើតែប័ណ្ណបានកត់ត្រា។ អនុម័តមិនមែនទូទាត់។ កែដោយប័ណ្ណត្រឡប់ និងរក្សាដើម។"
  ],
  [
   "帳套與作業規則",
   "Book and operating rules",
   "បញ្ជី និងច្បាប់ការងារ"
  ],
  [
   "起始日",
   "Opening date",
   "ថ្ងៃចាប់ផ្តើម"
  ],
  [
   "已結帳至",
   "Closed through",
   "បិទដល់"
  ],
  [
   "複核",
   "Review",
   "ពិនិត្យ"
  ],
  [
   "核准",
   "Approve",
   "អនុម័ត"
  ],
  [
   "尚未設定，不會自動指定人員或幣別。",
   "Not configured. No people or currency are assigned automatically.",
   "មិនទាន់កំណត់។ មិនចាត់តាំងមនុស្សឬរូបិយប័ណ្ណដោយស្វ័យប្រវត្តិ។"
  ],
  [
   "鎖定已結帳期間",
   "Close accounting period",
   "បិទរយៈពេលគណនេយ្យ"
  ],
  [
   "待財務確認的細則",
   "Finance decisions still needed",
   "ចំណុចហិរញ្ញវត្ថុត្រូវបញ្ជាក់"
  ],
  [
   "正式科目表、期初餘額與報表格式。",
   "Official chart, opening balances and report layouts.",
   "បញ្ជីគណនី សមតុល្យដើម និងទម្រង់របាយការណ៍។"
  ],
  [
   "實際複核、核准、入帳人員與金額門檻。",
   "Actual reviewers, approvers, posting operators and amount thresholds.",
   "អ្នកពិនិត្យ អ្នកអនុម័ត អ្នកកត់ត្រា និងកម្រិតទឹកប្រាក់។"
  ],
  [
   "外幣換算、稅務、薪資計算及 PMS 正式串接規格。",
   "Foreign exchange, tax, payroll calculation and the PMS integration contract.",
   "ប្តូររូបិយប័ណ្ណ ពន្ធ គណនាប្រាក់ខែ និងការតភ្ជាប់ PMS។"
  ],
  [
   "這些規則尚未自動計算；目前帳套採一家公司一個明確的記帳幣別。",
   "These rules are not calculated automatically. Each company uses one explicitly configured book currency.",
   "ច្បាប់ទាំងនេះមិនគណនាដោយស្វ័យប្រវត្តិ។ ក្រុមហ៊ុននីមួយៗប្រើរូបិយប័ណ្ណបញ្ជីដែលបានកំណត់។"
  ],
  [
   "新增科目",
   "New account",
   "បន្ថែមគណនី"
  ],
  [
   "搜尋代碼或名稱",
   "Find code or name",
   "ស្វែងរកលេខ ឬឈ្មោះ"
  ],
  [
   "輸入代碼開頭或科目名稱",
   "Enter code prefix or account name",
   "បញ្ចូលលេខដើម ឬឈ្មោះគណនី"
  ],
  [
   "代碼",
   "Code",
   "លេខកូដ"
  ],
  [
   "科目名稱",
   "Account name",
   "ឈ្មោះគណនី"
  ],
  [
   "分類／性質",
   "Type / normal balance",
   "ប្រភេទ / សមតុល្យ"
  ],
  [
   "上層科目",
   "Parent account",
   "គណនីមេ"
  ],
  [
   "可入帳明細",
   "Posting account",
   "គណនីកត់ត្រា"
  ],
  [
   "彙總科目",
   "Group account",
   "គណនីក្រុម"
  ],
  [
   "借",
   "Debit",
   "ឥណពន្ធ"
  ],
  [
   "貸",
   "Credit",
   "ឥណទាន"
  ],
  [
   "編輯",
   "Edit",
   "កែប្រែ"
  ],
  [
   "科目由財務建立或從 CSV 匯入。已使用的科目保留代碼與分類，停用後不可新增分錄。",
   "Finance creates accounts or imports CSV. Used codes and classifications remain fixed; disabled accounts reject new entries.",
   "ហិរញ្ញវត្ថុបង្កើតគណនី ឬនាំចូល CSV។ លេខ និងប្រភេទដែលប្រើរួចមិនប្តូរ; គណនីបិទមិនទទួលកំណត់ត្រាថ្មី។"
  ],
  [
   "返回傳票清單",
   "Back to vouchers",
   "ត្រឡប់ទៅបញ្ជីប័ណ្ណ"
  ],
  [
   "來源申請",
   "Source request",
   "សំណើប្រភព"
  ],
  [
   "關聯沖回紀錄",
   "Related reversal",
   "កំណត់ត្រាត្រឡប់"
  ],
  [
   "科目",
   "Account",
   "គណនី"
  ],
  [
   "摘要",
   "Line description",
   "សង្ខេប"
  ],
  [
   "借方",
   "Debit",
   "ឥណពន្ធ"
  ],
  [
   "貸方",
   "Credit",
   "ឥណទាន"
  ],
  [
   "借貸合計",
   "Debit / credit totals",
   "សរុបឥណពន្ធ / ឥណទាន"
  ],
  [
   "截止日期",
   "Through",
   "រហូតដល់"
  ],
  [
   "更新報表",
   "Run report",
   "បង្ហាញរបាយការណ៍"
  ],
  [
   "只包含已入帳資料",
   "Posted entries only",
   "តែកំណត់ត្រាបានកត់ត្រា"
  ],
  [
   "張傳票",
   "vouchers",
   "ប័ណ្ណ"
  ],
  [
   "下載此報表 CSV",
   "Download report CSV",
   "ទាញយករបាយការណ៍ CSV"
  ],
  [
   "日期／傳票",
   "Date / voucher",
   "កាលបរិច្ឆេទ / ប័ណ្ណ"
  ],
  [
   "借方餘額",
   "Debit balance",
   "សមតុល្យឥណពន្ធ"
  ],
  [
   "本期收入",
   "Period revenue",
   "ចំណូលរយៈពេល"
  ],
  [
   "本期費用",
   "Period expenses",
   "ចំណាយរយៈពេល"
  ],
  [
   "本期損益",
   "Period result",
   "លទ្ធផលរយៈពេល"
  ],
  [
   "分類",
   "Category",
   "ប្រភេទ"
  ],
  [
   "本期金額",
   "Period amount",
   "ចំនួនរយៈពេល"
  ],
  [
   "資產",
   "Assets",
   "ទ្រព្យសកម្ម"
  ],
  [
   "負債",
   "Liabilities",
   "បំណុល"
  ],
  [
   "權益＋未結轉損益",
   "Equity + unclosed result",
   "មូលធន + លទ្ធផលមិនបិទ"
  ],
  [
   "未結轉損益（系統計算）",
   "Unclosed result (calculated)",
   "លទ្ធផលមិនបិទ (គណនា)"
  ],
  [
   "平衡差額",
   "Balance difference",
   "ភាពខុសគ្នាតុល្យការ"
  ],
  [
   "截止日餘額",
   "Balance at end date",
   "សមតុល្យចុងថ្ងៃ"
  ],
  [
   "依帳套科目分類計算的管理報表；法定報表格式及財務結轉規則待財務確認。",
   "Management report using configured account classifications. Statutory layouts and closing policies require finance confirmation.",
   "របាយការណ៍គ្រប់គ្រងតាមប្រភេទគណនី។ ទម្រង់ផ្លូវការ និងច្បាប់បិទត្រូវបញ្ជាក់។"
  ],
  [
   "借方餘額合計",
   "Total debit balances",
   "សរុបសមតុល្យឥណពន្ធ"
  ],
  [
   "貸方餘額合計",
   "Total credit balances",
   "សរុបសមតុល្យឥណទាន"
  ],
  [
   "期初借方餘額",
   "Opening debit balance",
   "សមតុល្យឥណពន្ធដើម"
  ],
  [
   "本期借方",
   "Period debit",
   "ឥណពន្ធរយៈពេល"
  ],
  [
   "本期貸方",
   "Period credit",
   "ឥណទានរយៈពេល"
  ],
  [
   "期末借方餘額",
   "Closing debit balance",
   "សមតុល្យឥណពន្ធចុង"
  ],
  [
   "負數表示貸方餘額。可切換總分類帳，逐筆回到原傳票。",
   "Negative values indicate credit balances. Use the general ledger to open each source voucher.",
   "លេខអវិជ្ជមានជាសមតុល្យឥណទាន។ ប្រើបញ្ជីធំដើម្បីបើកប័ណ្ណដើម។"
  ],
  [
   "傳票批次匯入",
   "Batch voucher import",
   "នាំចូលប័ណ្ណជាបាច់"
  ],
  [
   "Excel 另存 UTF-8 CSV → 上傳 → 預覽錯誤 → 確認匯入草稿。整批通過才會儲存，仍須複核、核准與入帳。",
   "Save Excel as UTF-8 CSV → upload → preview → import drafts. The whole batch must pass, then follow review, approval and posting.",
   "រក្សា Excel ជា UTF-8 CSV → ផ្ទុក → ពិនិត្យ → នាំចូលសេចក្តីព្រាង។ ត្រូវឆ្លងពិនិត្យ អនុម័ត និងកត់ត្រា។"
  ],
  [
   "下載空白 CSV 範本",
   "Download blank CSV template",
   "ទាញយកគំរូ CSV"
  ],
  [
   "匯入傳票 CSV",
   "Import voucher CSV",
   "នាំចូលប័ណ្ណ CSV"
  ],
  [
   "科目表匯入與匯出",
   "Chart import / export",
   "នាំចូល / ចេញបញ្ជីគណនី"
  ],
  [
   "依上層到下層排列；代碼相同會更新名稱與啟用狀態，已使用科目的分類不可改。",
   "Order parent accounts before children. Matching codes update names/status; used classifications remain fixed.",
   "រៀបគណនីមេមុនកូន។ លេខដូចគ្នាធ្វើបច្ចុប្បន្នភាពឈ្មោះ/ស្ថានភាព។"
  ],
  [
   "匯出科目 CSV",
   "Export accounts CSV",
   "នាំចេញគណនី CSV"
  ],
  [
   "匯入科目 CSV",
   "Import accounts CSV",
   "នាំចូលគណនី CSV"
  ],
  [
   "匯出已入帳資料",
   "Export posted entries",
   "នាំចេញកំណត់ត្រា"
  ],
  [
   "僅匯出這家公司已入帳的傳票。明細報表可在財務報表頁指定日期。",
   "Exports posted vouchers for this company only. Choose report dates on the reports page.",
   "នាំចេញតែប័ណ្ណក្រុមហ៊ុននេះដែលបានកត់ត្រា។ ជ្រើសថ្ងៃនៅទំព័ររបាយការណ៍។"
  ],
  [
   "下載已入帳傳票 CSV",
   "Download posted vouchers CSV",
   "ទាញយកប័ណ្ណ CSV"
  ],
  [
   "目前使用 Excel 可開啟的 CSV，不接受直接上傳 .xlsx。PMS 與薪資系統資料未自動匯入。",
   "Uses Excel-compatible CSV; direct .xlsx upload is not supported. PMS and payroll are not imported automatically.",
   "ប្រើ CSV សម្រាប់ Excel; មិនទទួល .xlsx ដោយផ្ទាល់។ មិននាំចូល PMS និងប្រាក់ខែដោយស្វ័យប្រវត្តិ។"
  ],
  [
   "設定公司帳套",
   "Configure company book",
   "កំណត់បញ្ជីក្រុមហ៊ុន"
  ],
  [
   "記帳幣別（3 碼，如 USD、KHR）",
   "Book currency (3 letters, e.g. USD, KHR)",
   "រូបិយប័ណ្ណ (៣តួ ឧ. USD, KHR)"
  ],
  [
   "金額小數位數",
   "Amount decimal places",
   "ចំនួនខ្ទង់ទសភាគ"
  ],
  [
   "帳套起始日／期初日",
   "Book opening date",
   "ថ្ងៃចាប់ផ្តើមបញ្ជី"
  ],
  [
   "複核職位或人員",
   "Reviewer position or person",
   "តួនាទី ឬអ្នកពិនិត្យ"
  ],
  [
   "設定依據／原因",
   "Basis / reason",
   "មូលដ្ឋាន / មូលហេតុ"
  ],
  [
   "以上帳套與簽核安排已經公司確認",
   "The company has confirmed this book and approval route",
   "ក្រុមហ៊ុនបានបញ្ជាក់បញ្ជី និងលំហូរនេះ"
  ],
  [
   "送審時，輸入、複核與各層核准必須有不同的授權人員；不會自動跳過空缺。",
   "Submission requires distinct authorized people for preparation, review and each approval level. Vacancies are never skipped.",
   "ការដាក់ស្នើត្រូវមានអ្នករៀបចំ ពិនិត្យ និងអនុម័តផ្សេងគ្នា។ មិនរំលងតួនាទីទំនេរ។"
  ],
  [
   "會計科目",
   "Account",
   "គណនី"
  ],
  [
   "科目代碼",
   "Account code",
   "លេខគណនី"
  ],
  [
   "正常餘額性質",
   "Normal balance",
   "ប្រភេទសមតុល្យ"
  ],
  [
   "上層彙總科目（選填）",
   "Parent group (optional)",
   "គណនីក្រុមមេ (ស្រេចចិត្ត)"
  ],
  [
   "科目用途",
   "Account use",
   "ការប្រើគណនី"
  ],
  [
   "明細：可以入帳",
   "Detail: posting allowed",
   "លម្អិត៖ អាចកត់ត្រា"
  ],
  [
   "彙總：不可直接入帳",
   "Group: no direct posting",
   "ក្រុម៖ មិនកត់ត្រាផ្ទាល់"
  ],
  [
   "科目代碼／名稱搜尋",
   "Account code / name search",
   "ស្វែងរកលេខ / ឈ្មោះគណនី"
  ],
  [
   "移除",
   "Remove",
   "ដកចេញ"
  ],
  [
   "請先啟用帳套。",
   "Configure the book first.",
   "កំណត់បញ្ជីជាមុន។"
  ],
  [
   "填寫傳票",
   "Prepare voucher",
   "រៀបចំប័ណ្ណ"
  ],
  [
   "傳票種類",
   "Voucher kind",
   "ប្រភេទប័ណ្ណ"
  ],
  [
   "一般傳票",
   "General voucher",
   "ប័ណ្ណទូទៅ"
  ],
  [
   "傳票日期",
   "Voucher date",
   "កាលបរិច្ឆេទប័ណ្ណ"
  ],
  [
   "傳票摘要",
   "Voucher description",
   "សង្ខេបប័ណ្ណ"
  ],
  [
   "單據／外部參考號",
   "Document / external reference",
   "ឯកសារ / លេខយោង"
  ],
  [
   "已核准來源申請（選填）",
   "Approved source request (optional)",
   "សំណើប្រភពបានអនុម័ត (ស្រេចចិត្ត)"
  ],
  [
   "來源只建立追溯關聯；請按實際業務選科目、填入借貸金額，不會自動付款或代填會計分錄。",
   "Linking retains traceability. Choose accounts and amounts for the actual transaction; no payment or automatic mapping occurs.",
   "តំណភ្ជាប់សម្រាប់តាមដាន។ ជ្រើសគណនី និងទឹកប្រាក់តាមប្រតិបត្តិការពិត; មិនទូទាត់ឬបំពេញដោយស្វ័យប្រវត្តិ។"
  ],
  [
   "新增一筆分錄",
   "Add line",
   "បន្ថែមបន្ទាត់"
  ],
  [
   "修改原因（保留原分錄）",
   "Reason for revision (original retained)",
   "មូលហេតុកែ (រក្សាដើម)"
  ],
  [
   "儲存傳票",
   "Save voucher",
   "រក្សាប័ណ្ណ"
  ],
  [
   "借方 / 貸方",
   "Debit / credit",
   "ឥណពន្ធ / ឥណទាន"
  ],
  [
   "平衡",
   "Balanced",
   "មានតុល្យភាព"
  ],
  [
   "請核對借貸金額",
   "Check debit and credit",
   "ពិនិត្យឥណពន្ធ និងឥណទាន"
  ],
  [
   "入帳後會影響財務報表，原分錄不能直接修改；更正需另建沖回傳票。此操作不會移轉款項。",
   "Posting changes the reports and makes lines immutable. Corrections require a reversal. This does not transfer funds.",
   "កត់ត្រាប្តូររបាយការណ៍ និងមិនអាចកែផ្ទាល់។ ត្រូវមានប័ណ្ណត្រឡប់។ មិនផ្ទេរប្រាក់។"
  ],
  [
   "沖回傳票日期",
   "Reversal date",
   "ថ្ងៃប័ណ្ណត្រឡប់"
  ],
  [
   "處理說明",
   "Decision note",
   "មតិការសម្រេច"
  ],
  [
   "期間內所有傳票必須已入帳或作廢。結帳後不可新增或修改該日期內的分錄；更正在之後的開放期間處理。",
   "All vouchers in the period must be posted or void. Closed dates reject new entries; corrections use a later open period.",
   "ប័ណ្ណក្នុងរយៈពេលត្រូវកត់ត្រា ឬមោឃៈ។ ថ្ងៃបិទមិនទទួលថ្មី; កែនៅរយៈពេលបើកក្រោយ។"
  ],
  [
   "結帳截至日",
   "Close through",
   "បិទរហូតដល់"
  ],
  [
   "結帳依據／原因",
   "Closing basis / reason",
   "មូលដ្ឋាន / មូលហេតុ"
  ],
  [
   "鎖定期間",
   "Close period",
   "បិទរយៈពេល"
  ],
  [
   "匯入 CSV",
   "Import CSV",
   "នាំចូល CSV"
  ],
  [
   "科目表",
   "Chart of accounts",
   "បញ្ជីគណនី"
  ],
  [
   "傳票草稿",
   "Voucher drafts",
   "ព្រាងប័ណ្ណ"
  ],
  [
   "UTF-8 CSV 檔案（最多 150 KB）",
   "UTF-8 CSV file (max 150 KB)",
   "ឯកសារ UTF-8 CSV (អតិបរមា 150 KB)"
  ],
  [
   "或貼上 CSV 內容",
   "Or paste CSV content",
   "ឬបិទភ្ជាប់ CSV"
  ],
  [
   "先檢查與預覽",
   "Validate & preview",
   "ពិនិត្យ និងមើលជាមុន"
  ],
  [
   "已核對預覽，確認匯入這家公司",
   "I reviewed the preview and confirm this company",
   "បានពិនិត្យ និងបញ្ជាក់ក្រុមហ៊ុននេះ"
  ],
  [
   "確認匯入",
   "Confirm import",
   "បញ្ជាក់នាំចូល"
  ],
  [
   "個錯誤",
   "errors",
   "កំហុស"
  ],
  [
   "第",
   "Row",
   "ជួរទី"
  ],
  [
   "檢查通過，可以確認匯入",
   "Validation passed; ready to import",
   "ពិនិត្យរួច អាចនាំចូល"
  ],
  [
   "請依順序設定核准層級。",
   "Set approval levels in order.",
   "កំណត់កម្រិតតាមលំដាប់។"
  ],
  [
   "請先預覽目前內容並修正錯誤。",
   "Preview the current content and resolve errors first.",
   "ពិនិត្យមាតិកាបច្ចុប្បន្ន និងកែកំហុសជាមុន។"
  ],
  [
   "最多 150 筆分錄。",
   "Maximum 150 lines.",
   "អតិបរមា១៥០បន្ទាត់។"
  ],
  [
   "至少保留兩筆分錄。",
   "Keep at least two lines.",
   "រក្សាយ៉ាងហោចណាស់២បន្ទាត់។"
  ],
  [
   "請選擇 150 KB 以下的 CSV。",
   "Select a CSV file under 150 KB.",
   "ជ្រើស CSV ក្រោម១៥០ KB។"
  ],
  [
   "暫編",
   "Internal ID",
   "លេខសម្គាល់បណ្តោះអាសន្ន"
  ],
  [
   "無法完成操作",
   "Unable to complete action",
   "មិនអាចបញ្ចប់សកម្មភាព"
  ],
  [
   "重新連線",
   "Reconnect",
   "ភ្ជាប់ឡើងវិញ"
  ],
  [
   "使用已開通的帳號登入。員工名冊匯入後，不會自動開通帳號。",
   "Sign in with an activated account. Importing an employee does not activate access.",
   "ចូលដោយគណនីដែលបានបើក។ ការនាំចូលបុគ្គលិកមិនបើកគណនីដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "行政人事",
   "HR & administration",
   "រដ្ឋបាល និងធនធានមនុស្ស"
  ],
  [
   "企業業務",
   "Business",
   "អាជីវកម្ម"
  ],
  [
   "財務管理",
   "Finance",
   "ហិរញ្ញវត្ថុ"
  ],
  [
   "部分可用",
   "Partly available",
   "អាចប្រើបានខ្លះ"
  ],
  [
   "待建置",
   "Not yet available",
   "មិនទាន់មាន"
  ],
  [
   "功能規劃",
   "Planned scope",
   "មុខងារដែលបានគ្រោង"
  ],
  [
   "目前可用",
   "Available now",
   "អាចប្រើឥឡូវនេះ"
  ],
  [
   "啟用前待完成",
   "Required before activation",
   "ត្រូវបំពេញមុនបើកប្រើ"
  ],
  [
   "主要使用者",
   "Intended users",
   "អ្នកប្រើសំខាន់"
  ],
  [
   "我的薪資資料",
   "My salary details",
   "ព័ត៌មានប្រាក់ខែរបស់ខ្ញុំ"
  ],
  [
   "我的資料",
   "My profile",
   "ប្រវត្តិរូបរបស់ខ្ញុំ"
  ],
  [
   "管理員無員工身分",
   "Administrator is not an employee",
   "អ្នកគ្រប់គ្រងមិនមែនជាបុគ្គលិក"
  ],
  [
   "尚未送審",
   "Not submitted",
   "មិនទាន់ដាក់ស្នើ"
  ],
  [
   "申請類型",
   "Request type",
   "ប្រភេទសំណើ"
  ],
  [
   "返回工作首頁",
   "Back to workspace",
   "ត្រឡប់ទៅទំព័រការងារ"
  ],
  [
   "行政人事功能規劃",
   "HR administration plan",
   "ផែនការរដ្ឋបាលធនធានមនុស្ស"
  ],
  [
   "全體員工",
   "All employees",
   "បុគ្គលិកទាំងអស់"
  ],
  [
   "人資、主管",
   "HR, managers",
   "HR និងអ្នកគ្រប់គ្រង"
  ],
  [
   "物業主管、員工、人資",
   "Property managers, employees, HR",
   "អ្នកគ្រប់គ្រងអចលនទ្រព្យ បុគ្គលិក និង HR"
  ],
  [
   "員工、人資、主管",
   "Employees, HR, managers",
   "បុគ្គលិក HR និងអ្នកគ្រប់គ្រង"
  ],
  [
   "員工、主管、人資",
   "Employees, managers, HR",
   "បុគ្គលិក អ្នកគ្រប់គ្រង និង HR"
  ],
  [
   "薪酬專員、授權核決者",
   "Payroll specialists, authorized approvers",
   "អ្នកជំនាញប្រាក់ខែ និងអ្នកអនុម័តដែលមានសិទ្ធិ"
  ],
  [
   "人資、證件經辦",
   "HR, document officers",
   "HR និងមន្ត្រីឯកសារ"
  ],
  [
   "人資、主管、員工",
   "HR, managers, employees",
   "HR អ្នកគ្រប់គ្រង និងបុគ្គលិក"
  ],
  [
   "員工、主管、項目負責人",
   "Employees, managers, project owners",
   "បុគ្គលិក អ្នកគ្រប់គ្រង និងម្ចាស់គម្រោង"
  ],
  [
   "分別授權",
   "Separately authorized",
   "ផ្តល់សិទ្ធិដាច់ដោយឡែក"
  ],
  [
   "我的採購申請",
   "My purchase requests",
   "សំណើទិញរបស់ខ្ញុំ"
  ],
  [
   "此頁已依行政人事選單保留功能範圍，尚未啟用作業，不會產生正式紀錄。",
   "This page records the agreed HR scope. Operations are not enabled and no official records are generated.",
   "ទំព័រនេះកត់ត្រាវិសាលភាព HR។ ប្រតិបត្តិការមិនទាន់បើក និងមិនបង្កើតកំណត់ត្រាផ្លូវការ។"
  ],
  [
   "查看自己建立的人事申請，不會顯示其他人的資料。",
   "View your own HR requests. Other employees’ requests are not shown.",
   "មើលសំណើ HR ផ្ទាល់ខ្លួន មិនបង្ហាញសំណើរបស់អ្នកដទៃ។"
  ],
  [
   "我的工作",
   "My work",
   "ការងាររបស់ខ្ញុំ"
  ],
  [
   "先處理自己的申請，再進入獲授權的管理功能。",
   "Start with your requests, then access your authorized management tools.",
   "ចាប់ផ្តើមពីសំណើផ្ទាល់ខ្លួន រួចចូលមុខងារគ្រប់គ្រងដែលមានសិទ្ធិ។"
  ],
  [
   "打卡／班表",
   "Clock-in / shifts",
   "ចុះម៉ោង / វេន"
  ],
  [
   "新增調薪申請／查看異動進度 →",
   "Salary change requests and progress →",
   "សំណើកែប្រាក់ខែ និងវឌ្ឍនភាព →"
  ],
  [
   "未授權此功能",
   "Access not granted",
   "មិនមានសិទ្ធិចូលមុខងារនេះ"
  ],
  [
   "此功能需個別授權。",
   "This function requires separate authorization.",
   "មុខងារនេះត្រូវការសិទ្ធិដាច់ដោយឡែក។"
  ],
  [
   "系統管理員（你）",
   "Administrator (you)",
   "អ្នកគ្រប់គ្រងប្រព័ន្ធ (អ្នក)"
  ],
  [
   "作業公司",
   "Work company",
   "ក្រុមហ៊ុនការងារ"
  ],
  [
   "名冊未提供員工資料",
   "No employees supplied in roster",
   "បញ្ជីមិនបានផ្តល់ទិន្នន័យបុគ្គលិក"
  ],
  [
   "財務報表只計已入帳傳票，各公司及幣別分別列示；未確認的規則保留待設定。",
   "Financial reports use posted vouchers only, with companies and currencies kept separate. Unconfirmed rules remain unconfigured.",
   "របាយការណ៍ហិរញ្ញវត្ថុប្រើតែប័ណ្ណបានកត់ត្រា ដោយក្រុមហ៊ុន និងរូបិយប័ណ្ណដាច់ដោយឡែក។ ច្បាប់មិនទាន់បញ្ជាក់នៅតែរង់ចាំ។"
  ],
  [
   "此員工不在你的授權範圍，或編號不存在。",
   "This employee is outside your access or does not exist.",
   "បុគ្គលិកនេះនៅក្រៅសិទ្ធិរបស់អ្នក ឬមិនមាន។"
  ],
  [
   "個別新增與修改以員工詳細頁和操作紀錄為準。",
   "Individual additions and changes are recorded in employee details and the activity log.",
   "ការបន្ថែម និងការកែប្រែត្រូវបានកត់ត្រាក្នុងព័ត៌មានបុគ្គលិក និងកំណត់ត្រាសកម្មភាព។"
  ],
  [
   "共享團隊可以支援不同項目；支援項目不代表由該項目的公司發薪。",
   "Shared staff may support different projects without changing their payroll employer.",
   "បុគ្គលិកអាចគាំទ្រគម្រោងផ្សេងៗ ដោយមិនផ្លាស់ប្តូរក្រុមហ៊ុនបើកប្រាក់ខែ។"
  ],
  [
   "使用者指示新增 · 2026-10-27",
   "Added on user instruction · 2026-10-27",
   "បានបន្ថែមតាមការណែនាំរបស់អ្នកប្រើ · 2026-10-27"
  ],
  [
   "版本",
   "Version",
   "កំណែ"
  ],
  [
   "先填單並儲存，再開啟原單送審、追蹤處理進度。",
   "Save a draft, then open it to submit and track progress.",
   "រក្សាសេចក្តីព្រាង រួចបើកដើម្បីដាក់ស្នើ និងតាមដាន។"
  ],
  [
   "這裡會顯示實際建立的資料。現有名冊沒有提供這類單據。",
   "Actual records will appear here. These documents were not supplied in the roster.",
   "ទិន្នន័យពិតនឹងបង្ហាញទីនេះ។ បញ្ជីបុគ្គលិកមិនមានឯកសារប្រភេទនេះទេ។"
  ],
  [
   "名冊中的文件備註，並非已上傳的文件檔案。",
   "Document status from the roster; no files have been uploaded.",
   "ស្ថានភាពឯកសារពីបញ្ជី មិនមែនឯកសារដែលបានផ្ទុកឡើង។"
  ],
  [
   "合約",
   "Contract",
   "កិច្ចសន្យា"
  ],
  [
   "履歷",
   "CV",
   "ប្រវត្តិរូប"
  ],
  [
   "保密協議",
   "Confidentiality",
   "កិច្ចព្រមព្រៀងសម្ងាត់"
  ],
  [
   "物業、租約、維修與客訴由 PMS 處理。",
   "Properties, leases, maintenance and complaints are handled in PMS.",
   "អចលនទ្រព្យ កិច្ចសន្យាជួល ការថែទាំ និងបណ្តឹងត្រូវបានដោះស្រាយក្នុង PMS។"
  ],
  [
   "已開通帳號",
   "Activated accounts",
   "គណនីដែលបានបើក"
  ],
  [
   "查看權限",
   "View access",
   "មើលសិទ្ធិ"
  ],
  [
   "部門、職務、公司或薪資異動，請到人事異動申請。",
   "Use Employment changes to change department, job, employer or salary.",
   "ប្រើការផ្លាស់ប្តូរបុគ្គលិក ដើម្បីកែផ្នែក តួនាទី ក្រុមហ៊ុន ឬប្រាក់ខែ។"
  ],
  [
   "儲存後開啟原單送審；核准不會自動入帳或付款。",
   "Save, then open the request to submit. Approval does not post or pay automatically.",
   "រក្សាទុក រួចបើកសំណើដើម្បីដាក់ស្នើ។ ការអនុម័តមិនកត់គណនេយ្យ ឬទូទាត់ដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "修改內容",
   "Edit content",
   "កែខ្លឹមសារ"
  ],
  [
   "員工：本人資料；人資：授權公司人事資料；財務：授權公司薪資及收付款；主管：授權公司員工基本資料；經營主管：管理總覽與員工基本資料。人資／主管／經營主管不會取得他人薪資。",
   "Employee: self only. HR: company HR files. Finance: company payroll and finance. Manager: company basic profiles. Executive: management overview and basic employee profiles. HR, managers and executives cannot see others’ salary.",
   "បុគ្គលិក៖ ទិន្នន័យផ្ទាល់ខ្លួន។ HR៖ ឯកសារបុគ្គលិកក្រុមហ៊ុន។ ហិរញ្ញវត្ថុ៖ ប្រាក់ខែ និងការទូទាត់។ អ្នកគ្រប់គ្រង៖ ព័ត៌មានមូលដ្ឋាន។ ថ្នាក់ដឹកនាំ៖ ទិដ្ឋភាពក្រុមហ៊ុន។ HR និងអ្នកគ្រប់គ្រងមិនឃើញប្រាក់ខែអ្នកផ្សេងទេ។"
  ],
  [
   "任職公司保留本人作業權限；支援其他公司時需逐一授權。帳號使用 email。",
   "Keep employer access for personal requests. Explicitly authorize other work companies. Sign in with email.",
   "រក្សាសិទ្ធិក្រុមហ៊ុននិយោជកសម្រាប់សំណើផ្ទាល់ខ្លួន។ អនុញ្ញាតក្រុមហ៊ុនការងារផ្សេងជាក់លាក់។ ចូលដោយអ៊ីមែល។"
  ],
  [
   "換班與代班",
   "Swap & cover",
   "ប្ដូរ និងជំនួសវេន"
  ],
  [
   "考勤月結",
   "Monthly close",
   "បិទបញ្ជីវត្តមានប្រចាំខែ"
  ],
  [
   "申請換代班",
   "Request swap / cover",
   "ស្នើប្ដូរ / ជំនួសវេន"
  ],
  [
   "互換班次",
   "Swap two shifts",
   "ប្ដូរវេនគ្នា"
  ],
  [
   "請人代班",
   "Ask someone to cover",
   "សុំអ្នកជំនួសវេន"
  ],
  [
   "我的班次",
   "My shift",
   "វេនរបស់ខ្ញុំ"
  ],
  [
   "接班人",
   "Covering colleague",
   "អ្នកជំនួសវេន"
  ],
  [
   "對方班次",
   "Colleague’s shift",
   "វេនរបស់មិត្តរួមការងារ"
  ],
  [
   "申請原因",
   "Reason for request",
   "មូលហេតុស្នើ"
  ],
  [
   "待接班人確認",
   "Awaiting colleague",
   "រង់ចាំអ្នកជំនួសបញ្ជាក់"
  ],
  [
   "待主管審核",
   "Awaiting manager",
   "រង់ចាំអ្នកគ្រប់គ្រងពិនិត្យ"
  ],
  [
   "已核准並更新班表",
   "Approved; schedule updated",
   "បានអនុម័ត និងកែវេន"
  ],
  [
   "接班人已婉拒",
   "Declined by colleague",
   "អ្នកជំនួសបានបដិសេធ"
  ],
  [
   "主管已退回",
   "Returned by manager",
   "អ្នកគ្រប់គ្រងបានបញ្ជូនត្រឡប់"
  ],
  [
   "已撤回",
   "Withdrawn",
   "បានដកវិញ"
  ],
  [
   "班次已失效，請重新申請",
   "Shift changed or expired; reapply",
   "វេនបានប្ដូរ ឬផុតពេល សូមស្នើម្ដងទៀត"
  ],
  [
   "同意接班",
   "Accept",
   "យល់ព្រមទទួលវេន"
  ],
  [
   "無法接班",
   "Decline",
   "មិនអាចទទួលវេន"
  ],
  [
   "主管審核",
   "Manager review",
   "ការពិនិត្យរបស់អ្នកគ្រប់គ្រង"
  ],
  [
   "撤回申請",
   "Withdraw request",
   "ដកសំណើ"
  ],
  [
   "回覆說明",
   "Response note",
   "កំណត់សម្គាល់ឆ្លើយតប"
  ],
  [
   "申請流程",
   "Request routes",
   "លំហូរសំណើ"
  ],
  [
   "申請人",
   "Applicant",
   "អ្នកស្នើ"
  ],
  [
   "待我處理",
   "My inbox",
   "រង់ចាំខ្ញុំ"
  ],
  [
   "全部申請",
   "All requests",
   "សំណើទាំងអស់"
  ],
  [
   "月份",
   "Month",
   "ខែ"
  ],
  [
   "載入月份",
   "Load month",
   "បង្ហាញខែ"
  ],
  [
   "月份尚未結束",
   "Month still in progress",
   "ខែមិនទាន់បញ្ចប់"
  ],
  [
   "已鎖定",
   "Locked",
   "បានចាក់សោ"
  ],
  [
   "送交主管審核",
   "Submit to manager",
   "ដាក់ស្នើអ្នកគ្រប់គ្រង"
  ],
  [
   "核准並鎖定",
   "Approve & lock",
   "អនុម័ត និងចាក់សោ"
  ],
  [
   "退回修改",
   "Return for changes",
   "បញ្ជូនត្រឡប់"
  ],
  [
   "重新開啟月份",
   "Reopen month",
   "បើកខែឡើងវិញ"
  ],
  [
   "核對說明",
   "Review note",
   "កំណត់សម្គាល់ពិនិត្យ"
  ],
  [
   "說明並核對",
   "Add review note",
   "បន្ថែមកំណត់សម្គាល់"
  ],
  [
   "已核對",
   "Checked",
   "បានពិនិត្យ"
  ],
  [
   "尚待處理",
   "Unresolved",
   "មិនទាន់ដោះស្រាយ"
  ],
  [
   "預定班次",
   "Scheduled shifts",
   "ចំនួនវេន"
  ],
  [
   "班表工時",
   "Scheduled hours",
   "ម៉ោងតាមកាលវិភាគ"
  ],
  [
   "打卡區間時數",
   "Recorded interval hours",
   "ម៉ោងក្នុងចន្លោះចុះម៉ោង"
  ],
  [
   "補卡筆數",
   "Corrected punches",
   "ចំនួនកែម៉ោង"
  ],
  [
   "待處理事項",
   "Items to resolve",
   "ចំណុចត្រូវដោះស្រាយ"
  ],
  [
   "打卡未成對",
   "Unpaired punch",
   "ម៉ោងចូលចេញមិនគូគ្នា"
  ],
  [
   "補卡尚待審核",
   "Pending correction",
   "សំណើកែម៉ោងរង់ចាំ"
  ],
  [
   "草稿班表未處理",
   "Unresolved draft schedule",
   "កាលវិភាគព្រាងមិនទាន់ដោះស្រាយ"
  ],
  [
   "各月月結",
   "Monthly periods",
   "បញ្ជីបិទតាមខែ"
  ],
  [
   "月結流程紀錄",
   "Close history",
   "ប្រវត្តិបិទបញ្ជី"
  ],
  [
   "整理考勤",
   "Prepare attendance",
   "រៀបចំវត្តមាន"
  ],
  [
   "核准月結",
   "Approve close",
   "អនុម័តបិទបញ្ជី"
  ],
  [
   "主管待辦",
   "Manager tasks",
   "កិច្ចការអ្នកគ្រប់គ្រង"
  ],
  [
   "查看詳情",
   "View details",
   "មើលលម្អិត"
  ],
  [
   "核對後送審",
   "Review and submit",
   "ពិនិត្យរួចដាក់ស្នើ"
  ],
  [
   "選自己的班與接班人",
   "Choose your shift and a colleague",
   "ជ្រើសវេន និងអ្នកជំនួស"
  ],
  [
   "對方同意後交主管",
   "Then send to manager",
   "បន្ទាប់ពីយល់ព្រម ផ្ញើទៅអ្នកគ្រប់គ្រង"
  ],
  [
   "核准才更新正式班表",
   "Approved changes update the schedule",
   "កែវេនក្រោយអនុម័ត"
  ],
  [
   "目前沒有待你處理的申請",
   "No requests need your action",
   "មិនមានសំណើត្រូវការអ្នកដោះស្រាយ"
  ],
  [
   "員工有已發布的班表後，就可以提出換班或代班申請。",
   "Employees can request a swap or cover after their schedules are published.",
   "បុគ្គលិកអាចស្នើប្ដូរ ឬជំនួសក្រោយផ្សព្វផ្សាយកាលវិភាគ។"
  ],
  [
   "只列同公司、同部門且已開通帳號的員工。主管會再確認接班資格；核准前仍依原班表出勤。",
   "Only active colleagues in your company and department with accounts appear. The manager checks suitability. Follow the original schedule until approval.",
   "បង្ហាញតែបុគ្គលិកក្រុមហ៊ុន និងផ្នែកដូចគ្នាដែលមានគណនី។ អ្នកគ្រប់គ្រងពិនិត្យសមត្ថភាព។ ប្រើវេនដើមរហូតដល់អនុម័ត។"
  ],
  [
   "目前沒有可選的接班人，請先由人事核對部門與帳號。",
   "No eligible colleagues yet. Ask HR to verify department and account access.",
   "មិនទាន់មានអ្នកជំនួស សូមឱ្យ HR ពិនិត្យផ្នែក និងគណនី។"
  ],
  [
   "人事核對班表與紀錄",
   "HR checks the records",
   "HR ពិនិត្យកាលវិភាគ និងកំណត់ត្រា"
  ],
  [
   "問題處理完再送審",
   "Resolve issues before submission",
   "ដោះស្រាយបញ្ហាមុនដាក់ស្នើ"
  ],
  [
   "保留本月確認結果",
   "Keep the approved monthly result",
   "រក្សាលទ្ធផលខែដែលអនុម័ត"
  ],
  [
   "選公司與月份，開始核對",
   "Select a company and month",
   "ជ្រើសក្រុមហ៊ុន និងខែ"
  ],
  [
   "月份結束後可送審；本月可先查看進度。",
   "Past months can be submitted; the current month can be previewed.",
   "ខែបញ្ចប់អាចដាក់ស្នើ ខែកំពុងដំណើរការអាចមើលជាមុន។"
  ],
  [
   "班表工時已扣設定的休息時間；打卡區間時數按日曆月分開，未扣未打卡的休息，也不是應付薪資或加班時數。",
   "Scheduled hours exclude configured breaks. Recorded intervals are split at calendar month boundaries, without deducting unrecorded breaks; they are not payable or overtime hours.",
   "ម៉ោងកាលវិភាគដកសម្រាក។ ចន្លោះម៉ោងបែងតាមខែ មិនដកសម្រាកដែលមិនបានចុះម៉ោង មិនមែនម៉ោងបើកប្រាក់ខែ ឬបន្ថែមម៉ោង។"
  ],
  [
   "前往處理",
   "Open inbox",
   "បើកប្រអប់ការងារ"
  ],
  [
   "目前沒有待核對事項。",
   "No items to resolve.",
   "គ្មានចំណុចត្រូវដោះស្រាយ។"
  ],
  [
   "已送審，請由另一位授權主管核准或退回。",
   "Submitted. Another authorized manager must approve or return it.",
   "បានដាក់ស្នើ ត្រូវឱ្យអ្នកគ្រប់គ្រងផ្សេងអនុម័ត ឬបញ្ជូនត្រឡប់។"
  ],
  [
   "月結鎖定考勤結果，不會入帳、扣薪或付款。重新開啟需主管填原因；舊版月結結果仍保留。",
   "Closing locks attendance results only. It does not post, deduct or pay. A manager must give a reason to reopen; earlier snapshots are retained.",
   "បិទបញ្ជីចាក់សោតែលទ្ធផលវត្តមាន មិនកាត់ប្រាក់ ឬទូទាត់។ បើកឡើងវិញត្រូវមានមូលហេតុ និងរក្សាកំណែចាស់។"
  ],
  [
   "我的打卡",
   "My clock-in",
   "ការចុះម៉ោងរបស់ខ្ញុំ"
  ],
  [
   "班表",
   "Schedules",
   "កាលវិភាគវេន"
  ],
  [
   "考勤紀錄",
   "Attendance records",
   "កំណត់ត្រាវត្តមាន"
  ],
  [
   "打卡規則",
   "Clock-in rules",
   "ច្បាប់ចុះម៉ោង"
  ],
  [
   "班別",
   "Shift",
   "វេន"
  ],
  [
   "新增班別",
   "Add shift",
   "បន្ថែមវេន"
  ],
  [
   "安排班表",
   "Schedule staff",
   "រៀបចំកាលវិភាគ"
  ],
  [
   "發布班表",
   "Publish schedules",
   "ផ្សព្វផ្សាយកាលវិភាគ"
  ],
  [
   "打卡地點",
   "Work site",
   "ទីតាំងការងារ"
  ],
  [
   "上班打卡",
   "Clock in",
   "ចុះម៉ោងចូល"
  ],
  [
   "下班打卡",
   "Clock out",
   "ចុះម៉ោងចេញ"
  ],
  [
   "開始上班",
   "Clock in",
   "ចុះម៉ោងចូល"
  ],
  [
   "完成下班",
   "Clock out",
   "ចុះម៉ោងចេញ"
  ],
  [
   "重新定位",
   "Locate again",
   "កំណត់ទីតាំងម្ដងទៀត"
  ],
  [
   "取得位置",
   "Get location",
   "រកទីតាំង"
  ],
  [
   "開啟相機",
   "Open camera",
   "បើកកាមេរ៉ា"
  ],
  [
   "拍照",
   "Take photo",
   "ថតរូប"
  ],
  [
   "重新拍照",
   "Retake",
   "ថតម្ដងទៀត"
  ],
  [
   "送出打卡",
   "Submit clock-in",
   "បញ្ជូនការចុះម៉ោង"
  ],
  [
   "已發布",
   "Published",
   "បានផ្សព្វផ្សាយ"
  ],
  [
   "已取消",
   "Cancelled",
   "បានបោះបង់"
  ],
  [
   "取消班表",
   "Cancel schedule",
   "បោះបង់កាលវិភាគ"
  ],
  [
   "考勤設定",
   "Attendance settings",
   "ការកំណត់វត្តមាន"
  ],
  [
   "啟用打卡",
   "Enable clock-in",
   "បើកការចុះម៉ោង"
  ],
  [
   "要求 GPS 定位",
   "Require GPS",
   "តម្រូវឱ្យមាន GPS"
  ],
  [
   "要求現場拍照",
   "Require camera photo",
   "តម្រូវឱ្យថតរូបនៅទីតាំង"
  ],
  [
   "班別名稱",
   "Shift name",
   "ឈ្មោះវេន"
  ],
  [
   "上班時間",
   "Start time",
   "ម៉ោងចូល"
  ],
  [
   "下班時間",
   "End time",
   "ម៉ោងចេញ"
  ],
  [
   "隔日下班",
   "Ends next day",
   "ចេញនៅថ្ងៃបន្ទាប់"
  ],
  [
   "休息分鐘",
   "Break minutes",
   "នាទីសម្រាក"
  ],
  [
   "遲到寬限分鐘",
   "Late grace minutes",
   "នាទីអនុគ្រោះ"
  ],
  [
   "新增地點",
   "Add work site",
   "បន្ថែមទីតាំង"
  ],
  [
   "地點名稱",
   "Site name",
   "ឈ្មោះទីតាំង"
  ],
  [
   "緯度",
   "Latitude",
   "រយៈទទឹង"
  ],
  [
   "經度",
   "Longitude",
   "រយៈបណ្តោយ"
  ],
  [
   "半徑（公尺）",
   "Radius (m)",
   "កាំ (ម៉ែត្រ)"
  ],
  [
   "允許誤差（公尺）",
   "Max accuracy error (m)",
   "កំហុសអនុញ្ញាត (ម៉ែត្រ)"
  ],
  [
   "申請補卡",
   "Request correction",
   "ស្នើកែម៉ោង"
  ],
  [
   "補卡審核",
   "Correction review",
   "ពិនិត្យសំណើកែម៉ោង"
  ],
  [
   "補卡時間",
   "Missing punch time",
   "ម៉ោងដែលខកខាន"
  ],
  [
   "補卡類型",
   "Punch type",
   "ប្រភេទចុះម៉ោង"
  ],
  [
   "補卡原因",
   "Reason",
   "មូលហេតុ"
  ],
  [
   "審核說明",
   "Review note",
   "កំណត់សម្គាល់ពិនិត្យ"
  ],
  [
   "退回",
   "Return",
   "បញ្ជូនត្រឡប់"
  ],
  [
   "待審核",
   "Pending review",
   "រង់ចាំពិនិត្យ"
  ],
  [
   "已核准",
   "Approved",
   "បានអនុម័ត"
  ],
  [
   "已退回",
   "Returned",
   "បានបញ្ជូនត្រឡប់"
  ],
  [
   "現場打卡",
   "Clock-in",
   "ចុះម៉ោងនៅទីតាំង"
  ],
  [
   "核准補卡",
   "Approved correction",
   "កែម៉ោងដែលបានអនុម័ត"
  ],
  [
   "查看照片",
   "View photo",
   "មើលរូបថត"
  ],
  [
   "未排班打卡",
   "Unscheduled punch",
   "ចុះម៉ោងក្រៅកាលវិភាគ"
  ],
  [
   "未見上班紀錄",
   "No clock-in recorded",
   "មិនទាន់មានម៉ោងចូល"
  ],
  [
   "未見下班紀錄",
   "No clock-out recorded",
   "មិនទាន់មានម៉ោងចេញ"
  ],
  [
   "遲到",
   "Late",
   "មកយឺត"
  ],
  [
   "早退",
   "Early departure",
   "ចេញមុនម៉ោង"
  ],
  [
   "尚無異常",
   "No exceptions yet",
   "មិនទាន់មានភាពមិនប្រក្រតី"
  ],
  [
   "更新紀錄",
   "Refresh records",
   "ធ្វើបច្ចុប្បន្នភាព"
  ],
  [
   "今日已排班",
   "Scheduled today",
   "មានវេនថ្ងៃនេះ"
  ],
  [
   "今日已打卡",
   "Clocked in today",
   "បានចុះម៉ោងថ្ងៃនេះ"
  ],
  [
   "待核對班次",
   "Shifts to check",
   "វេនត្រូវពិនិត្យ"
  ],
  [
   "待審補卡",
   "Pending corrections",
   "សំណើកែម៉ោងរង់ចាំ"
  ],
  [
   "已上班，尚未下班",
   "Clocked in",
   "បានចុះម៉ោងចូល"
  ],
  [
   "尚未上班打卡",
   "Not clocked in",
   "មិនទាន់ចុះម៉ោងចូល"
  ],
  [
   "已完成下班",
   "Clocked out",
   "បានចុះម៉ោងចេញ"
  ],
  [
   "起日",
   "From",
   "ចាប់ពី"
  ],
  [
   "迄日",
   "To",
   "ដល់"
  ],
  [
   "顯示紀錄",
   "Show records",
   "បង្ហាញកំណត់ត្រា"
  ],
  [
   "班表、上下班打卡與異常核對，集中在這裡。",
   "Schedules, clock-in and attendance checks in one place.",
   "កាលវិភាគ ការចុះម៉ោង និងការពិនិត្យវត្តមាននៅកន្លែងតែមួយ។"
  ],
  [
   "柬埔寨時間 UTC+7",
   "Cambodia time UTC+7",
   "ម៉ោងកម្ពុជា UTC+7"
  ],
  [
   "任職公司決定薪資歸屬；打卡地點記錄實際工作位置。",
   "Employer determines payroll; the site records where work takes place.",
   "ក្រុមហ៊ុននិយោជកកំណត់ប្រាក់ខែ ទីតាំងកត់ត្រាកន្លែងធ្វើការ។"
  ],
  [
   "使用自己的帳號打卡",
   "Use your own account to clock in",
   "ប្រើគណនីផ្ទាល់ខ្លួនដើម្បីចុះម៉ោង"
  ],
  [
   "只在你按下按鈕時取得位置與照片，不會持續追蹤。",
   "Location and camera are used only when you tap; no background tracking.",
   "ទីតាំង និងកាមេរ៉ាប្រើតែពេលអ្នកចុច មិនតាមដាននៅខាងក្រោយ។"
  ],
  [
   "我的近期班表",
   "My upcoming shifts",
   "វេនខាងមុខរបស់ខ្ញុំ"
  ],
  [
   "尚無已發布班表；仍可按公司打卡規則打卡，紀錄會標示未排班。",
   "No published shifts yet. Clock-in is still allowed under company rules and marked unscheduled.",
   "មិនទាន់មានវេនផ្សព្វផ្សាយ។ អាចចុះម៉ោងតាមច្បាប់ក្រុមហ៊ុន ហើយកត់ថាក្រៅកាលវិភាគ។"
  ],
  [
   "我的最近紀錄",
   "My latest punches",
   "កំណត់ត្រាចុងក្រោយរបស់ខ្ញុំ"
  ],
  [
   "先填工作時間",
   "Set working hours",
   "កំណត់ម៉ោងធ្វើការ"
  ],
  [
   "選員工、日期、地點",
   "Choose staff, dates and site",
   "ជ្រើសបុគ្គលិក ថ្ងៃ និងទីតាំង"
  ],
  [
   "發布後員工才看得到",
   "Visible to staff after publishing",
   "បុគ្គលិកឃើញបន្ទាប់ពីផ្សព្វផ្សាយ"
  ],
  [
   "需要核對的班次",
   "Shifts requiring review",
   "វេនដែលត្រូវពិនិត្យ"
  ],
  [
   "依已發布班表比較，不會直接判定曠職、扣薪或加班。",
   "Compared with published schedules; does not automatically classify absence, deductions or overtime.",
   "ប្រៀបធៀបនឹងកាលវិភាគ មិនគណនាអវត្តមាន កាត់ប្រាក់ ឬបន្ថែមម៉ោងដោយស្វ័យប្រវត្តិ។"
  ],
  [
   "可使用換代班與考勤月結；自動計薪尚未啟用。",
   "Shift swaps, cover and monthly closing are available. Automatic payroll is not enabled.",
   "អាចប្ដូរ ជំនួសវេន និងបិទបញ្ជីខែ។ មិនទាន់គណនាប្រាក់ខែដោយស្វ័យប្រវត្តិ។"
  ],
  [
   "開啟",
   "On",
   "បើក"
  ],
  [
   "沿用 暹光一廠 的 200 公尺範圍。暹光二廠 可另增地點；正式座標待確認。GPS 與照片供核對，網頁無法保證阻擋模擬定位或多人共用帳號。",
   "暹光一廠 retains the 200 m radius. Add 暹光二廠 after its coordinates are confirmed. GPS and photos support review; a web page cannot guarantee prevention of location spoofing or shared accounts.",
   "暹光一廠 ប្រើកាំ ២០០ ម៉ែត្រ។ បន្ថែម 暹光二廠 ក្រោយបញ្ជាក់ទីតាំង។ GPS និងរូបថតជួយពិនិត្យ តែមិនធានាទប់ស្កាត់ទីតាំងក្លែងក្លាយ ឬគណនីប្រើរួម។"
  ],
  [
   "修改班別不會改動已安排的班表；需取消原班表後重新安排。",
   "Editing a shift does not alter existing schedules. Cancel and reschedule when needed.",
   "កែវេនមិនផ្លាស់ប្តូរកាលវិភាគដែលបានរៀបចំទេ។ ត្រូវបោះបង់ហើយរៀបចំឡើងវិញ។"
  ],
  [
   "選定日期內每天安排相同班別，最多 31 天。先存草稿，再發布。",
   "Applies the same shift to every date in the range, up to 31 days. Save a draft, then publish.",
   "រៀបចំវេនដូចគ្នារាល់ថ្ងៃក្នុងចន្លោះ ដល់ ៣១ ថ្ងៃ។ រក្សាសេចក្តីព្រាង រួចផ្សព្វផ្សាយ។"
  ],
  [
   "使用柬埔寨時間，需由人資或管理員審核；不能核准自己的補卡。",
   "Use Cambodia time. HR or an administrator must review; self-approval is not allowed.",
   "ប្រើម៉ោងកម្ពុជា។ HR ឬអ្នកគ្រប់គ្រងត្រូវពិនិត្យ មិនអាចអនុម័តខ្លួនឯង។"
  ],
  [
   "請先建立這家公司的班別。",
   "Create a shift for this company first.",
   "សូមបង្កើតវេនសម្រាប់ក្រុមហ៊ុននេះជាមុន។"
  ],
  [
   "等待取得目前位置",
   "Waiting for location",
   "រង់ចាំរកទីតាំង"
  ],
  [
   "使用後鏡頭拍下目前工作地點。",
   "Use the rear camera to capture your current workplace.",
   "ប្រើកាមេរ៉ាខាងក្រោយថតកន្លែងធ្វើការបច្ចុប្បន្ន។"
  ],
  [
   "正在定位…",
   "Locating…",
   "កំពុងរកទីតាំង…"
  ],
  [
   "此瀏覽器不支援定位。",
   "This browser does not support geolocation.",
   "កម្មវិធីរុករកមិនគាំទ្រទីតាំង។"
  ],
  [
   "定位未取得，請允許瀏覽器使用精確位置。",
   "Location unavailable. Allow precise location in your browser.",
   "មិនបានទីតាំង។ សូមអនុញ្ញាតទីតាំងច្បាស់លាស់។"
  ],
  [
   "請用手機 Safari 或 Chrome 開啟 HTTPS 網址並允許相機。",
   "Open the HTTPS site in Safari or Chrome and allow the camera.",
   "បើក HTTPS ក្នុង Safari ឬ Chrome និងអនុញ្ញាតកាមេរ៉ា។"
  ],
  [
   "相機尚未準備好，請稍候。",
   "The camera is not ready yet.",
   "កាមេរ៉ាមិនទាន់រួចរាល់។"
  ],
  [
   "照片過大，請重新拍照。",
   "Photo too large; please retake.",
   "រូបថតធំពេក សូមថតម្ដងទៀត។"
  ],
  [
   "請先取得位置。",
   "Get your location first.",
   "សូមរកទីតាំងជាមុន។"
  ],
  [
   "請先現場拍照。",
   "Take a camera photo first.",
   "សូមថតរូបនៅទីតាំងជាមុន។"
  ],
  [
   "請確認起訖日期。",
   "Check the date range.",
   "សូមពិនិត្យចន្លោះកាលបរិច្ឆេទ។"
  ],
  [
   "請在瀏覽器設定允許相機，再重試。",
   "Allow camera access in browser settings and retry.",
   "សូមអនុញ្ញាតកាមេរ៉ា ហើយសាកឡើងវិញ។"
  ],
  [
   "地點已變更，請重新定位。",
   "Site changed. Locate again.",
   "ទីតាំងបានប្ដូរ សូមរកម្ដងទៀត។"
  ],
  [
   "待指定",
   "Unassigned",
   "មិនទាន់ចាត់តាំង"
  ],
  [
   "客戶負責人",
   "Customer owner",
   "អ្នកទទួលបន្ទុកអតិថិជន"
  ],
  [
   "原指派不符合目前職務，請重新指定。",
   "The previous assignee is no longer eligible. Choose again.",
   "អ្នកដែលបានចាត់តាំងពីមុនមិនត្រូវតាមតួនាទីទៀតទេ។ សូមជ្រើសរើសឡើងវិញ។"
  ],
  [
   "功能選單",
   "Modules",
   "ម៉ឺនុយមុខងារ"
  ],
  [
   "指定參與工程",
   "Explicit project participant",
   "អ្នកចូលរួមគម្រោងដែលបានកំណត់"
  ],
  [
   "待重新指定",
   "Reassignment required",
   "ត្រូវចាត់តាំងឡើងវិញ"
  ],
  [
   "尚無符合職務的工程人員",
   "No eligible engineering staff in your access",
   "មិនមានបុគ្គលិកវិស្វកម្មដែលមានសិទ្ធិជ្រើសរើស"
  ],
  [
   "工程與專案",
   "Engineering & projects",
   "វិស្វកម្ម និងគម្រោង"
  ],
  [
   "工作進度",
   "Work progress",
   "វឌ្ឍនភាពការងារ"
  ],
  [
   "預算與費用",
   "Budget & costs",
   "ថវិកា និងចំណាយ"
  ],
  [
   "變更與驗收",
   "Changes & inspections",
   "ការផ្លាស់ប្តូរ និងការត្រួតពិនិត្យ"
  ],
  [
   "相關文件",
   "Related documents",
   "ឯកសារពាក់ព័ន្ធ"
  ],
  [
   "預算項目",
   "Budget item",
   "ធាតុថវិកា"
  ],
  [
   "工程變更",
   "Project change",
   "ការផ្លាស់ប្តូរគម្រោង"
  ],
  [
   "驗收紀錄",
   "Inspection record",
   "កំណត់ត្រាត្រួតពិនិត្យ"
  ],
  [
   "文件版本",
   "Document version",
   "កំណែឯកសារ"
  ],
  [
   "客戶管理",
   "Customers",
   "អតិថិជន"
  ],
  [
   "客戶跟進",
   "Customer follow-up",
   "ការតាមដានអតិថិជន"
  ],
  [
   "供應商資料",
   "Suppliers",
   "អ្នកផ្គត់ផ្គង់"
  ],
  [
   "文件管理",
   "Business documents",
   "ឯកសារអាជីវកម្ម"
  ],
  [
   "申請與簽核",
   "Requests & approvals",
   "សំណើ និងការអនុម័ត"
  ],
  [
   "營運總覽",
   "Business overview",
   "ទិដ្ឋភាពអាជីវកម្ម"
  ],
  [
   "新增工程",
   "New project",
   "គម្រោងថ្មី"
  ],
  [
   "編輯工程",
   "Edit project",
   "កែគម្រោង"
  ],
  [
   "新增工作",
   "Add work item",
   "បន្ថែមការងារ"
  ],
  [
   "新增預算",
   "Add budget item",
   "បន្ថែមធាតុថវិកា"
  ],
  [
   "登記變更",
   "Record change",
   "កត់ត្រាការផ្លាស់ប្តូរ"
  ],
  [
   "登記驗收",
   "Record inspection",
   "កត់ត្រាការត្រួតពិនិត្យ"
  ],
  [
   "登記文件連結",
   "Add document link",
   "បន្ថែមតំណឯកសារ"
  ],
  [
   "新增版本",
   "Add version",
   "បន្ថែមកំណែ"
  ],
  [
   "新增客戶",
   "New customer",
   "អតិថិជនថ្មី"
  ],
  [
   "新增供應商",
   "New supplier",
   "អ្នកផ្គត់ផ្គង់ថ្មី"
  ],
  [
   "新增跟進",
   "Add follow-up",
   "បន្ថែមការតាមដាន"
  ],
  [
   "編輯紀錄",
   "Edit record",
   "កែកំណត់ត្រា"
  ],
  [
   "返回工程清單",
   "Back to projects",
   "ត្រឡប់ទៅបញ្ជីគម្រោង"
  ],
  [
   "返回客戶清單",
   "Back to customers",
   "ត្រឡប់ទៅបញ្ជីអតិថិជន"
  ],
  [
   "返回供應商清單",
   "Back to suppliers",
   "ត្រឡប់ទៅបញ្ជីអ្នកផ្គត់ផ្គង់"
  ],
  [
   "查看原單",
   "View source record",
   "មើលកំណត់ត្រាដើម"
  ],
  [
   "查看來源",
   "View source",
   "មើលប្រភព"
  ],
  [
   "開啟文件",
   "Open document",
   "បើកឯកសារ"
  ],
  [
   "查看版本",
   "View version",
   "មើលកំណែ"
  ],
  [
   "規劃中",
   "Planning",
   "កំពុងរៀបចំ"
  ],
  [
   "進行中",
   "In progress",
   "កំពុងដំណើរការ"
  ],
  [
   "暫停",
   "On hold",
   "ផ្អាក"
  ],
  [
   "已結束",
   "Closed",
   "បានបិទ"
  ],
  [
   "未開始",
   "Not started",
   "មិនទាន់ចាប់ផ្តើម"
  ],
  [
   "受阻",
   "Blocked",
   "ជាប់គាំង"
  ],
  [
   "已完成",
   "Completed",
   "បានបញ្ចប់"
  ],
  [
   "待評估",
   "Proposed",
   "រង់ចាំវាយតម្លៃ"
  ],
  [
   "通過",
   "Pass",
   "ជាប់"
  ],
  [
   "待改善",
   "Needs correction",
   "ត្រូវកែលម្អ"
  ],
  [
   "未通過",
   "Fail",
   "មិនជាប់"
  ],
  [
   "新客戶",
   "New lead",
   "អតិថិជនថ្មី"
  ],
  [
   "聯繫中",
   "Contacting",
   "កំពុងទាក់ទង"
  ],
  [
   "提案中",
   "Proposal",
   "កំពុងស្នើ"
  ],
  [
   "已成交",
   "Won",
   "បានសម្រេច"
  ],
  [
   "已結案",
   "Closed",
   "បានបិទ"
  ],
  [
   "有效紀錄",
   "Active record",
   "កំណត់ត្រាសកម្ម"
  ],
  [
   "工程名稱",
   "Project name",
   "ឈ្មោះគម្រោង"
  ],
  [
   "工程地點",
   "Project location",
   "ទីតាំងគម្រោង"
  ],
  [
   "工程負責人",
   "Project lead",
   "អ្នកដឹកនាំគម្រោង"
  ],
  [
   "工程成員",
   "Project members",
   "សមាជិកគម្រោង"
  ],
  [
   "工作名稱",
   "Work item",
   "ឈ្មោះការងារ"
  ],
  [
   "工作負責人",
   "Assignee",
   "អ្នកទទួលបន្ទុក"
  ],
  [
   "預定完成",
   "Due date",
   "ថ្ងៃត្រូវបញ្ចប់"
  ],
  [
   "完成比例",
   "Completion %",
   "ភាគរយបញ្ចប់"
  ],
  [
   "工程狀態",
   "Project status",
   "ស្ថានភាពគម្រោង"
  ],
  [
   "預算分類",
   "Budget category",
   "ប្រភេទថវិកា"
  ],
  [
   "預算合計",
   "Planned budget",
   "ថវិកាសរុប"
  ],
  [
   "採購草稿合計",
   "Purchase drafts total",
   "សរុបសេចក្តីព្រាងការទិញ"
  ],
  [
   "應付草稿合計",
   "Payable drafts total",
   "សរុបសេចក្តីព្រាងត្រូវបង់"
  ],
  [
   "已完成工作",
   "Completed work",
   "ការងារដែលបានបញ្ចប់"
  ],
  [
   "工程數",
   "Projects",
   "គម្រោង"
  ],
  [
   "變更原因",
   "Reason for change",
   "មូលហេតុប្តូរ"
  ],
  [
   "費用影響",
   "Cost impact",
   "ផលប៉ះពាល់ចំណាយ"
  ],
  [
   "工期影響天數",
   "Schedule impact (days)",
   "ផលប៉ះពាល់ពេលវេលា (ថ្ងៃ)"
  ],
  [
   "驗收日期",
   "Inspection date",
   "ថ្ងៃត្រួតពិនិត្យ"
  ],
  [
   "驗收人",
   "Inspector",
   "អ្នកត្រួតពិនិត្យ"
  ],
  [
   "驗收結果",
   "Inspection result",
   "លទ្ធផលត្រួតពិនិត្យ"
  ],
  [
   "改善期限",
   "Correction deadline",
   "ថ្ងៃកំណត់កែលម្អ"
  ],
  [
   "聯絡人",
   "Contact",
   "អ្នកទំនាក់ទំនង"
  ],
  [
   "電話",
   "Phone",
   "ទូរស័ព្ទ"
  ],
  [
   "客戶需求",
   "Requirements",
   "តម្រូវការអតិថិជន"
  ],
  [
   "業務階段",
   "Stage",
   "ដំណាក់កាល"
  ],
  [
   "負責人",
   "Assignee",
   "អ្នកទទួលខុសត្រូវ"
  ],
  [
   "下次跟進",
   "Next follow-up",
   "ការតាមដានបន្ទាប់"
  ],
  [
   "聯繫日期",
   "Contact date",
   "ថ្ងៃទាក់ទង"
  ],
  [
   "跟進紀錄",
   "Follow-up history",
   "ប្រវត្តិតាមដាន"
  ],
  [
   "文件名稱",
   "Document name",
   "ឈ្មោះឯកសារ"
  ],
  [
   "文件連結",
   "Document URL",
   "តំណឯកសារ"
  ],
  [
   "關聯業務",
   "Linked business record",
   "កំណត់ត្រាអាជីវកម្មពាក់ព័ន្ធ"
  ],
  [
   "前一版本",
   "Previous version",
   "កំណែមុន"
  ],
  [
   "無關聯工程",
   "No linked project",
   "គ្មានគម្រោងពាក់ព័ន្ធ"
  ],
  [
   "關聯工程",
   "Linked project",
   "គម្រោងពាក់ព័ន្ធ"
  ],
  [
   "無關聯供應商",
   "No linked supplier",
   "គ្មានអ្នកផ្គត់ផ្គង់ពាក់ព័ន្ធ"
  ],
  [
   "關聯供應商",
   "Linked supplier",
   "អ្នកផ្គត់ផ្គង់ពាក់ព័ន្ធ"
  ],
  [
   "工作清單",
   "Work items",
   "បញ្ជីការងារ"
  ],
  [
   "目前沒有工程資料",
   "No projects yet",
   "មិនទាន់មានគម្រោង"
  ],
  [
   "尚無相關文件",
   "No related documents",
   "មិនទាន់មានឯកសារពាក់ព័ន្ធ"
  ],
  [
   "查無可存取的資料",
   "Record unavailable",
   "មិនមានកំណត់ត្រាដែលអាចចូលបាន"
  ],
  [
   "全部業務",
   "All business records",
   "កំណត់ត្រាអាជីវកម្មទាំងអស់"
  ],
  [
   "建立採購草稿",
   "Create purchase draft",
   "បង្កើតសេចក្តីព្រាងការទិញ"
  ],
  [
   "建立應付草稿",
   "Create payable draft",
   "បង្កើតសេចក្តីព្រាងត្រូវបង់"
  ],
  [
   "行政交辦",
   "Administrative tasks",
   "ភារកិច្ចរដ្ឋបាល"
  ],
  [
   "尚未啟用正式簽核",
   "Approval workflow not enabled",
   "មិនទាន់បើកលំហូរអនុម័ត"
  ],
  [
   "變更待評估",
   "Changes awaiting review",
   "ការផ្លាស់ប្តូររង់ចាំវាយតម្លៃ"
  ],
  [
   "文件總數",
   "Document versions",
   "ចំនួនកំណែឯកសារ"
  ],
  [
   "工作筆數",
   "Work items",
   "ចំនួនការងារ"
  ],
  [
   "未設定",
   "Not set",
   "មិនបានកំណត់"
  ],
  [
   "預算金額",
   "Budget amount",
   "ចំនួនថវិកា"
  ],
  [
   "紀錄版本",
   "Record revision",
   "កំណែកំណត់ត្រា"
  ],
  [
   "僅更新進度與備註",
   "Update progress and notes only",
   "កែតែវឌ្ឍនភាព និងកំណត់ចំណាំ"
  ],
  [
   "工程工作、預算、變更驗收及文件集中在同一個項目。",
   "Keep work, budgets, changes, inspections and documents in one project.",
   "ប្រមូលការងារ ថវិកា ការផ្លាស់ប្តូរ ការត្រួតពិនិត្យ និងឯកសារក្នុងគម្រោងតែមួយ។"
  ],
  [
   "由管理員或主管建立真實工程；舊版示例不會匯入。",
   "An administrator or manager can create a real project. Old demo data is not imported.",
   "អ្នកគ្រប់គ្រងអាចបង្កើតគម្រោងពិត។ មិននាំចូលទិន្នន័យគំរូចាស់ទេ។"
  ],
  [
   "行政人事的「專案交辦」保留在原區塊；維修與客訴由 PMS 處理。",
   "Administrative tasks remain in HR; maintenance and complaints belong to PMS.",
   "ភារកិច្ចរដ្ឋបាលនៅក្នុង HR។ ការថែទាំ និងបណ្តឹងនៅក្នុង PMS។"
  ],
  [
   "變更先登記費用與工期影響；驗收記錄現場結果。兩者都不會自動核准預算、入帳或付款。",
   "Record change impacts and inspection results. These records do not authorize budgets, post accounts or trigger payment.",
   "កត់ត្រាផលប៉ះពាល់ និងលទ្ធផលត្រួតពិនិត្យ។ មិនអនុម័តថវិកា កត់ត្រាគណនេយ្យ ឬទូទាត់ដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "採購與應付可能是同一筆費用，不會相加重複計算。這些是草稿金額，並非已入帳成本或已付款。",
   "Purchases and payables can describe the same expense, so their totals are separate. Draft amounts are not posted costs or payments.",
   "ការទិញ និងគណនីត្រូវបង់អាចជាចំណាយតែមួយ ដូច្នេះមិនបូកបញ្ចូលគ្នាទេ។ ទាំងនេះជាសេចក្តីព្រាង មិនមែនថ្លៃដើម ឬការទូទាត់ផ្លូវការ។"
  ],
  [
   "按公司保留往來資料，從同一筆資料連到工作與文件。",
   "Keep company-scoped contacts linked to work and documents.",
   "រក្សាទំនាក់ទំនងតាមក្រុមហ៊ុន និងភ្ជាប់ការងារ និងឯកសារ។"
  ],
  [
   "登記既有雲端文件的 HTTPS 連結、版本與來源；新增版本會保留舊紀錄。目前不提供檔案上傳，外部文件仍使用原平台的存取權限。",
   "Register an existing HTTPS document link, version and source. New versions retain older records. File upload is not available; the original provider controls file access.",
   "ចុះបញ្ជីតំណ HTTPS កំណែ និងប្រភព។ កំណែថ្មីរក្សាកំណែចាស់។ មិនទាន់អាចផ្ទុកឯកសារឡើង និងសិទ្ធិឯកសារគ្រប់គ្រងដោយអ្នកផ្តល់ដើម។"
  ],
  [
   "工程、客戶、採購與財務文件在此集中查找；人事證件仍有獨立入口。",
   "Find business documents here; HR documents keep their separate entry.",
   "ស្វែងរកឯកសារអាជីវកម្មទីនេះ។ ឯកសារ HR មានច្រកចូលដាច់ដោយឡែក។"
  ],
  [
   "先集中查看已儲存的申請。核決人、金額權限與代理規則尚待設定；不會將草稿顯示為已送審或已核准。",
   "Review saved requests here. Approvers, authority limits and delegation rules still need configuration. Drafts are not submitted or approved.",
   "មើលសំណើដែលបានរក្សាទុក។ ត្រូវកំណត់អ្នកអនុម័ត ដែនកំណត់ និងអ្នកជំនួស។ សេចក្តីព្រាងមិនទាន់ដាក់ស្នើ ឬអនុម័ត។"
  ],
  [
   "只統計你有權限查看的真實紀錄。",
   "Only actual records within your access are counted.",
   "រាប់តែកំណត់ត្រាពិតដែលអ្នកមានសិទ្ធិមើល។"
  ],
  [
   "營收、實際成本、付款與 KPI 需要正式入帳與指標定義，目前不使用草稿或示例數字代替。",
   "Revenue, actual costs, payments and KPIs require posted entries and defined metrics. Drafts or demo figures are not substituted.",
   "ចំណូល ថ្លៃដើម ការទូទាត់ និង KPI ត្រូវការទិន្នន័យផ្លូវការ និងនិយមន័យ។ មិនប្រើសេចក្តីព្រាង ឬទិន្នន័យគំរូជំនួសទេ។"
  ],
  [
   "儲存業務紀錄，不會自動執行簽核、入帳或付款。",
   "Saves a business record; does not trigger approval, posting or payment.",
   "រក្សាកំណត់ត្រាអាជីវកម្ម មិនអនុម័ត កត់ត្រាគណនេយ្យ ឬទូទាត់ដោយស្វ័យប្រវត្តិ។"
  ],
  [
   "只列工程／技術人員及指定參與者。各項工作可再分別指定負責人。",
   "Engineering/technical staff and designated participants only. Assign each work item separately.",
   "តែបុគ្គលិកវិស្វកម្ម បច្ចេកទេស និងអ្នកដែលបានកំណត់។ អាចចាត់តាំងការងារនីមួយៗដាច់ដោយឡែក។"
  ],
  [
   "依名冊部門與職務列出；任職公司不因指派而改變。",
   "Listed by roster department and job. Assignment does not change the employer.",
   "បង្ហាញតាមផ្នែក និងតួនាទីក្នុងបញ្ជី។ ការចាត់តាំងមិនប្ដូរក្រុមហ៊ុននិយោជកទេ។"
  ],
  [
   "尚無符合職務的可指派人員，先保留待指定。",
   "No eligible staff available. Leave unassigned for now.",
   "មិនទាន់មានបុគ្គលិកត្រូវតាមតួនាទី។ រក្សាទុកដោយមិនទាន់ចាត់តាំង។"
  ],
  [
   "帳號權限",
   "Account access",
   "សិទ្ធិគណនី"
  ],
  [
   "可見選單如下；資料仍受公司、本人及項目指派範圍限制。",
   "Visible modules below. Company scope, own records and project assignment still limit data access.",
   "ម៉ឺនុយដែលអាចមើលបានខាងក្រោម។ ទិន្នន័យកំណត់តាមក្រុមហ៊ុន កំណត់ត្រាផ្ទាល់ខ្លួន និងការចាត់តាំងគម្រោង។"
  ],
  [
   "董事長總覽",
   "Chairman overview",
   "ទិដ្ឋភាពប្រធានក្រុមប្រឹក្សា"
  ],
  [
   "CEO 工作總覽",
   "CEO team overview",
   "ទិដ្ឋភាពការងារ CEO"
  ],
  [
   "返回管理總覽",
   "Back to overview",
   "ត្រឡប់ទៅទិដ្ឋភាពទូទៅ"
  ],
  [
   "董事長",
   "Chairman",
   "ប្រធានក្រុមប្រឹក្សា"
  ],
  [
   "工作卡關",
   "Blocked work",
   "ការងារជាប់គាំង"
  ],
  [
   "工作逾期",
   "Overdue work",
   "ការងារហួសកំណត់"
  ],
  [
   "驗收需改善",
   "Inspection needs action",
   "ការត្រួតពិនិត្យត្រូវកែលម្អ"
  ],
  [
   "變更待確認",
   "Proposed change",
   "ការផ្លាស់ប្តូររង់ចាំបញ្ជាក់"
  ],
  [
   "團隊進度",
   "Team progress",
   "វឌ្ឍនភាពក្រុម"
  ],
  [
   "查看工作",
   "View work",
   "មើលការងារ"
  ],
  [
   "依工作負責人的部門整理，點部門看明細。",
   "Grouped by the responsible employee’s department. Select a team for details.",
   "រៀបតាមផ្នែករបស់អ្នកទទួលខុសត្រូវ។ ចុចផ្នែកដើម្បីមើលលម្អិត។"
  ],
  [
   "查看其餘",
   "Show remaining",
   "មើលផ្នែកនៅសល់"
  ],
  [
   "個部門",
   "departments",
   "ផ្នែក"
  ],
  [
   "部門未指定",
   "No department",
   "មិនទាន់កំណត់ផ្នែក"
  ],
  [
   "完成",
   "Done",
   "រួចរាល់"
  ],
  [
   "尚無進度紀錄",
   "No progress recorded",
   "មិនទាន់កត់ត្រាវឌ្ឍនភាព"
  ],
  [
   "位負責人",
   "responsible staff",
   "នាក់ទទួលខុសត្រូវ"
  ],
  [
   "位在職員工",
   "active staff",
   "នាក់កំពុងបម្រើការ"
  ],
  [
   "卡關",
   "Blocked",
   "ជាប់គាំង"
  ],
  [
   "逾期",
   "Overdue",
   "ហួសកំណត់"
  ],
  [
   "查看員工",
   "View people",
   "មើលបុគ្គលិក"
  ],
  [
   "無已記錄異常",
   "No recorded exceptions",
   "គ្មានបញ្ហាដែលបានកត់ត្រា"
  ],
  [
   "還沒有工作進度紀錄。工程工作建立後，這裡會顯示各部門完成、卡關與逾期情況。",
   "No work progress recorded yet. Engineering work will appear here by team, completion, blockers and due dates.",
   "មិនទាន់មានវឌ្ឍនភាពការងារ។ ការងារវិស្វកម្មនឹងបង្ហាញតាមក្រុម ការបញ្ចប់ បញ្ហា និងកាលកំណត់។"
  ],
  [
   "此卡統計工程工作；一般專案交辦進度與驗收在上方分開列示。",
   "This card counts engineering work. Administrative execution and acceptance are shown separately above.",
   "កាតនេះរាប់ការងារវិស្វកម្ម។ វឌ្ឍនភាព និងការទទួលយករដ្ឋបាលបង្ហាញដាច់ដោយឡែកខាងលើ។"
  ],
  [
   "需要關注",
   "Needs attention",
   "ត្រូវយកចិត្តទុកដាក់"
  ],
  [
   "查看全部",
   "View all",
   "មើលទាំងអស់"
  ],
  [
   "目前沒有已記錄的卡關、逾期、驗收改善或變更事項。",
   "No recorded blockers, overdue work, inspection issues or proposed changes.",
   "បច្ចុប្បន្នគ្មានបញ្ហា ការហួសកំណត់ ការកែលម្អ ឬការផ្លាស់ប្តូរដែលបានកត់ត្រា។"
  ],
  [
   "尚無工程紀錄，還不能判斷執行狀況。",
   "No engineering records yet; delivery status is not available.",
   "មិនទាន់មានកំណត់ត្រាវិស្វកម្ម ដូច្នេះមិនទាន់អាចវាយតម្លៃការងារ។"
  ],
  [
   "各公司概況",
   "Company overview",
   "ទិដ្ឋភាពក្រុមហ៊ុន"
  ],
  [
   "點選查看公司",
   "Select a company",
   "ជ្រើសក្រុមហ៊ុន"
  ],
  [
   "進行中工程",
   "Active projects",
   "គម្រោងកំពុងដំណើរការ"
  ],
  [
   "逾期工作",
   "Overdue work",
   "ការងារហួសកំណត់"
  ],
  [
   "名冊尚未提供員工資料",
   "No roster supplied",
   "មិនទាន់ផ្តល់បញ្ជីបុគ្គលិក"
  ],
  [
   "員工依任職公司；工程與財務依出帳公司。",
   "Employees follow their employer; projects and finance follow the billing company.",
   "បុគ្គលិកតាមក្រុមហ៊ុននិយោជក។ គម្រោង និងហិរញ្ញវត្ថុតាមក្រុមហ៊ុនចេញវិក្កយបត្រ។"
  ],
  [
   "財務摘要",
   "Finance summary",
   "សង្ខេបហិរញ្ញវត្ថុ"
  ],
  [
   "已登記金額，尚未入帳或付款。",
   "Recorded drafts; not posted or paid.",
   "ចំនួនទឹកប្រាក់ក្នុងសេចក្តីព្រាង មិនទាន់កត់គណនេយ្យ ឬទូទាត់។"
  ],
  [
   "應收草稿",
   "Receivable drafts",
   "សេចក្តីព្រាងប្រាក់ត្រូវទទួល"
  ],
  [
   "應付草稿",
   "Payable drafts",
   "សេចក្តីព្រាងប្រាក់ត្រូវបង់"
  ],
  [
   "尚無草稿",
   "No drafts yet",
   "មិនទាន់មានសេចក្តីព្រាង"
  ],
  [
   "此卡僅顯示申請草稿；正式收入與損益請查看各公司已入帳報表。",
   "This card shows request drafts only. See each company’s posted reports for revenue and profit.",
   "កាតនេះបង្ហាញតែសេចក្តីព្រាងសំណើ។ មើលរបាយការណ៍កត់ត្រាតាមក្រុមហ៊ុនសម្រាប់ចំណូល និងចំណេញ។"
  ],
  [
   "工程進度",
   "Project delivery",
   "វឌ្ឍនភាពគម្រោង"
  ],
  [
   "項工作完成",
   "work items done",
   "ការងារបានបញ្ចប់"
  ],
  [
   "尚未建立工作項目",
   "No work items yet",
   "មិនទាន់បង្កើតការងារ"
  ],
  [
   "未設定期限",
   "No deadline",
   "មិនទាន់កំណត់ថ្ងៃ"
  ],
  [
   "工程建立後，即可查看負責人、進度與期限。",
   "Once a project is created, its lead, work progress and deadline appear here.",
   "បន្ទាប់ពីបង្កើតគម្រោង អាចមើលអ្នកទទួលខុសត្រូវ វឌ្ឍនភាព និងកាលកំណត់។"
  ],
  [
   "管理員檢視版型",
   "Administrator layout preview",
   "អ្នកគ្រប់គ្រងមើលប្លង់"
  ],
  [
   "維持你的管理員權限",
   "Your administrator access is unchanged",
   "រក្សាសិទ្ធិអ្នកគ្រប់គ្រងរបស់អ្នក"
  ],
  [
   "先看各公司，再看需要處理的事。",
   "See the companies. Focus on what needs action.",
   "មើលក្រុមហ៊ុន ហើយផ្តោតលើអ្វីដែលត្រូវដោះស្រាយ។"
  ],
  [
   "團隊做到哪裡，哪些事情需要你處理。",
   "Where the team stands, and what needs your attention.",
   "ក្រុមធ្វើដល់ណា និងអ្វីត្រូវការអ្នកដោះស្រាយ។"
  ],
  [
   "更新資料",
   "Refresh data",
   "ធ្វើបច្ចុប្បន្នភាព"
  ],
  [
   "資料更新",
   "Updated",
   "បានធ្វើបច្ចុប្បន្នភាព"
  ],
  [
   "查看人員與部門",
   "People and departments",
   "មើលបុគ្គលិក និងផ្នែក"
  ],
  [
   "未完成工作",
   "Open work",
   "ការងារមិនទាន់បញ្ចប់"
  ],
  [
   "查看工程明細",
   "View projects",
   "មើលគម្រោង"
  ],
  [
   "依已建立工程工作",
   "Recorded engineering work",
   "តាមការងារវិស្វកម្មដែលបានបង្កើត"
  ],
  [
   "期限已過、尚未完成",
   "Past due and unfinished",
   "ហួសកំណត់ និងមិនទាន់បញ្ចប់"
  ],
  [
   "卡關工作",
   "Blocked work",
   "ការងារជាប់គាំង"
  ],
  [
   "需要協調或協助",
   "Needs coordination or support",
   "ត្រូវការសម្របសម្រួល ឬជំនួយ"
  ],
  [
   "份申請草稿 · 執行與驗收另行追蹤",
   "request drafts · execution and acceptance tracked separately",
   "សេចក្តីព្រាងសំណើ · តាមដានការអនុវត្ត និងទទួលយកដាច់ដោយឡែក"
  ],
  [
   "經營 KPI",
   "Business KPIs",
   "សូចនាករអាជីវកម្ម"
  ],
  [
   "待設定目標與計算方式",
   "Targets and formulas not configured",
   "គោលដៅ និងរូបមន្តមិនទាន់កំណត់"
  ],
  [
   "我的請假與申請",
   "My leave & requests",
   "ការសុំច្បាប់ និងសំណើរបស់ខ្ញុំ"
  ],
  [
   "保留個人員工功能",
   "Personal employee tools remain available",
   "រក្សាមុខងារបុគ្គលិកផ្ទាល់ខ្លួន"
  ],
  [
   "「—」表示尚無資料，不代表零。完成率＝已完成工作數 ÷ 已建立工作數；不代表工期、預算或員工績效。",
   "“—” means data is unavailable, not zero. Completion is completed items / recorded items, not schedule, budget or employee performance.",
   "«—» មានន័យថាមិនទាន់មានទិន្នន័យ មិនមែនសូន្យ។ អត្រាបញ្ចប់គឺចំនួនការងារបញ្ចប់ចែកការងារដែលបានបង្កើត មិនមែនពេលវេលា ថវិកា ឬលទ្ធផលបុគ្គលិក។"
  ],
  [
   "財務草稿明細",
   "Financial draft details",
   "លម្អិតសេចក្តីព្រាងហិរញ្ញវត្ថុ"
  ],
  [
   "尚未入帳或付款；僅供核對已登記內容。",
   "Not posted or paid; review recorded draft information.",
   "មិនទាន់កត់គណនេយ្យ ឬទូទាត់។ សម្រាប់ពិនិត្យសេចក្តីព្រាង។"
  ],
  [
   "需要關注的事項",
   "Items needing attention",
   "កិច្ចការត្រូវយកចិត្តទុកដាក់"
  ],
  [
   "原因",
   "Reason",
   "មូលហេតុ"
  ],
  [
   "團隊工作明細",
   "Team work details",
   "លម្អិតការងារក្រុម"
  ],
  [
   "點開工作查看進度、負責人與備註。",
   "Open a work item for progress, assignee and notes.",
   "បើកការងារដើម្បីមើលវឌ្ឍនភាព អ្នកទទួលខុសត្រូវ និងកំណត់ចំណាំ។"
  ],
  [
   "全部工作",
   "All work",
   "ការងារទាំងអស់"
  ],
  [
   "未完成",
   "Not done",
   "មិនទាន់រួច"
  ],
  [
   "負責人／部門",
   "Assignee / team",
   "អ្នកទទួលខុសត្រូវ / ផ្នែក"
  ],
  [
   "期限",
   "Due",
   "កាលកំណត់"
  ],
  [
   "進度",
   "Status",
   "ស្ថានភាព"
  ],
  [
   "今日考勤",
   "Attendance today",
   "វត្តមានថ្ងៃនេះ"
  ],
  [
   "已排班",
   "Scheduled",
   "មានវេន"
  ],
  [
   "已打卡",
   "Clocked in",
   "បានចុះម៉ោង"
  ],
  [
   "更多資料（選填）",
   "More details (optional)",
   "ព័ត៌មានបន្ថែម (ជាជម្រើស)"
  ],
  [
   "聯絡資料（選填）",
   "Contact details (optional)",
   "ព័ត៌មានទំនាក់ទំនង (ជាជម្រើស)"
  ],
  [
   "已帶入",
   "Filled automatically",
   "បានបំពេញដោយស្វ័យប្រវត្តិ"
  ],
  [
   "客戶名稱",
   "Customer name",
   "ឈ្មោះអតិថិជន"
  ],
  [
   "供應商名稱",
   "Supplier name",
   "ឈ្មោះអ្នកផ្គត់ផ្គង់"
  ],
  [
   "採購內容",
   "Purchase description",
   "បរិយាយការទិញ"
  ],
  [
   "請假事由",
   "Reason for leave",
   "មូលហេតុសុំច្បាប់"
  ],
  [
   "交接安排",
   "Handover plan",
   "ផែនការប្រគល់ការងារ"
  ],
  [
   "跟進內容",
   "Follow-up notes",
   "ព័ត៌មានតាមដាន"
  ],
  [
   "改善事項",
   "Required corrections",
   "ចំណុចត្រូវកែលម្អ"
  ],
  [
   "其他往來對象",
   "Other counterparty",
   "ភាគីផ្សេងទៀត"
  ],
  [
   "單據名稱",
   "Record title",
   "ចំណងជើងកំណត់ត្រា"
  ],
  [
   "金額（USD）",
   "Amount (USD)",
   "ចំនួនប្រាក់ (USD)"
  ],
  [
   "員工任職公司",
   "Employee company",
   "ក្រុមហ៊ុននិយោជក"
  ],
  [
   "選定員工後自動帶入任職公司。",
   "The employer is filled after selecting an employee.",
   "ក្រុមហ៊ុននិយោជកបំពេញបន្ទាប់ពីជ្រើសរើសបុគ្គលិក។"
  ],
  [
   "只開通本人任職公司。",
   "Access to the employee’s company only.",
   "ចូលបានតែក្រុមហ៊ុននិយោជក។"
  ],
  [
   "請至少選擇一家授權公司。",
   "Select at least one authorized company.",
   "សូមជ្រើសរើសក្រុមហ៊ុនដែលបានអនុញ្ញាតយ៉ាងតិចមួយ។"
  ],
  [
   "查看本人資料與申請。",
   "Access own information and requests.",
   "មើលព័ត៌មាន និងសំណើផ្ទាល់ខ្លួន។"
  ],
  [
   "管理授權公司的人事資料，不含他人薪資。",
   "Manage authorized HR files, excluding others’ pay.",
   "គ្រប់គ្រងព័ត៌មាន HR ដែលបានអនុញ្ញាត មិនរួមប្រាក់ខែអ្នកផ្សេង។"
  ],
  [
   "查看授權公司的薪資與收付款資料。",
   "View payroll and finance for authorized companies.",
   "មើលប្រាក់ខែ និងហិរញ្ញវត្ថុរបស់ក្រុមហ៊ុនដែលបានអនុញ្ញាត។"
  ],
  [
   "查看授權公司的員工基本資料與業務。",
   "Access employee basics and authorized business records.",
   "មើលព័ត៌មានមូលដ្ឋានបុគ្គលិក និងអាជីវកម្មដែលបានអនុញ្ញាត។"
  ],
  [
   "依職務顯示 CEO／董事長總覽，可查看授權公司的員工基本資料；不含他人薪資與證件。",
   "CEO/chairman dashboard and authorized employee basics; excludes others’ pay and identity documents.",
   "ទិដ្ឋភាព CEO/ប្រធានក្រុមប្រឹក្សា និងព័ត៌មានមូលដ្ឋានបុគ្គលិក។ មិនរួមប្រាក់ខែ និងឯកសារផ្ទាល់ខ្លួនអ្នកផ្សេង។"
  ],
  [
   "任職公司保留，支援公司可另外勾選。",
   "Employer access is retained; select additional work companies as needed.",
   "រក្សាសិទ្ធិក្រុមហ៊ុននិយោជក ហើយជ្រើសក្រុមហ៊ុនការងារបន្ថែម។"
  ],
  [
   "會議待確認事項",
   "Meeting decisions needed",
   "ចំណុចត្រូវបញ្ជាក់ពីកិច្ចប្រជុំ"
  ],
  [
   "依 10 月 28 日會議整理；區分已可操作的功能，以及仍需客戶確認的資料與規則。",
   "From the 28 October meeting: working features are distinguished from data and rules that still need client confirmation.",
   "តាមកិច្ចប្រជុំថ្ងៃទី២៨ តុលា៖ បែងចែកមុខងារដែលអាចប្រើបាន និងទិន្នន័យឬច្បាប់ដែលនៅត្រូវការអតិថិជនបញ្ជាក់។"
  ],
  [
   "待確認",
   "Pending confirmation",
   "រង់ចាំបញ្ជាក់"
  ],
  [
   "職位與期間代理",
   "Positions and temporary delegates",
   "តួនាទី និងអ្នកជំនួសបណ្តោះអាសន្ន"
  ],
  [
   "先建立固定職位，再選任職者。流程指向職位，換人時不用重建路線。",
   "Create a stable position, then assign its holder. Routes refer to positions and survive staffing changes.",
   "បង្កើតតួនាទីថេរ រួចជ្រើសអ្នកកាន់តំណែង។ លំហូររក្សាដដែលពេលប្តូរបុគ្គលិក។"
  ],
  [
   "新增職位",
   "New position",
   "បន្ថែមតួនាទី"
  ],
  [
   "職位可設定功能與操作權限；任職者與有效代理人使用相同授權。未勾選額外權限時，沿用原本簽核用途。代理依柬埔寨日期到期失效。",
   "Positions may grant explicit function access to holders and active delegates. Without extra grants they retain request-routing use only. Delegation expires using Cambodia dates.",
   "តួនាទីអាចផ្តល់សិទ្ធិមុខងារ និងសកម្មភាពជាក់លាក់ដល់អ្នកកាន់តំណែង និងអ្នកជំនួសក្នុងរយៈពេលមានសុពលភាព។ បើមិនកំណត់សិទ្ធិបន្ថែម តួនាទីប្រើសម្រាប់លំហូរសំណើប៉ុណ្ណោះ។ ការជំនួសផុតកំណត់តាមកាលបរិច្ឆេទកម្ពុជា។"
  ],
  [
   "現任",
   "Holder",
   "អ្នកកាន់តំណែង"
  ],
  [
   "職位空缺",
   "Vacant",
   "តួនាទីទំនេរ"
  ],
  [
   "編輯職位",
   "Edit position",
   "កែតួនាទី"
  ],
  [
   "設定期間代理",
   "Set temporary delegation",
   "កំណត់ការជំនួសបណ្តោះអាសន្ន"
  ],
  [
   "已撤銷",
   "Revoked",
   "បានដកហូត"
  ],
  [
   "已到期",
   "Expired",
   "ផុតកំណត់"
  ],
  [
   "尚未開始",
   "Not started",
   "មិនទាន់ចាប់ផ្តើម"
  ],
  [
   "期間內",
   "In period",
   "ក្នុងរយៈពេល"
  ],
  [
   "撤銷代理",
   "Revoke delegate",
   "ដកហូតអ្នកជំនួស"
  ],
  [
   "尚未設定固定職位",
   "No positions configured",
   "មិនទាន់កំណត់តួនាទី"
  ],
  [
   "依已確認的人員與職務建立，沒有預先指定任何人。",
   "Create positions using confirmed assignments. Nobody is assigned automatically.",
   "បង្កើតតាមការចាត់តាំងដែលបានបញ្ជាក់។ មិនចាត់តាំងនរណាដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "前往簽核路線，使用已建立的職位 →",
   "Use positions in approval routes →",
   "ប្រើតួនាទីក្នុងលំហូរអនុម័ត →"
  ],
  [
   "此公司尚無對應角色的在職帳號，可先保留空缺。",
   "No active account with this company and role. The position can remain vacant.",
   "មិនមានគណនីសមស្រប។ អាចទុកតួនាទីទំនេរ។"
  ],
  [
   "設定固定職位",
   "Configure position",
   "កំណត់តួនាទី"
  ],
  [
   "職位名稱，例如財務主管",
   "Position name, e.g. Finance Manager",
   "ឈ្មោះតួនាទី ឧ. ប្រធានហិរញ្ញវត្ថុ"
  ],
  [
   "任職者（可空缺）",
   "Holders (may be vacant)",
   "អ្នកកាន់តំណែង (អាចទំនេរ)"
  ],
  [
   "此職位的額外功能權限（選填）",
   "Additional function access (optional)",
   "សិទ្ធិមុខងារបន្ថែម (ស្រេចចិត្ត)"
  ],
  [
   "設定原因",
   "Reason for configuration",
   "មូលហេតុកំណត់"
  ],
  [
   "撤銷期間代理",
   "Revoke delegation",
   "ដកហូតការជំនួស"
  ],
  [
   "代理人",
   "Delegate",
   "អ្នកជំនួស"
  ],
  [
   "開始日期",
   "Start date",
   "ថ្ងៃចាប់ផ្តើម"
  ],
  [
   "已確認此人、職位與代理期間的授權",
   "This person, position and period are authorized",
   "បានអនុញ្ញាតបុគ្គល តួនាទី និងរយៈពេលនេះ"
  ],
  [
   "授權／撤銷原因",
   "Authorization / revocation reason",
   "មូលហេតុអនុញ្ញាត / ដកហូត"
  ],
  [
   "考核待你處理",
   "Performance actions due",
   "ការវាយតម្លៃរង់ចាំអ្នក"
  ],
  [
   "查看目標與評核",
   "Open goals and assessments",
   "មើលគោលដៅ និងការវាយតម្លៃ"
  ],
  [
   "主管訂目標 → 上層確認 → 員工查看 → 兩層主管分別評分。",
   "Set goals → confirm them → employee views goals → two separate manager assessments.",
   "កំណត់គោលដៅ → ថ្នាក់លើបញ្ជាក់ → បុគ្គលិកមើល → អ្នកគ្រប់គ្រងពីរវាយតម្លៃ។"
  ],
  [
   "訂定員工目標",
   "Set employee goals",
   "កំណត់គោលដៅបុគ្គលិក"
  ],
  [
   "可查看的考核",
   "Accessible plans",
   "ការវាយតម្លៃអាចមើល"
  ],
  [
   "上層主管",
   "Second level",
   "ថ្នាក់លើ"
  ],
  [
   "查看目標與進度",
   "View goals and progress",
   "មើលគោលដៅ និងវឌ្ឍនភាព"
  ],
  [
   "尚無考核紀錄",
   "No performance plans",
   "មិនមានកំណត់ត្រាវាយតម្លៃ"
  ],
  [
   "由員工的直屬主管建立；不預填目標、分數或評核人。",
   "An employee’s line manager creates the plan. Goals, scores and reviewers are not prefilled.",
   "អ្នកគ្រប់គ្រងផ្ទាល់បង្កើតគោលដៅ។ មិនបំពេញគោលដៅ ពិន្ទុ ឬអ្នកវាយតម្លៃជាមុនទេ។"
  ],
  [
   "尚需確認的主管／帳號",
   "Reporting lines / accounts to confirm",
   "អ្នកគ្រប់គ្រង / គណនីត្រូវបញ្ជាក់"
  ],
  [
   "需有兩層不同主管，並開通該公司帳號。沒有合適人選時不自動派給 CEO。",
   "Two different managers need enabled accounts and company access. No automatic CEO fallback.",
   "ត្រូវមានអ្នកគ្រប់គ្រងពីរផ្សេងគ្នា មានគណនី និងសិទ្ធិក្រុមហ៊ុន។ មិនបញ្ជូនទៅ CEO ស្វ័យប្រវត្តិទេ។"
  ],
  [
   "設定主管",
   "Set reporting line",
   "កំណត់អ្នកគ្រប់គ្រង"
  ],
  [
   "直屬主管訂目標",
   "Set goals",
   "កំណត់គោលដៅ"
  ],
  [
   "上層確認",
   "Confirm goals",
   "បញ្ជាក់គោលដៅ"
  ],
  [
   "直屬主管評分",
   "Line-manager assessment",
   "ការវាយតម្លៃអ្នកគ្រប់គ្រងផ្ទាល់"
  ],
  [
   "上層主管評分",
   "Second-level assessment",
   "ការវាយតម្លៃថ្នាក់លើ"
  ],
  [
   "本份考核每項滿分",
   "Maximum score per goal",
   "ពិន្ទុអតិបរមាតាមគោលដៅ"
  ],
  [
   "主管關係或帳號尚未齊備，確認後才能送審或評分。",
   "Reporting lines or accounts are incomplete. Resolve them before submission or assessment.",
   "អ្នកគ្រប់គ្រង ឬគណនីមិនទាន់ពេញលេញ។ បំពេញមុនផ្ញើ ឬវាយតម្លៃ។"
  ],
  [
   "各項分數 × 目標比重後加總；這是本層分數，尚非兩層合成總分。",
   "Sum of each goal score × its weight. This is this reviewer’s score, not a combined final score.",
   "ផលបូកពិន្ទុគុណនឹងទម្ងន់។ នេះជាពិន្ទុអ្នកវាយតម្លៃនេះ មិនមែនពិន្ទុសរុបទាំងពីរទេ។"
  ],
  [
   "兩層分數分開保留。合成方式、等第與薪酬影響待確認，不會自動調薪。",
   "Both assessments are retained separately. Combined scoring, grades and pay consequences are pending; no automatic pay changes.",
   "រក្សាពិន្ទុទាំងពីរដាច់ដោយឡែក។ ការបូក ថ្នាក់ និងប្រាក់ខែរង់ចាំបញ្ជាក់។ មិនកែប្រាក់ខែស្វ័យប្រវត្តិទេ។"
  ],
  [
   "處理紀錄",
   "Audit trail",
   "ប្រវត្តិដំណើរការ"
  ],
  [
   "工作類別",
   "Work category",
   "ប្រភេទការងារ"
  ],
  [
   "目標比重 (%)",
   "Goal weight (%)",
   "ទម្ងន់គោលដៅ (%)"
  ],
  [
   "目標名稱",
   "Goal title",
   "ឈ្មោះគោលដៅ"
  ],
  [
   "要完成什麼／如何判斷",
   "Expected outcome / how to measure",
   "លទ្ធផលរំពឹង / វិធីវាស់វែង"
  ],
  [
   "移除此目標",
   "Remove goal",
   "លុបគោលដៅ"
  ],
  [
   "訂定考核目標",
   "Set performance goals",
   "កំណត់គោលដៅវាយតម្លៃ"
  ],
  [
   "考核員工",
   "Employee",
   "បុគ្គលិក"
  ],
  [
   "考核名稱",
   "Plan title",
   "ឈ្មោះការវាយតម្លៃ"
  ],
  [
   "期間開始",
   "Period start",
   "ចាប់ផ្តើមរយៈពេល"
  ],
  [
   "期間結束",
   "Period end",
   "បញ្ចប់រយៈពេល"
  ],
  [
   "每項滿分（由上層一併確認）",
   "Maximum score per goal (confirmed with goals)",
   "ពិន្ទុអតិបរមា (បញ្ជាក់ជាមួយគោលដៅ)"
  ],
  [
   "請依已討論的期間與評分尺度填寫，不預設月考核或百分制。目標比重合計需為 100%。",
   "Use the discussed period and scoring scale. No monthly or 100-point scale is assumed. Weights must total 100%.",
   "ប្រើរយៈពេល និងមាត្រដ្ឋានដែលបានពិភាក្សា។ មិនកំណត់ប្រចាំខែ ឬ១០០ពិន្ទុជាមុន។ ទម្ងន់សរុប១០០%។"
  ],
  [
   "新增目標",
   "Add goal",
   "បន្ថែមគោលដៅ"
  ],
  [
   "儲存目標草稿",
   "Save goal draft",
   "រក្សាព្រាងគោលដៅ"
  ],
  [
   "分數／滿分 ",
   "Score / maximum ",
   "ពិន្ទុ / អតិបរមា "
  ],
  [
   "實際成果／評分依據",
   "Observed outcome / scoring evidence",
   "លទ្ធផល / មូលដ្ឋានពិន្ទុ"
  ],
  [
   "將整份目標、比重、期間及滿分送交上層確認，送出後不能直接修改。",
   "Submit the goals, weights, period and scale for confirmation. Editing is locked after submission.",
   "ផ្ញើគោលដៅ ទម្ងន់ រយៈពេល និងមាត្រដ្ឋានដើម្បីបញ្ជាក់។ មិនអាចកែផ្ទាល់ក្រោយផ្ញើ។"
  ],
  [
   "本層整體評語",
   "Overall assessment",
   "មតិវាយតម្លៃទូទៅ"
  ],
  [
   "送出後交由上層評核，不能直接修改。",
   "Submission sends this assessment to the next manager and locks editing.",
   "ក្រោយផ្ញើ ការវាយតម្លៃទៅថ្នាក់លើ ហើយចាក់សោការកែ។"
  ],
  [
   "完成後，員工可查看兩層主管的結果。",
   "After completion, the employee can view both assessments.",
   "ក្រោយបញ្ចប់ បុគ្គលិកអាចមើលលទ្ធផលទាំងពីរ។"
  ],
  [
   "送交上層評核",
   "Submit for second review",
   "ផ្ញើទៅវាយតម្លៃទីពីរ"
  ],
  [
   "完成本期評核",
   "Complete this assessment",
   "បញ្ចប់ការវាយតម្លៃនេះ"
  ],
  [
   "設定分類",
   "Settings sections",
   "ផ្នែកការកំណត់"
  ],
  [
   "帳號與權限",
   "Accounts and access",
   "គណនី និងសិទ្ធិ"
  ],
  [
   "職位與代理",
   "Positions and delegates",
   "តួនាទី និងអ្នកជំនួស"
  ],
  [
   "會議待確認",
   "Pending decisions",
   "ចំណុចរង់ចាំ"
  ],
  [
   "最多 20 項目標。",
   "Maximum 20 goals.",
   "អតិបរមា២០គោលដៅ។"
  ],
  [
   "尚無已確認合成規則。本份考核將保留兩層分數，不自動產生合成總分。",
   "No combined-score policy is confirmed. This plan will retain separate scores without a combined total.",
   "មិនទាន់បញ្ជាក់ច្បាប់បូកពិន្ទុ។ ផែនការនេះរក្សាពិន្ទុពីរដាច់ដោយឡែក។"
  ],
  [
   "考核結果",
   "Assessment result",
   "លទ្ធផលវាយតម្លៃ"
  ],
  [
   "合成總分",
   "Combined score",
   "ពិន្ទុសរុប"
  ],
  [
   "各層原分數保留；總分四捨五入至小數點後兩位。等第與薪酬連動仍需另行確認，不會自動調薪。",
   "Original scores are retained. The combined total is rounded to two decimal places. Grades and pay consequences require separate decisions; no automatic salary change.",
   "រក្សាពិន្ទុដើម។ ពិន្ទុសរុបបង្គត់ពីរខ្ទង់ទសភាគ។ ថ្នាក់ និងប្រាក់ខែត្រូវបញ្ជាក់ដោយឡែក មិនកែប្រាក់ខែស្វ័យប្រវត្តិ។"
  ],
  [
   "考核合成規則",
   "Combined assessment policy",
   "គោលការណ៍ពិន្ទុសរុប"
  ],
  [
   "每家公司確認兩層主管各占多少。規則只套用於之後確認目標的考核。",
   "Confirm each manager’s share by company. Rules apply only when goals are subsequently confirmed.",
   "បញ្ជាក់ទម្ងន់អ្នកគ្រប់គ្រងតាមក្រុមហ៊ុន។ អនុវត្តតែគោលដៅដែលបញ្ជាក់ក្រោយ។"
  ],
  [
   "設定合成比重",
   "Configure weights",
   "កំណត់ទម្ងន់"
  ],
  [
   "已確認",
   "Confirmed",
   "បានបញ្ជាក់"
  ],
  [
   "修改",
   "Edit",
   "កែ"
  ],
  [
   "尚未確認合成比重",
   "Weights not confirmed",
   "មិនទាន់បញ្ជាក់ទម្ងន់"
  ],
  [
   "沒有預設 50／50 或任何等第；先保留兩層分數。",
   "No default 50/50 split or grades. Both scores remain separate.",
   "មិនកំណត់៥០/៥០ ឬថ្នាក់ជាមុន។ រក្សាពិន្ទុពីរដាច់ដោយឡែក។"
  ],
  [
   "設定兩層考核比重",
   "Configure assessment weights",
   "កំណត់ទម្ងន់ការវាយតម្លៃ"
  ],
  [
   "直屬主管比重 (%)",
   "Line-manager weight (%)",
   "ទម្ងន់អ្នកគ្រប់គ្រងផ្ទាល់ (%)"
  ],
  [
   "上層主管比重 (%)",
   "Second-level weight (%)",
   "ទម្ងន់ថ្នាក់លើ (%)"
  ],
  [
   "兩層均需有比重，合計 100%。停用不會修改已確認目標的考核。",
   "Both levels need a weight totaling 100%. Disabling does not change plans with confirmed goals.",
   "កម្រិតទាំងពីរត្រូវមានទម្ងន់ សរុប១០០%។ បិទមិនប្តូរផែនការដែលបញ្ជាក់ហើយទេ។"
  ],
  [
   "已確認本公司的合成方式",
   "The company has confirmed this scoring method",
   "ក្រុមហ៊ុនបានបញ្ជាក់វិធីគណនានេះ"
  ],
  [
   "設定原因／依據",
   "Reason / basis",
   "មូលហេតុ / មូលដ្ឋាន"
  ],
  [
   "合成比重與規則",
   "Assessment weights and rules",
   "ទម្ងន់ និងច្បាប់វាយតម្លៃ"
  ],
  [
   "查看與處理",
   "View and process",
   "មើល និងដំណើរការ"
  ],
  [
   "人事異動",
   "Employment changes",
   "ការផ្លាស់ប្តូរបុគ្គលិក"
  ],
  [
   "待複核／核准",
   "In review / approval",
   "រង់ចាំពិនិត្យ / អនុម័ត"
  ],
  [
   "核准待生效",
   "Approved, awaiting application",
   "អនុម័ត រង់ចាំអនុវត្ត"
  ],
  [
   "簽核路線尚未設定；可先準備草稿。",
   "Approval routes not configured; drafts can be prepared.",
   "មិនទាន់កំណត់លំហូរអនុម័ត អាចរៀបចំព្រាង។"
  ],
  [
   "排班與崗位",
   "Staffing and posts",
   "រៀបចំមនុស្ស និងតួនាទី"
  ],
  [
   "待發布班次",
   "Shifts awaiting publication",
   "វេនរង់ចាំផ្សព្វផ្សាយ"
  ],
  [
   "尚未滿員班次",
   "Understaffed shifts",
   "វេនខ្វះបុគ្គលិក"
  ],
  [
   "工作區或崗位尚未設定。",
   "Work areas or posts not configured.",
   "មិនទាន់កំណត់តំបន់ ឬតួនាទី។"
  ],
  [
   "執行中／退回改善",
   "In progress / returned",
   "កំពុងអនុវត្ត / ត្រឡប់កែ"
  ],
  [
   "待主管驗收",
   "Awaiting acceptance",
   "រង់ចាំទទួលយក"
  ],
  [
   "尚無已安排的交辦工作。",
   "No tasks assigned yet.",
   "មិនទាន់ចាត់តាំងកិច្ចការ។"
  ],
  [
   "目標與考核",
   "Goals and assessments",
   "គោលដៅ និងវាយតម្លៃ"
  ],
  [
   "目標待確認",
   "Goals awaiting confirmation",
   "គោលដៅរង់ចាំបញ្ជាក់"
  ],
  [
   "評核中",
   "Assessment in progress",
   "កំពុងវាយតម្លៃ"
  ],
  [
   "已完成評核",
   "Assessments completed",
   "វាយតម្លៃបានបញ្ចប់"
  ],
  [
   "顯示流程筆數，並非績效分數。",
   "Workflow counts, not performance scores.",
   "ចំនួនលំហូរ មិនមែនពិន្ទុប្រសិទ្ធភាព។"
  ],
  [
   "尚未建立考核目標。",
   "Assessment goals not set.",
   "មិនទាន់កំណត់គោលដៅវាយតម្លៃ។"
  ],
  [
   "帳套",
   "Accounting book",
   "បញ្ជីគណនេយ្យ"
  ],
  [
   "尚未設定",
   "Not configured",
   "មិនទាន់កំណត់"
  ],
  [
   "已入帳收入",
   "Posted revenue",
   "ចំណូលបានកត់ត្រា"
  ],
  [
   "已入帳費用",
   "Posted expenses",
   "ចំណាយបានកត់ត្រា"
  ],
  [
   "帳面損益",
   "Recorded profit / loss",
   "ចំណេញ / ខាតក្នុងបញ្ជី"
  ],
  [
   "尚無已入帳報表資料；不以申請金額代替。",
   "No posted report data yet; request amounts are excluded.",
   "មិនទាន់មានរបាយការណ៍កត់ត្រា មិនប្រើចំនួនទឹកប្រាក់សំណើជំនួស។"
  ],
  [
   "公司工作進度",
   "Company operations progress",
   "វឌ្ឍនភាពការងារក្រុមហ៊ុន"
  ],
  [
   "各項工作進度",
   "Operations progress",
   "វឌ្ឍនភាពការងារ"
  ],
  [
   "目前可查看的公司與資料",
   "Companies and records you can access",
   "ក្រុមហ៊ុន និងទិន្នន័យដែលអ្នកអាចមើល"
  ],
  [
   "各公司財務 · 分別列示幣別",
   "Company finances · currencies kept separate",
   "ហិរញ្ញវត្ថុតាមក្រុមហ៊ុន · រូបិយប័ណ្ណដាច់ដោយឡែក"
  ],
  [
   "僅管理員可設定權限",
   "Administrator access required",
   "ត្រូវការសិទ្ធិអ្នកគ្រប់គ្រង"
  ],
  [
   "公司與功能權限",
   "Company and function access",
   "សិទ្ធិក្រុមហ៊ុន និងមុខងារ"
  ],
  [
   "每家公司分別設定：看什麼、做什麼。本人打卡與申請仍保留。",
   "Set what each account can see and do per company. Personal attendance and requests remain available.",
   "កំណត់សិទ្ធិមើល និងធ្វើតាមក្រុមហ៊ុន។ ការចុះវត្តមាន និងសំណើផ្ទាល់ខ្លួននៅតែមាន។"
  ],
  [
   "已按公司細分",
   "Company-specific access",
   "សិទ្ធិតាមក្រុមហ៊ុន"
  ],
  [
   "目前沿用原角色權限",
   "Using existing role access",
   "កំពុងប្រើសិទ្ធិតួនាទីដើម"
  ],
  [
   "只有本人作業或未授權",
   "Personal access only / no grant",
   "សិទ្ធិផ្ទាល់ខ្លួន ឬមិនបានផ្តល់សិទ្ធិ"
  ],
  [
   "設定",
   "Configure",
   "កំណត់"
  ],
  [
   "職位授權與有效期間內的代理會另外累加。要撤銷職位帶來的權限，請調整該職位或撤銷代理。",
   "Position grants and active delegations add access. Change the position or revoke delegation to remove it.",
   "សិទ្ធិតួនាទី និងអ្នកជំនួសមានសុពលភាពបន្ថែមសិទ្ធិ។ កែតួនាទី ឬដកអ្នកជំនួសដើម្បីលុបសិទ្ធិនោះ។"
  ],
  [
   "設定公司與功能權限",
   "Configure company access",
   "កំណត់សិទ្ធិក្រុមហ៊ុន"
  ],
  [
   "這家公司中的職務類型",
   "Role in this company",
   "តួនាទីនៅក្រុមហ៊ុននេះ"
  ],
  [
   "下方勾選決定實際操作權限。只設定這家公司，不改變薪資歸屬；一般寫入權限包含查看；採購只勾新增／編輯時限本人申請。",
   "The selected actions determine access for this company only. Payroll employer stays unchanged. Write access includes view; purchase create/edit alone is limited to own requests.",
   "ជម្រើសខាងក្រោមកំណត់សិទ្ធិសម្រាប់ក្រុមហ៊ុននេះ។ ក្រុមហ៊ុនបើកប្រាក់ខែមិនផ្លាស់ប្តូរ។"
  ],
  [
   "儲存後，該帳號需重新登入。全不勾選表示不開放管理功能。",
   "After saving, this account must sign in again. Leave all unchecked to grant no management functions.",
   "បន្ទាប់ពីរក្សាទុក គណនីត្រូវចូលម្តងទៀត។ មិនជ្រើសមានន័យថាមិនផ្តល់សិទ្ធិគ្រប់គ្រង។"
  ],
  [
   "公司 × 功能 × 操作",
   "Company × function × action",
   "ក្រុមហ៊ុន × មុខងារ × សកម្មភាព"
  ],
  [
   "人資可以只管考勤，另一位只管考核；各公司分別授權。",
   "One HR colleague can manage attendance, another performance, with access set per company.",
   "មន្ត្រី HR ម្នាក់គ្រប់គ្រងវត្តមាន ម្នាក់ទៀតគ្រប់គ្រងការវាយតម្លៃ តាមក្រុមហ៊ុន។"
  ],
  [
   "設定功能權限 →",
   "Configure access →",
   "កំណត់សិទ្ធិ →"
  ],
  [
   "人事異動清單",
   "Employment changes",
   "បញ្ជីការផ្លាស់ប្តូរបុគ្គលិក"
  ],
  [
   "生效日",
   "Effective date",
   "ថ្ងៃចូលជាធរមាន"
  ],
  [
   "未指定",
   "Unassigned",
   "មិនទាន់កំណត់"
  ],
  [
   "接收公司",
   "Receiving employer",
   "ក្រុមហ៊ុនទទួល"
  ],
  [
   "找不到此異動",
   "Change not available",
   "រកមិនឃើញការផ្លាស់ប្តូរ"
  ],
  [
   "人事異動分類",
   "Employment workflow sections",
   "ផ្នែកការផ្លាស់ប្តូរ"
  ],
  [
   "異動申請",
   "Requests",
   "សំណើ"
  ],
  [
   "生效紀錄",
   "Applied history",
   "ប្រវត្តិអនុវត្ត"
  ],
  [
   "複核與核准路線",
   "Review and approval routes",
   "លំហូរពិនិត្យ និងអនុម័ត"
  ],
  [
   "填寫 → 複核修正 → 分層核准 → 到期套用。每一步保留紀錄。",
   "Prepare → review and correct → approve → apply when due. Every step is recorded.",
   "បំពេញ → ពិនិត្យ និងកែ → អនុម័ត → អនុវត្តពេលដល់ថ្ងៃ។ រក្សាប្រវត្តិគ្រប់ជំហាន។"
  ],
  [
   "新增人事異動",
   "New employment change",
   "បន្ថែមការផ្លាស់ប្តូរ"
  ],
  [
   "異動",
   "Change",
   "ការផ្លាស់ប្តូរ"
  ],
  [
   "套用人",
   "Applied by",
   "អ្នកអនុវត្ត"
  ],
  [
   "紀錄",
   "Record",
   "កំណត់ត្រា"
  ],
  [
   "查看前後內容",
   "View before / after",
   "មើលមុន / ក្រោយ"
  ],
  [
   "尚無已生效異動",
   "No applied changes",
   "មិនទាន់មានការផ្លាស់ប្តូរបានអនុវត្ត"
  ],
  [
   "已生效",
   "Applied",
   "បានអនុវត្ត"
  ],
  [
   "異動核准後，名冊仍會保留原資料，直到授權人員在生效日套用。到職不會自動開帳號；離職會停用帳號；跨公司調動需重新審核帳號權限。",
   "Approval preserves the current roster until an authorized person applies the change on or after its effective date. Hires do not create accounts. Departures disable accounts; employer transfers require a fresh access review.",
   "ទិន្នន័យនៅដដែលរហូតអ្នកមានសិទ្ធិអនុវត្តនៅថ្ងៃកំណត់។ បុគ្គលិកថ្មីមិនបង្កើតគណនីស្វ័យប្រវត្តិ។ លាឈប់បិទគណនី; ផ្ទេរក្រុមហ៊ុនត្រូវពិនិត្យសិទ្ធិឡើងវិញ។"
  ],
  [
   "員工／種類",
   "Employee / change",
   "បុគ្គលិក / ការផ្លាស់ប្តូរ"
  ],
  [
   "查看／處理",
   "View / process",
   "មើល / ដំណើរការ"
  ],
  [
   "尚無人事異動申請",
   "No employment requests",
   "មិនទាន់មានសំណើបុគ្គលិក"
  ],
  [
   "填寫示範資料建立草稿；路線確認後才能送審。",
   "Create a draft using verified details. A confirmed route is required before submission.",
   "បង្កើតសេចក្តីព្រាងដោយព័ត៌មានពិត។ ត្រូវបញ្ជាក់លំហូរមុនផ្ញើ។"
  ],
  [
   "異動原因",
   "Reason for change",
   "មូលហេតុ"
  ],
  [
   "目前路線未設定，或缺少互相獨立的複核／核准人員。可先儲存草稿，確認授權後再送審。",
   "The route is unconfigured or lacks independent reviewers and approvers. Save a draft, then confirm the assignments before submitting.",
   "លំហូរមិនទាន់កំណត់ ឬខ្វះអ្នកពិនិត្យ និងអនុម័តឯករាជ្យ។ អាចរក្សាព្រាង រួចបញ្ជាក់ការចាត់តាំង។"
  ],
  [
   "尚未到生效日，系統不會提前修改名冊。",
   "The effective date has not arrived; the roster will not change early.",
   "មិនទាន់ដល់ថ្ងៃអនុវត្ត ទិន្នន័យមិនប្តូរមុនទេ។"
  ],
  [
   "已到生效日；按「套用生效」才會更新名冊／薪資。",
   "The effective date has arrived. Apply the approved change to update employment or pay.",
   "ដល់ថ្ងៃហើយ។ ចុចអនុវត្តដើម្បីប្តូរទិន្នន័យបុគ្គលិក ឬប្រាក់ខែ។"
  ],
  [
   "本次簽核路線",
   "This request’s route",
   "លំហូរសំណើនេះ"
  ],
  [
   "申請人、修正人與當事人不能核准自己的異動；不同層由不同人處理。",
   "Applicants, editors and affected employees cannot approve their own change. Each stage requires a different person.",
   "អ្នកស្នើ អ្នកកែ និងបុគ្គលិកពាក់ព័ន្ធមិនអនុម័តការផ្លាស់ប្តូរខ្លួនឯងទេ។ កម្រិតនីមួយៗត្រូវជាមនុស្សផ្សេង។"
  ],
  [
   "任職公司",
   "Employer",
   "និយោជក"
  ],
  [
   "在職狀態",
   "Employment status",
   "ស្ថានភាពការងារ"
  ],
  [
   "到職日",
   "Start date",
   "ថ្ងៃចូលធ្វើការ"
  ],
  [
   "離職日",
   "End date",
   "ថ្ងៃលាឈប់"
  ],
  [
   "轉正日",
   "Confirmation date",
   "ថ្ងៃបញ្ជាក់"
  ],
  [
   "生效前後",
   "Before and after",
   "មុន និងក្រោយ"
  ],
  [
   "原資料",
   "Before",
   "មុន"
  ],
  [
   "生效後",
   "After",
   "ក្រោយ"
  ],
  [
   "時間",
   "Time",
   "ពេលវេលា"
  ],
  [
   "人員",
   "Actor",
   "អ្នកដំណើរការ"
  ],
  [
   "動作",
   "Action",
   "សកម្មភាព"
  ],
  [
   "說明",
   "Note",
   "កំណត់សម្គាល់"
  ],
  [
   "每家公司、每種異動分別設定。複核可以修正資料，核准只能決定；至少一層複核加一層核准。新設定不改寫已送出的路線。",
   "Configure each company and change type. Reviewers can correct details; approvers decide. At least one review and one approval are required. Changes do not rewrite submitted routes.",
   "កំណត់តាមក្រុមហ៊ុន និងប្រភេទ។ អ្នកពិនិត្យអាចកែ អ្នកអនុម័តសម្រេច។ យ៉ាងហោចណាស់មួយពិនិត្យ និងមួយអនុម័ត។ មិនប្តូរលំហូរដែលបានផ្ញើទេ។"
  ],
  [
   "設定異動路線",
   "Configure route",
   "កំណត់លំហូរ"
  ],
  [
   "異動種類",
   "Change type",
   "ប្រភេទ"
  ],
  [
   "路線",
   "Route",
   "លំហូរ"
  ],
  [
   "已啟用",
   "Enabled",
   "បើក"
  ],
  [
   "尚未確認簽核路線",
   "No routes confirmed",
   "មិនទាន់បញ្ជាក់លំហូរ"
  ],
  [
   "尚無新增異動權限",
   "No permission to create changes",
   "គ្មានសិទ្ធិបន្ថែម"
  ],
  [
   "複核修正",
   "Correct during review",
   "កែពេលពិនិត្យ"
  ],
  [
   "人事異動申請",
   "Employment change request",
   "សំណើផ្លាស់ប្តូរបុគ្គលិក"
  ],
  [
   "儲存不會變更名冊；送審、核准和套用是不同步驟。",
   "Saving does not update employment. Submission, approval and application are separate steps.",
   "រក្សាទុកមិនប្តូរបញ្ជីបុគ្គលិកទេ។ ផ្ញើ អនុម័ត និងអនុវត្តជាជំហានផ្សេងគ្នា។"
  ],
  [
   "儲存複核修正",
   "Save corrections",
   "រក្សាទុកការកែ"
  ],
  [
   "儲存草稿",
   "Draft saved",
   "រក្សាព្រាង"
  ],
  [
   "原文姓名",
   "Native name",
   "ឈ្មោះដើម"
  ],
  [
   "到職後仍需管理員另外建立帳號。初始薪資另送「調整薪資」，僅薪資授權人員可見。",
   "After hiring, an administrator must create the login separately. Set initial pay through a salary adjustment visible only to authorized payroll staff.",
   "ក្រោយចូលធ្វើការ អ្នកគ្រប់គ្រងបង្កើតគណនីដោយឡែក។ ប្រាក់ខែដើមត្រូវស្នើកែប្រាក់ខែ សម្រាប់អ្នកមានសិទ្ធិប៉ុណ្ណោះ។"
  ],
  [
   "調動生效會保留舊任職與薪資來源紀錄、停用原登入。管理員重新確認新公司權限後才能啟用；薪資金額不會自動改變。",
   "Applying a transfer preserves prior employment and payroll provenance and disables the old login until access is reviewed. Salary amounts remain unchanged.",
   "ផ្ទេររក្សាប្រវត្តិការងារ និងប្រាក់ខែ ហើយបិទគណនីរហូតពិនិត្យសិទ្ធិឡើងវិញ។ ទឹកប្រាក់ខែមិនប្តូរទេ។"
  ],
  [
   "新部門",
   "Department after change",
   "ផ្នែកក្រោយផ្លាស់ប្តូរ"
  ],
  [
   "新職務",
   "Job after change",
   "មុខតំណែងក្រោយផ្លាស់ប្តូរ"
  ],
  [
   "工作、文件與設備的交接安排",
   "Work, document and equipment handover",
   "ការប្រគល់ការងារ ឯកសារ និងឧបករណ៍"
  ],
  [
   "新的基本薪資",
   "New base salary",
   "ប្រាក់ខែគោលថ្មី"
  ],
  [
   "新的津貼",
   "New allowance",
   "ប្រាក់ឧបត្ថម្ភថ្មី"
  ],
  [
   "新的服務費",
   "New service charge",
   "ប្រាក់សេវាថ្មី"
  ],
  [
   "只填要調整的欄位；留白保留原值，輸入 0 代表改為零。沿用名冊的薪資幣別；不計算實發薪資、稅金或社保。",
   "Fill only changed components. Blank preserves the current value; 0 sets zero. Uses the roster’s existing pay currency; does not calculate net pay, tax or social insurance.",
   "បំពេញតែចំណុចដែលប្តូរ។ ទទេទុកតម្លៃដដែល; ០ កំណត់ជាសូន្យ។ ប្រើរូបិយប័ណ្ណដើម មិនគណនាប្រាក់ខែសុទ្ធ ពន្ធ ឬសន្តិសុខសង្គម។"
  ],
  [
   "這個操作目前不可使用",
   "Action unavailable",
   "មិនអាចប្រើសកម្មភាពនេះ"
  ],
  [
   "既有核准失效，必須重新複核與核准；不會修改已生效的資料。",
   "Existing approvals are invalidated. A fresh review and approval is required. Applied employment history is unchanged.",
   "ការអនុម័តចាស់ត្រូវលុបចោល ហើយត្រូវពិនិត្យ និងអនុម័តឡើងវិញ។ ប្រវត្តិអនុវត្តរក្សាដដែល។"
  ],
  [
   "確認後會記錄處理人、時間與說明。",
   "The actor, timestamp and note will be recorded.",
   "កត់ត្រាអ្នកដំណើរការ ពេលវេលា និងមតិ។"
  ],
  [
   "沒有設定權限",
   "No configuration access",
   "គ្មានសិទ្ធិកំណត់"
  ],
  [
   "設定人事異動路線",
   "Configure employment route",
   "កំណត់លំហូរបុគ្គលិក"
  ],
  [
   "路線狀態",
   "Route status",
   "ស្ថានភាពលំហូរ"
  ],
  [
   "已確認這家公司的複核與核准安排",
   "These review and approval assignments have been confirmed",
   "បានបញ្ជាក់ការចាត់តាំងពិនិត្យ និងអនុម័ត"
  ],
  [
   "複核（可修正）",
   "Review (may correct)",
   "ពិនិត្យ (អាចកែ)"
  ],
  [
   "不使用此層",
   "No additional stage",
   "មិនប្រើកម្រិតនេះ"
  ],
  [
   "待複核",
   "Review needed",
   "រង់ចាំពិនិត្យ"
  ],
  [
   "待核准",
   "Approval needed",
   "រង់ចាំអនុម័ត"
  ],
  [
   "已核准補位",
   "Cover approved",
   "បានអនុម័តជំនួស"
  ],
  [
   "已安排",
   "Assigned",
   "បានចាត់តាំង"
  ],
  [
   "已交接",
   "Handed over",
   "បានប្រគល់"
  ],
  [
   "待完成",
   "To do",
   "ត្រូវធ្វើ"
  ],
  [
   "待驗收",
   "Awaiting verification",
   "រង់ចាំផ្ទៀងផ្ទាត់"
  ],
  [
   "已驗收",
   "Verified",
   "បានផ្ទៀងផ្ទាត់"
  ],
  [
   "已轉交",
   "Reassigned",
   "បានចាត់តាំងឡើងវិញ"
  ],
  [
   "開始時間",
   "Start",
   "ចាប់ផ្តើម"
  ],
  [
   "結束時間",
   "End",
   "បញ្ចប់"
  ],
  [
   "隔日結束",
   "Ends next day",
   "បញ្ចប់ថ្ងៃបន្ទាប់"
  ],
  [
   "時段工作（每行：HH:MM 工作內容）",
   "Timed duties (one per line: HH:MM description)",
   "ភារកិច្ចតាមម៉ោង (មួយក្នុងមួយបន្ទាត់: HH:MM ការងារ)"
  ],
  [
   "工時／休息規則尚未確認，未進行完整規則檢查。",
   "Work/rest limits are not configured; full rule checks are unavailable.",
   "មិនទាន់កំណត់ម៉ោងការងារ/សម្រាក មិនអាចពិនិត្យច្បាប់ពេញលេញ។"
  ],
  [
   "班次重疊",
   "Overlapping shifts",
   "វេនជាន់គ្នា"
  ],
  [
   "超過已設定週工時",
   "Exceeds configured weekly hours",
   "លើសម៉ោងប្រចាំសប្តាហ៍"
  ],
  [
   "休息間隔不足",
   "Rest interval too short",
   "ចន្លោះសម្រាកខ្លីពេក"
  ],
  [
   "崗位排班與工作回報",
   "Staffing and duties",
   "រៀបចំមនុស្ស និងភារកិច្ច"
  ],
  [
   "先定工作區、崗位與需求，再排人、送審、發布。",
   "Define areas, posts and staffing needs, then assign, review and publish.",
   "កំណត់តំបន់ តួនាទី និងតម្រូវការ រួចចាត់តាំង ពិនិត្យ និងផ្សព្វផ្សាយ។"
  ],
  [
   "班表與打卡",
   "Schedules and clock-in",
   "កាលវិភាគ និងចុះម៉ោង"
  ],
  [
   "人力安排",
   "Staffing",
   "រៀបចំមនុស្ស"
  ],
  [
   "工作回報",
   "Work completion",
   "រាយការណ៍ការងារ"
  ],
  [
   "崗位與規則",
   "Posts and rules",
   "តួនាទី និងច្បាប់"
  ],
  [
   "服務公司",
   "Service company",
   "ក្រុមហ៊ុនសេវា"
  ],
  [
   "匯出整月班表 CSV",
   "Export monthly CSV",
   "នាំចេញ CSV ប្រចាំខែ"
  ],
  [
   "新增人力需求",
   "Add staffing need",
   "បន្ថែមតម្រូវការមនុស្ស"
  ],
  [
   "先在「崗位與規則」指定複核人和核准人。尚未設定時可準備草稿，不能直接發布。",
   "Set the reviewer and approver in Posts and rules. Draft preparation is available; publication waits for configuration.",
   "កំណត់អ្នកពិនិត្យ និងអនុម័តក្នុងតួនាទី និងច្បាប់។ អាចរៀបចំព្រាង តែមិនអាចផ្សព្វផ្សាយ។"
  ],
  [
   "這個月份尚無崗位排班需求。",
   "No staffing needs for this month.",
   "មិនមានតម្រូវការមនុស្សសម្រាប់ខែនេះ។"
  ],
  [
   "服務公司與工作區不會改變員工的任職公司或薪資歸屬。已發布安排會出現在班表；工作回報不代替上、下班打卡。",
   "Service company and work area never change payroll employer. Published assignments appear in attendance schedules; work completion does not replace clock-in/out.",
   "ក្រុមហ៊ុនសេវា និងតំបន់មិនផ្លាស់ប្តូរនិយោជកប្រាក់ខែ។ កាលវិភាគផ្សព្វផ្សាយបង្ហាញក្នុងវត្តមាន ការរាយការណ៍ការងារមិនជំនួសការចុះម៉ោង។"
  ],
  [
   "需要",
   "Need",
   "ត្រូវការ"
  ],
  [
   "已排",
   "Assigned",
   "បានចាត់តាំង"
  ],
  [
   "缺口",
   "Gap",
   "ខ្វះ"
  ],
  [
   "任職／薪資公司",
   "Employer / payroll company",
   "ក្រុមហ៊ុននិយោជក / ប្រាក់ខែ"
  ],
  [
   "移除安排",
   "Remove assignment",
   "ដកការចាត់តាំង"
  ],
  [
   "臨時補位",
   "Emergency cover",
   "ជំនួសបន្ទាន់"
  ],
  [
   "安排員工",
   "Assign employee",
   "ចាត់តាំងបុគ្គលិក"
  ],
  [
   "修改需求",
   "Edit need",
   "កែតម្រូវការ"
  ],
  [
   "送交複核",
   "Submit for review",
   "បញ្ជូនពិនិត្យ"
  ],
  [
   "複核通過",
   "Reviewed",
   "បានពិនិត្យ"
  ],
  [
   "核准並發布",
   "Approve and publish",
   "អនុម័ត និងផ្សព្វផ្សាយ"
  ],
  [
   "流程紀錄",
   "History",
   "ប្រវត្តិ"
  ],
  [
   "送審",
   "Submitted",
   "ដាក់ស្នើ"
  ],
  [
   "核准發布",
   "Published",
   "ផ្សព្វផ្សាយ"
  ],
  [
   "新增",
   "Add",
   "បន្ថែម"
  ],
  [
   "工作區",
   "Work area",
   "តំបន់ការងារ"
  ],
  [
   "部門與崗位",
   "Department posts",
   "តួនាទីតាមផ្នែក"
  ],
  [
   "崗位班別模板",
   "Post shift template",
   "គំរូវេនតួនាទី"
  ],
  [
   "簽核與工時規則",
   "Approval and work rules",
   "អនុម័ត និងច្បាប់ម៉ោង"
  ],
  [
   "複核人",
   "Reviewer",
   "អ្នកពិនិត្យ"
  ],
  [
   "核准人",
   "Approver",
   "អ្នកអនុម័ត"
  ],
  [
   "每週上限（分鐘）",
   "Weekly limit (minutes)",
   "កម្រិតសប្តាហ៍ (នាទី)"
  ],
  [
   "最短休息（分鐘）",
   "Minimum rest (minutes)",
   "សម្រាកអប្បបរមា (នាទី)"
  ],
  [
   "已啟用流程",
   "Workflow enabled",
   "បានបើកលំហូរ"
  ],
  [
   "尚未啟用流程",
   "Workflow not enabled",
   "មិនទាន់បើកលំហូរ"
  ],
  [
   "待確認：共用打卡設備的身分驗證、現場 GPS 驗收、國定假日與假勤規則、PMS 工作項目分工。這裡不預設法定工時、扣薪或加班計薪。",
   "Pending: shared-device identity checks, on-site GPS acceptance, holiday/leave rules and PMS work ownership. Statutory hours, deductions and overtime pay are not assumed here.",
   "ត្រូវបញ្ជាក់៖ អត្តសញ្ញាណឧបករណ៍រួម ការសាក GPS ច្បាប់ថ្ងៃឈប់/ច្បាប់ និងការងារ PMS។ មិនសន្មតម៉ោងច្បាប់ កាត់ប្រាក់ ឬបន្ថែមម៉ោង។"
  ],
  [
   "回報完成",
   "Report completion",
   "រាយការណ៍បញ្ចប់"
  ],
  [
   "驗收工作",
   "Verify work",
   "ផ្ទៀងផ្ទាត់ការងារ"
  ],
  [
   "目前沒有工作回報。發布有工作項目的崗位班次後，員工即可回報。",
   "No duties yet. Publish a post shift with timed duties to enable reporting.",
   "មិនមានភារកិច្ច។ ផ្សព្វផ្សាយវេនដែលមានការងារតាមម៉ោងដើម្បីរាយការណ៍។"
  ],
  [
   "臨時補位紀錄",
   "Emergency cover history",
   "ប្រវត្តិជំនួសបន្ទាន់"
  ],
  [
   "原任職公司",
   "Original employer",
   "និយោជកដើម"
  ],
  [
   "補位人任職公司",
   "Cover employer",
   "និយោជកអ្នកជំនួស"
  ],
  [
   "複核補位",
   "Review cover",
   "ពិនិត្យជំនួស"
  ],
  [
   "核准補位",
   "Approve cover",
   "អនុម័តជំនួស"
  ],
  [
   "排班流程與規則",
   "Staffing workflow and rules",
   "លំហូរ និងច្បាប់រៀបចំ"
  ],
  [
   "可選固定職位或指定帳號。固定職位會依任職者與有效代理期間判斷；實際複核和核准仍須由不同人完成。",
   "Choose a stable position or a named account. Positions resolve current holders and valid delegates; actual review and approval must use different people.",
   "ជ្រើសតួនាទីថេរ ឬគណនី។ តួនាទីប្រើអ្នកកាន់ និងអ្នកជំនួសស្របពេល ហើយការពិនិត្យ និងអនុម័តត្រូវដោយមនុស្សផ្សេងគ្នា។"
  ],
  [
   "啟用簽核流程",
   "Enable workflow",
   "បើកលំហូរ"
  ],
  [
   "先儲存設定",
   "Save settings first",
   "រក្សាការកំណត់សិន"
  ],
  [
   "職位",
   "Position",
   "តួនាទី"
  ],
  [
   "每週最多分鐘（未確認可留白）",
   "Weekly minute limit (blank if unconfirmed)",
   "កម្រិតនាទីសប្តាហ៍ (ទទេបើមិនបញ្ជាក់)"
  ],
  [
   "兩班間最少休息分鐘（未確認可留白）",
   "Minimum rest minutes (blank if unconfirmed)",
   "នាទីសម្រាកអប្បបរមា (ទទេបើមិនបញ្ជាក់)"
  ],
  [
   "名稱，例如一樓大廳",
   "Name, e.g. ground-floor lobby",
   "ឈ្មោះ ឧ. សាលជាន់ផ្ទាល់ដី"
  ],
  [
   "部門崗位",
   "Department post",
   "តួនាទីផ្នែក"
  ],
  [
   "崗位名稱",
   "Post name",
   "ឈ្មោះតួនាទី"
  ],
  [
   "名冊部門",
   "Roster department",
   "ផ្នែកក្នុងបញ្ជី"
  ],
  [
   "可任職職務（可複選；不選代表同部門全部職務）",
   "Eligible job titles (multi-select; none means all titles in the department)",
   "មុខតំណែងអាចធ្វើ (ជ្រើសច្រើន ទទេមានន័យទាំងអស់ក្នុងផ្នែក)"
  ],
  [
   "模板名稱",
   "Template name",
   "ឈ្មោះគំរូ"
  ],
  [
   "崗位",
   "Post",
   "តួនាទី"
  ],
  [
   "需要人數",
   "Required staff",
   "ចំនួនមនុស្សត្រូវការ"
  ],
  [
   "人力需求",
   "Staffing need",
   "តម្រូវការមនុស្ស"
  ],
  [
   "打卡地點（另於工作區）",
   "Clock-in site (separate from work area)",
   "ទីតាំងចុះម៉ោង (ដាច់ពីតំបន់ការងារ)"
  ],
  [
   "套用班別模板（可不選）",
   "Shift template (optional)",
   "គំរូវេន (ជាជម្រើស)"
  ],
  [
   "臨時補位申請",
   "Request emergency cover",
   "ស្នើជំនួសបន្ទាន់"
  ],
  [
   "員工／任職公司",
   "Employee / employer",
   "បុគ្គលិក / និយោជក"
  ],
  [
   "補位日期",
   "Cover date",
   "ថ្ងៃជំនួស"
  ],
  [
   "交接起始時間",
   "Handover time",
   "ម៉ោងប្រគល់"
  ],
  [
   "原員工休息分鐘",
   "Original worker break minutes",
   "នាទីសម្រាកអ្នកដើម"
  ],
  [
   "補位員工休息分鐘",
   "Cover worker break minutes",
   "នាទីសម្រាកអ្នកជំនួស"
  ],
  [
   "缺勤與補位原因",
   "Absence / cover reason",
   "មូលហេតុអវត្តមាន / ជំនួស"
  ],
  [
   "複核班次",
   "Review staffing",
   "ពិនិត្យវេន"
  ],
  [
   "送出後交由設定的複核人處理，無法直接修改。",
   "Submitting locks editing and sends this shift to the configured reviewer.",
   "ដាក់ស្នើនឹងចាក់សោកែប្រែ និងបញ្ជូនទៅអ្នកពិនិត្យ។"
  ],
  [
   "處理臨時補位",
   "Process emergency cover",
   "ដំណើរការជំនួសបន្ទាន់"
  ],
  [
   "工作驗收",
   "Verify work",
   "ផ្ទៀងផ្ទាត់ការងារ"
  ],
  [
   "結果",
   "Result",
   "លទ្ធផល"
  ],
  [
   "驗收通過",
   "Verified",
   "បានផ្ទៀងផ្ទាត់"
  ],
  [
   "退回重做",
   "Return for rework",
   "បញ្ជូនត្រឡប់ធ្វើឡើងវិញ"
  ],
  [
   "匯出整月班表",
   "Export monthly schedule",
   "នាំចេញកាលវិភាគខែ"
  ],
  [
   "部門（不選則全部）",
   "Department (blank = all)",
   "ផ្នែក (ទទេ = ទាំងអស់)"
  ],
  [
   "下載 UTF-8 CSV，可用 Excel 開啟；每筆保留服務公司及任職公司。",
   "Downloads UTF-8 CSV for Excel, retaining service company and employer on each row.",
   "ទាញយក CSV UTF-8 សម្រាប់ Excel រក្សាក្រុមហ៊ុនសេវា និងនិយោជក។"
  ],
  [
   "工作項目格式：HH:MM 工作內容。",
   "Duty format: HH:MM description.",
   "ទម្រង់ការងារ៖ HH:MM ការងារ។"
  ],
  [
   "工作進度與驗收",
   "Execution & acceptance",
   "វឌ្ឍនភាព និងទទួលយក"
  ],
  [
   "交辦申請與簽核",
   "Requests & approvals",
   "សំណើ និងអនុម័ត"
  ],
  [
   "申請核准後安排負責人；員工回報成果，主管確認完成。",
   "Assign approved work. Employees report evidence; a manager accepts completion.",
   "ចាត់តាំងការងារបានអនុម័ត។ បុគ្គលិករាយការណ៍លទ្ធផល និងអ្នកគ្រប់គ្រងទទួលយក។"
  ],
  [
   "① 申請、複核與核准",
   "① Request, review & approve",
   "① ស្នើ ពិនិត្យ អនុម័ត"
  ],
  [
   "② 指派、期限與成果清單",
   "② Assign, set due date & checklist",
   "② ចាត់តាំង កាលកំណត់ និងបញ្ជី"
  ],
  [
   "③ 員工回報進度",
   "③ Employee progress",
   "③ រាយការណ៍វឌ្ឍនភាព"
  ],
  [
   "④ 主管驗收",
   "④ Manager accepts",
   "④ អ្នកគ្រប់គ្រងទទួលយក"
  ],
  [
   "已核准，待安排執行",
   "Approved, ready to assign",
   "អនុម័ត រង់ចាំចាត់តាំង"
  ],
  [
   "安排執行",
   "Assign execution",
   "ចាត់តាំងអនុវត្ត"
  ],
  [
   "新增交辦申請",
   "New task request",
   "សំណើកិច្ចការថ្មី"
  ],
  [
   "工作／公司",
   "Task / company",
   "កិច្ចការ / ក្រុមហ៊ុន"
  ],
  [
   "成果清單進度",
   "Checklist progress",
   "វឌ្ឍនភាពបញ្ជី"
  ],
  [
   "帳號／公司授權待核對",
   "Account / access needs review",
   "ត្រូវពិនិត្យគណនី / សិទ្ធិ"
  ],
  [
   "工作清單 100% 仍須主管驗收；工程專案、預算與工程驗收在「工程與專案」另行管理。",
   "A 100% checklist still requires manager acceptance. Engineering projects, budgets and inspections remain in Engineering.",
   "បញ្ជី១០០% នៅតែត្រូវអ្នកគ្រប់គ្រងទទួលយក។ គម្រោងវិស្វកម្ម ថវិកា និងត្រួតពិនិត្យនៅផ្នែកវិស្វកម្ម។"
  ],
  [
   "返回工作清單",
   "Back to tasks",
   "ត្រឡប់ទៅបញ្ជីកិច្ចការ"
  ],
  [
   "工作期限",
   "Due date",
   "កាលកំណត់"
  ],
  [
   "已核准來源申請",
   "Approved source request",
   "សំណើប្រភពបានអនុម័ត"
  ],
  [
   "工作成果與里程碑",
   "Deliverables & milestones",
   "លទ្ធផល និងដំណាក់កាល"
  ],
  [
   "完成說明",
   "Completion note",
   "សេចក្តីបញ្ចប់"
  ],
  [
   "需改善",
   "Changes needed",
   "ត្រូវកែលម្អ"
  ],
  [
   "驗收說明",
   "Acceptance note",
   "សេចក្តីទទួលយក"
  ],
  [
   "成果連結與工作回報",
   "Evidence links & updates",
   "តំណលទ្ធផល និងរបាយការណ៍"
  ],
  [
   "保留文件的 HTTPS 連結；此處不會上傳檔案。",
   "Registers HTTPS document links; files are not uploaded here.",
   "រក្សាតំណឯកសារ HTTPS; មិនផ្ទុកឯកសារនៅទីនេះ។"
  ],
  [
   "負責人編號",
   "Assignee ID",
   "លេខអ្នកទទួលខុសត្រូវ"
  ],
  [
   "工作成果／里程碑",
   "Deliverable / milestone",
   "លទ្ធផល / ដំណាក់កាល"
  ],
  [
   "完成日期（選填）",
   "Due date (optional)",
   "ថ្ងៃបញ្ចប់ (ស្រេចចិត្ត)"
  ],
  [
   "安排已核准的工作",
   "Assign approved work",
   "ចាត់តាំងការងារបានអនុម័ត"
  ],
  [
   "實際負責員工",
   "Assigned employee",
   "បុគ្គលិកទទួលខុសត្រូវ"
  ],
  [
   "從已開通帳號且有此公司作業範圍的實際員工選擇，不限人資部門。支援公司不改變薪資歸屬。",
   "Choose an active employee with account and company access, from any department. Work assignment does not change payroll employer.",
   "ជ្រើសបុគ្គលិកមានគណនី និងសិទ្ធិក្រុមហ៊ុន ពីគ្រប់ផ្នែក។ ការចាត់តាំងមិនប្តូរនិយោជកប្រាក់ខែ។"
  ],
  [
   "整份工作的期限",
   "Overall due date",
   "កាលកំណត់កិច្ចការទាំងមូល"
  ],
  [
   "新增成果項目",
   "Add deliverable",
   "បន្ថែមលទ្ធផល"
  ],
  [
   "安排說明",
   "Assignment note",
   "សេចក្តីចាត់តាំង"
  ],
  [
   "確認安排執行",
   "Assign and start",
   "ចាត់តាំង និងចាប់ផ្តើម"
  ],
  [
   "回報完成的成果項目",
   "Mark completed deliverables",
   "សម្គាល់លទ្ធផលបានរួច"
  ],
  [
   "新增成果 HTTPS 連結（選填）",
   "Add HTTPS evidence link (optional)",
   "បន្ថែមតំណលទ្ធផល HTTPS (ស្រេចចិត្ត)"
  ],
  [
   "連結名稱（選填）",
   "Link title (optional)",
   "ឈ្មោះតំណ (ស្រេចចិត្ត)"
  ],
  [
   "所有成果項目須已完成；提交後，等待另一位有驗收權限的主管確認。",
   "Every deliverable must be complete. A different authorized manager will accept the work.",
   "លទ្ធផលទាំងអស់ត្រូវបានរួច។ អ្នកគ្រប់គ្រងមានសិទ្ធិផ្សេងទៀតនឹងទទួលយក។"
  ],
  [
   "處理說明／工作回報",
   "Decision note / work update",
   "សេចក្តីសម្រេច / រាយការណ៍"
  ],
  [
   "最多 30 項。",
   "Maximum 30 items.",
   "អតិបរមា៣០ធាតុ។"
  ],
  [
   "至少保留一項。",
   "Keep at least one item.",
   "រក្សាយ៉ាងតិចមួយ។"
  ],
  [
   "申請",
   "Apply",
   "ស្នើសុំ"
  ],
  [
   "複核 → 核准（職務待確認）",
   "Review → approval (roles pending)",
   "ពិនិត្យ → អនុម័ត (រង់ចាំតួនាទី)"
  ],
  [
   "處理流程",
   "Request workflow",
   "ដំណើរការសំណើ"
  ],
  [
   "此類申請的簽核職務尚待確認，可先存草稿。管理員確認流程後才能送審。",
   "The approval roles for this request are pending confirmation. Save a draft; an administrator must confirm the route before submission.",
   "តួនាទីអនុម័តមិនទាន់បានបញ្ជាក់។ អាចរក្សាសេចក្តីព្រាង មុនអ្នកគ្រប់គ្រងបញ្ជាក់លំហូរ។"
  ],
  [
   "目前處理職務",
   "Current role",
   "តួនាទីបច្ចុប្បន្ន"
  ],
  [
   "目前無可處理帳號，請確認公司授權與人員任職。",
   "No eligible account. Check company access and staffing.",
   "មិនមានគណនីមានសិទ្ធិ។ សូមពិនិត្យសិទ្ធិ និងបុគ្គលិក។"
  ],
  [
   "核准只確認這份申請；不會自動付款、入帳、扣假或改變班表。",
   "Approval confirms this request only. It does not pay, post accounting entries, deduct leave or change shifts.",
   "ការអនុម័តបញ្ជាក់សំណើប៉ុណ្ណោះ។ មិនទូទាត់ កត់គណនេយ្យ កាត់ថ្ងៃឈប់ ឬប្តូរវេនដោយស្វ័យប្រវត្តិទេ។"
  ],
  [
   "處理紀錄與版本",
   "History and versions",
   "ប្រវត្តិ និងកំណែ"
  ],
  [
   "送審輪次",
   "Cycle",
   "លើក"
  ],
  [
   "期間代理",
   "Temporary delegate",
   "អ្នកជំនួសបណ្តោះអាសន្ន"
  ],
  [
   "任職者",
   "Position holder",
   "អ្នកកាន់តំណែង"
  ],
  [
   "查看當時內容",
   "View saved version",
   "មើលកំណែដែលរក្សាទុក"
  ],
  [
   "申請人填單 → 複核者檢查與修改 → 核准者確認。每一步都保留紀錄。",
   "Apply → review and revise → approve. Every step is recorded.",
   "ដាក់សំណើ → ពិនិត្យនិងកែ → អនុម័ត។ គ្រប់ជំហានមានកំណត់ត្រា។"
  ],
  [
   "我提出的",
   "My requests",
   "សំណើរបស់ខ្ញុំ"
  ],
  [
   "授權範圍內",
   "Within my access",
   "ក្នុងសិទ្ធិរបស់ខ្ញុំ"
  ],
  [
   "流程設定",
   "Workflow settings",
   "កំណត់លំហូរ"
  ],
  [
   "先建立草稿，核對內容後送審。退回時可修改，再重新送出。",
   "Create a draft, check it, then submit. Returned requests can be edited and resubmitted.",
   "បង្កើតសេចក្តីព្រាង ពិនិត្យ រួចដាក់ស្នើ។ សំណើដែលត្រឡប់អាចកែ និងដាក់ម្តងទៀត។"
  ],
  [
   "待你複核／核准",
   "Awaiting your review / approval",
   "រង់ចាំអ្នកពិនិត្យ / អនុម័ត"
  ],
  [
   "開啟原單，確認公司與內容，再處理。",
   "Open the request and verify its company and content.",
   "បើកសំណើ ហើយពិនិត្យក្រុមហ៊ុន និងខ្លឹមសារ។"
  ],
  [
   "儲存後開啟原單送審",
   "Save, then open the request",
   "រក្សាទុក រួចបើកសំណើ"
  ],
  [
   "修改會留下前後版本；儲存後仍需按「複核通過」才會送交核准。",
   "Revision preserves both versions. Complete review afterward to send the request for approval.",
   "ការកែរក្សាកំណែមុននិងក្រោយ។ ត្រូវបញ្ចប់ការពិនិត្យបន្ទាប់ ដើម្បីផ្ញើទៅអនុម័ត។"
  ],
  [
   "修改原因",
   "Reason for revision",
   "មូលហេតុកែ"
  ],
  [
   "送出後內容會鎖定。需要修改時，請先撤回或等待退回。",
   "Submission locks the content. Withdraw it or wait for a return before editing.",
   "ក្រោយដាក់ស្នើ ខ្លឹមសារត្រូវចាក់សោ។ ដកសំណើ ឬរង់ចាំត្រឡប់មុនកែ។"
  ],
  [
   "設定固定職位與期間代理 →",
   "Configure positions and temporary delegates →",
   "កំណត់តួនាទី និងអ្នកជំនួស →"
  ],
  [
   "申請流程設定",
   "Request workflow settings",
   "កំណត់លំហូរសំណើ"
  ],
  [
   "按出帳／作業公司與申請類型設定；任職公司與薪資歸屬不會改變。",
   "Configure by business company and request type. Employment and payroll companies stay unchanged.",
   "កំណត់តាមក្រុមហ៊ុនការងារ និងប្រភេទសំណើ។ ក្រុមហ៊ុននិយោជក និងប្រាក់ខែមិនប្តូរ។"
  ],
  [
   "會議確認了「申請 → 複核可修改 → 一至三層核准」。各單據的職務需確認後啟用，不會自動指派給 CEO 或代理人；金額門檻尚未設定。",
   "The meeting confirmed application, editable review and one to three approval levels. Confirm each request’s roles before activation. No automatic CEO or delegate assignment; amount thresholds are not configured.",
   "កិច្ចប្រជុំបានបញ្ជាក់ការស្នើ ពិនិត្យអាចកែ និងអនុម័តពី១ដល់៣កម្រិត។ បញ្ជាក់តួនាទីតាមសំណើមុនបើកប្រើ។ មិនចាត់តាំង CEO ឬអ្នកជំនួសដោយស្វ័យប្រវត្តិ។ មិនទាន់កំណត់កម្រិតទឹកប្រាក់។"
  ],
  [
   "流程",
   "Workflow",
   "លំហូរ"
  ],
  [
   "已確認並啟用",
   "Confirmed and enabled",
   "បានបញ្ជាក់ និងបើក"
  ],
  [
   "待確認／停用",
   "Pending / disabled",
   "រង់ចាំ / បិទ"
  ],
  [
   "各公司、各類單據的複核與核准職務，以及對應帳號和直屬主管關係。",
   "Review / approval roles, enabled accounts and reporting relationships for each company and request type.",
   "តួនាទីពិនិត្យ និងអនុម័តតាមក្រុមហ៊ុន និងសំណើ។"
  ],
  [
   "金額門檻、職位空缺及請假代理的啟用條件與有效期限。",
   "Amount limits, vacancies and leave delegation conditions and duration.",
   "កម្រិតទឹកប្រាក់ និងលក្ខខណ្ឌ រយៈពេលជំនួសតួនាទីទំនេរ ឬឈប់សម្រាក។"
  ],
  [
   "核准後如何入帳、付款、扣假，以及與 PMS／考勤試用的分工。",
   "Posting, payment and leave deduction after approval; PMS and attendance trial responsibilities.",
   "ការកត់គណនេយ្យ ទូទាត់ កាត់ថ្ងៃឈប់ និងការបែងចែកជាមួយ PMS/ការសាកល្បងវត្តមាន។"
  ],
  [
   "名冊離職、公司現況及每位人員的跨公司授權清單。",
   "Roster departures, company status and each person’s cross-company access.",
   "ការចាកចេញក្នុងបញ្ជី ស្ថានភាពក្រុមហ៊ុន និងសិទ្ធិឆ្លងក្រុមហ៊ុនរបស់ម្នាក់ៗ។"
  ],
  [
   "設定已確認流程",
   "Configure a confirmed route",
   "កំណត់លំហូរដែលបានបញ្ជាក់"
  ],
  [
   "流程狀態",
   "Route status",
   "ស្ថានភាពលំហូរ"
  ],
  [
   "停用／待確認",
   "Disabled / pending",
   "បិទ / រង់ចាំ"
  ],
  [
   "啟用已確認流程",
   "Enable confirmed route",
   "បើកលំហូរដែលបានបញ្ជាក់"
  ],
  [
   "複核職務",
   "Review role",
   "តួនាទីពិនិត្យ"
  ],
  [
   "直屬／上兩級主管依員工檔案的主管關係查找，並須有主管或經營主管角色及該公司授權。「公司主管」則涵蓋該公司所有主管帳號。職務沒有可處理人員時會阻擋送審，不會跳關。",
   "Line and second-level managers follow employee reporting relationships and require a manager/executive account with company access. “Company managers” covers all manager accounts for that company. An unfilled role blocks submission.",
   "អ្នកគ្រប់គ្រងផ្ទាល់ និងលំដាប់ទីពីរអាស្រ័យតាមឯកសារបុគ្គលិក និងត្រូវមានតួនាទីអ្នកគ្រប់គ្រង និងសិទ្ធិក្រុមហ៊ុន។ តួនាទីគ្មានអ្នកទទួលបន្ទុកនឹងរារាំងការដាក់ស្នើ។"
  ],
  [
   "此流程已與業務確認",
   "This route has been confirmed with the business",
   "លំហូរនេះបានបញ្ជាក់ជាមួយអាជីវកម្ម"
  ],
  [
   "設定只套用到新的送審；已送審單據保留原流程版本。",
   "Changes apply to new submissions. Submitted requests retain their route version.",
   "ការកែអនុវត្តលើសំណើថ្មី។ សំណើដែលដាក់រួចរក្សាកំណែលំហូរដើម។"
  ],
  [
   "編輯作業權限",
   "Edit work access",
   "កែសិទ្ធិការងារ"
  ],
  [
   "可作業公司（逐一授權）",
   "Authorized work companies",
   "ក្រុមហ៊ុនដែលអនុញ្ញាតឱ្យធ្វើការ"
  ],
  [
   "新增公司只擴大這個角色的作業範圍，不會變更任職、薪資公司，也不會讓人資取得工程或他人薪資權限。請保留任職公司的本人作業權限。",
   "Adding a company extends this role’s work scope only. It does not change employer/payroll or grant HR access to engineering or others’ pay. Keep the employee’s employer selected.",
   "បន្ថែមក្រុមហ៊ុនពង្រីកតែសិទ្ធិតួនាទីនេះ។ មិនប្តូរក្រុមហ៊ុននិយោជក/ប្រាក់ខែ ឬផ្តល់ឱ្យ HR មើលវិស្វកម្ម និងប្រាក់ខែអ្នកផ្សេងទេ។ រក្សាក្រុមហ៊ុននិយោជក។"
  ],
  [
   "儲存後，這個帳號須重新登入；變更會留下紀錄。",
   "The account must sign in again after saving. Changes are audited.",
   "គណនីត្រូវចូលម្តងទៀតក្រោយរក្សាទុក។ ការប្តូរមានកំណត់ត្រា។"
  ],
  [
   "請設定複核與第一層核准，後續層級不可跳過。",
   "Set review and first approval. Do not skip a later level.",
   "កំណត់ការពិនិត្យ និងអនុម័តទីមួយ។ មិនអាចរំលងកម្រិតបានទេ។"
  ],
  [
   "公司授權與申請流程",
   "Company access and workflows",
   "សិទ្ធិក្រុមហ៊ុន និងលំហូរ"
  ],
  [
   "帳號表的「權限」可調整角色與可作業公司；任職／薪資公司保持原設定。",
   "Use “Access” in the accounts table to adjust roles and work companies. Employer and payroll company remain unchanged.",
   "ប្រើ «សិទ្ធិ» ក្នុងតារាងគណនីដើម្បីកែតួនាទី និងក្រុមហ៊ុនការងារ។ ក្រុមហ៊ុននិយោជក និងប្រាក់ខែមិនប្តូរ។"
  ],
  [
   "設定申請、複核與核准 →",
   "Configure application, review and approval →",
   "កំណត់ការស្នើ ពិនិត្យ និងអនុម័ត →"
  ]
 ]
});
