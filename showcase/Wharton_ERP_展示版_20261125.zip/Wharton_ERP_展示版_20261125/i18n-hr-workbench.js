/* Offline exhibition interface translations. */
window.SFM_I18N??={};
Object.assign(window.SFM_I18N,{
 "hrWorkbench": [
  [
   "人事管理總覽",
   "HR management overview",
   "ទិដ្ឋភាពទូទៅការគ្រប់គ្រងបុគ្គលិក"
  ],
  [
   "部門管理總覽",
   "Department overview",
   "ទិដ្ឋភាពទូទៅផ្នែក"
  ],
  [
   "授權範圍人員",
   "Employees in scope",
   "បុគ្គលិកក្នុងវិសាលភាពសិទ្ធិ"
  ],
  [
   "有待查項目",
   "People needing attention",
   "អ្នកដែលមានចំណុចត្រូវពិនិត្យ"
  ],
  [
   "尚待核對／補正",
   "To check or correct",
   "ត្រូវផ្ទៀងផ្ទាត់ឬកែតម្រូវ"
  ],
  [
   "已完成核對",
   "Checked",
   "បានផ្ទៀងផ្ទាត់"
  ],
  [
   "查看人員 →",
   "View employees →",
   "មើលបុគ្គលិក →"
  ],
  [
   "綜合檢核",
   "Overall check",
   "ការពិនិត្យរួម"
  ],
  [
   "每月年假總表",
   "Monthly annual leave register",
   "បញ្ជីច្បាប់ឈប់ប្រចាំឆ្នាំតាមខែ"
  ],
  [
   "證件期限總表",
   "Document expiry register",
   "បញ្ជីកាលផុតកំណត់ឯកសារ"
  ],
  [
   "搜尋人員",
   "Search employees",
   "ស្វែងរកបុគ្គលិក"
  ],
  [
   "姓名、編號或職務",
   "Name, ID or position",
   "ឈ្មោះ លេខសម្គាល់ ឬមុខតំណែង"
  ],
  [
   "月初年假",
   "Opening annual leave",
   "សមតុល្យច្បាប់ឈប់ដើមខែ"
  ],
  [
   "本月新增",
   "Accrued this month",
   "បង្គរខែនេះ"
  ],
  [
   "本月調整",
   "Adjustments this month",
   "កែតម្រូវខែនេះ"
  ],
  [
   "本月已休年假",
   "Annual leave used this month",
   "ច្បាប់ឈប់ប្រចាំឆ្នាំប្រើខែនេះ"
  ],
  [
   "本月待審年假",
   "Annual leave pending this month",
   "ច្បាប់ឈប់ប្រចាំឆ្នាំរង់ចាំខែនេះ"
  ],
  [
   "月末年假",
   "Closing annual leave",
   "សមតុល្យច្បាប់ឈប់ចុងខែ"
  ],
  [
   "核對狀態",
   "Check status",
   "ស្ថានភាពផ្ទៀងផ្ទាត់"
  ],
  [
   "核對資料",
   "Check records",
   "ផ្ទៀងផ្ទាត់កំណត់ត្រា"
  ],
  [
   "證件狀況",
   "Document status",
   "ស្ថានភាពឯកសារ"
  ],
  [
   "本月核准請假",
   "Approved leave this month",
   "ច្បាប់ឈប់បានអនុម័តខែនេះ"
  ],
  [
   "由人資管理",
   "Managed by HR",
   "គ្រប់គ្រងដោយផ្នែកបុគ្គលិក"
  ],
  [
   "已登錄・期限正常",
   "Recorded · dates valid",
   "បានចុះបញ្ជី · កាលបរិច្ឆេទមានសុពលភាព"
  ],
  [
   "尚未核對",
   "Not yet checked",
   "មិនទាន់ផ្ទៀងផ្ទាត់"
  ],
  [
   "資料更新，請重核",
   "Data changed; check again",
   "ទិន្នន័យបានផ្លាស់ប្ដូរ សូមផ្ទៀងផ្ទាត់ឡើងវិញ"
  ],
  [
   "待補正",
   "Correction needed",
   "ត្រូវកែតម្រូវ"
  ],
  [
   "已核對",
   "Checked",
   "បានផ្ទៀងផ្ទាត់"
  ],
  [
   "返回管理總覽",
   "Back to management overview",
   "ត្រឡប់ទៅទិដ្ឋភាពគ្រប់គ្រង"
  ],
  [
   "登記核對結果",
   "Record check result",
   "កត់ត្រាលទ្ធផលផ្ទៀងផ្ទាត់"
  ],
  [
   "核對結果",
   "Check result",
   "លទ្ធផលផ្ទៀងផ្ទាត់"
  ],
  [
   "核對說明",
   "Check notes",
   "កំណត់សម្គាល់ផ្ទៀងផ្ទាត់"
  ],
  [
   "核對歷史",
   "Check history",
   "ប្រវត្តិផ្ទៀងផ្ទាត់"
  ],
  [
   "尚無核對紀錄。",
   "No check records yet.",
   "មិនទាន់មានកំណត់ត្រាផ្ទៀងផ្ទាត់ទេ។"
  ],
  [
   "此紀錄之後資料已有更新",
   "Data has changed since this check",
   "ទិន្នន័យបានផ្លាស់ប្ដូរក្រោយការផ្ទៀងផ្ទាត់នេះ"
  ],
  [
   "已完成核對",
   "Check completed",
   "បានបញ្ចប់ការផ្ទៀងផ្ទាត់"
  ],
  [
   "證件與期限",
   "Documents and dates",
   "ឯកសារនិងកាលបរិច្ឆេទ"
  ],
  [
   "請核對是否適用並補登資料",
   "Check applicability and record missing data",
   "ពិនិត្យលក្ខខណ្ឌនិងបញ្ចូលទិន្នន័យខ្វះ"
  ],
  [
   "有效／已留存",
   "Valid / on file",
   "មានសុពលភាព / បានរក្សាទុក"
  ],
  [
   "證件總表與補件",
   "Document register and missing items",
   "បញ្ជីឯកសារនិងការបំពេញឯកសារខ្វះ"
  ],
  [
   "假勤與工時",
   "Leave and working hours",
   "ច្បាប់ឈប់និងម៉ោងការងារ"
  ],
  [
   "排定／打卡參考工時",
   "Scheduled / clocked reference hours",
   "ម៉ោងបានកំណត់ / ម៉ោងកត់ត្រាយោង"
  ],
  [
   "本月核准加班",
   "Approved overtime this month",
   "ម៉ោងបន្ថែមបានអនុម័តខែនេះ"
  ],
  [
   "假勤來源明細",
   "Leave source records",
   "កំណត់ត្រាប្រភពច្បាប់ឈប់"
  ],
  [
   "班表與缺卡",
   "Shifts and missing punches",
   "វេននិងការខ្វះកត់ត្រាវត្តមាន"
  ],
  [
   "本月年假核對",
   "Monthly annual leave check",
   "ផ្ទៀងផ្ទាត់ច្បាប់ឈប់ប្រចាំខែ"
  ],
  [
   "本月新增／調整",
   "Monthly accrual / adjustments",
   "បង្គរ / កែតម្រូវខែនេះ"
  ],
  [
   "本月已休／待審",
   "Used / pending this month",
   "ប្រើ / រង់ចាំខែនេះ"
  ],
  [
   "月末年假（未扣待審）",
   "Closing balance (before pending leave)",
   "សមតុល្យចុងខែ (មិនទាន់កាត់សំណើរង់ចាំ)"
  ],
  [
   "此年度尚未設定額度",
   "Entitlement not set for this year",
   "មិនទាន់កំណត់សិទ្ធិសម្រាប់ឆ្នាំនេះ"
  ],
  [
   "額度設定與調整",
   "Entitlement settings and adjustments",
   "ការកំណត់និងកែតម្រូវសិទ្ធិ"
  ],
  [
   "待我簽核的單據",
   "Requests awaiting my approval",
   "សំណើរង់ចាំការអនុម័តរបស់ខ្ញុំ"
  ],
  [
   "原有員工名冊",
   "Existing employee roster",
   "បញ្ជីបុគ្គលិកដើម"
  ],
  [
   "證件已到期",
   "Expired documents",
   "ឯកសារផុតកំណត់"
  ],
  [
   "證件即將到期",
   "Documents expiring soon",
   "ឯកសារជិតផុតកំណត់"
  ],
  [
   "證件未登錄",
   "Documents not recorded",
   "ឯកសារមិនទាន់ចុះបញ្ជី"
  ],
  [
   "打卡待核對",
   "Punch records need checking",
   "កំណត់ត្រាវត្តមានត្រូវផ្ទៀងផ្ទាត់"
  ],
  [
   "假勤待審",
   "Leave awaiting approval",
   "ច្បាប់ឈប់រង់ចាំអនុម័ត"
  ],
  [
   "跨月工時待拆分",
   "Cross-month hours need allocation",
   "ម៉ោងឆ្លងខែត្រូវបែងចែក"
  ],
  [
   "年度額度未設定",
   "Annual entitlement not set",
   "មិនទាន់កំណត់សិទ្ធិប្រចាំឆ្នាំ"
  ],
  [
   "年假餘額待核對",
   "Annual leave balance needs checking",
   "សមតុល្យច្បាប់ឈប់ប្រចាំឆ្នាំត្រូវពិនិត្យ"
  ],
  [
   "先核對人員與整體狀況，再處理缺件、到期及假勤異常。",
   "Review all employees and overall status, then handle missing documents, expiry and attendance issues.",
   "ពិនិត្យបុគ្គលិកនិងស្ថានភាពរួម រួចដោះស្រាយឯកសារខ្វះ ការផុតកំណត់ និងបញ្ហាវត្តមាន។"
  ],
  [
   "全部為虛構示範資料；所有操作只保存在此瀏覽器。",
   "Workflow examples · Existing real employee records are preserved. Checks here do not change formal records.",
   "ឧទាហរណ៍ដំណើរការ · កំណត់ត្រាបុគ្គលិកពិតរក្សាដដែល។ ការផ្ទៀងផ្ទាត់ទីនេះមិនកែទិន្នន័យផ្លូវការទេ។"
  ],
  [
   "核對紀錄不會代替請假簽核、補卡審核或更新原始資料。",
   "Check notes do not replace leave approvals, punch reviews or edits to source records.",
   "កំណត់ត្រាផ្ទៀងផ្ទាត់មិនជំនួសការអនុម័តច្បាប់ឈប់ ការពិនិត្យវត្តមាន ឬការកែប្រភពទិន្នន័យទេ។"
  ],
  [
   "目前沒有系統提示的待查項目。",
   "No system-flagged issues at present.",
   "បច្ចុប្បន្នមិនមានចំណុចដែលប្រព័ន្ធបង្ហាញឱ្យពិនិត្យទេ។"
  ],
  [
   "未登錄證件須先核對是否適用；已核對不會消除仍存在的到期、缺件或待審事項。",
   "Check whether unrecorded documents apply. Marking a check complete does not clear outstanding expiry, missing data or pending requests.",
   "ពិនិត្យថាឯកសារមិនទាន់ចុះបញ្ជីត្រូវអនុវត្តឬទេ។ ការសម្គាល់ថាបានផ្ទៀងផ្ទាត់មិនលុបបញ្ហាផុតកំណត់ ឯកសារខ្វះ ឬសំណើរង់ចាំទេ។"
  ],
  [
   "年假新增依已設定的累計截止月；更動來源資料後，核對狀態會自動提醒重新檢查。",
   "Accrual follows the configured cutoff month. Changes to source data flag the record for another check.",
   "ការបង្គរតាមខែបញ្ចប់ដែលបានកំណត់។ ពេលទិន្នន័យប្រភពផ្លាស់ប្ដូរ ប្រព័ន្ធរំលឹកឱ្យពិនិត្យឡើងវិញ។"
  ],
  [
   "依目前核准結果回算，並非當時封存餘額。跨月申請未拆分時，餘額僅供核對。",
   "Recalculated from current approval results, not an archived balance. Cross-month requests must be allocated before relying on the balance.",
   "គណនាឡើងវិញពីលទ្ធផលអនុម័តបច្ចុប្បន្ន មិនមែនសមតុល្យទុកក្នុងបណ្ណសារទេ។ ត្រូវបែងចែកសំណើឆ្លងខែមុនពឹងផ្អែកលើសមតុល្យ។"
  ],
  [
   "月末年假＝月初＋本月新增＋調整－本月已休。依目前核准結果回算，不代表歷史封存；跨月未拆分另列待查。",
   "Closing leave = opening + monthly accrual + adjustments − leave used. Recalculated from current approvals, not a historical archive. Unallocated cross-month requests are flagged separately.",
   "សមតុល្យចុងខែ = ដើមខែ + បង្គរ + កែតម្រូវ − ច្បាប់ឈប់បានប្រើ។ គណនាតាមការអនុម័តបច្ចុប្បន្ន មិនមែនបណ្ណសារប្រវត្តិសាស្ត្រទេ។ សំណើឆ្លងខែមិនទាន់បែងចែកត្រូវពិនិត្យដាច់ដោយឡែក។"
  ],
  [
   "目前身分無法查看管理總表",
   "Your role cannot access this management register",
   "តួនាទីរបស់អ្នកមិនអាចមើលបញ្ជីគ្រប់គ្រងនេះបានទេ"
  ],
  [
   "此員工不在目前授權範圍",
   "This employee is outside your authorized scope",
   "បុគ្គលិកនេះនៅក្រៅវិសាលភាពសិទ្ធិរបស់អ្នក"
  ],
  [
   "此範圍沒有符合條件的人員",
   "No employees match these filters",
   "មិនមានបុគ្គលិកត្រូវតាមតម្រងនេះទេ"
  ],
  [
   "來源資料已更新，請重新開啟核對。",
   "Source data changed. Reopen the check.",
   "ទិន្នន័យប្រភពបានផ្លាស់ប្ដូរ។ សូមបើកការផ្ទៀងផ្ទាត់ឡើងវិញ។"
  ],
  [
   "請記錄需補正事項或核對說明。",
   "Record the correction needed or check notes.",
   "សូមកត់ត្រាចំណុចត្រូវកែតម្រូវឬកំណត់សម្គាល់ផ្ទៀងផ្ទាត់។"
  ],
  [
   "目前無待查項目",
   "No flagged issues",
   "មិនមានចំណុចត្រូវពិនិត្យ"
  ]
 ]
});
